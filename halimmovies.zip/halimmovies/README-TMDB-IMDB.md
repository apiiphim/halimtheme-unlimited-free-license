# Hướng dẫn sử dụng TMDB/IMDB Helper Functions

## Tổng quan
Plugin crawl đã được cập nhật để hỗ trợ API đầy đủ với thông tin TMDB và IMDB. Các helper functions được tạo để hiển thị thông tin này trong theme.

## Cấu trúc dữ liệu mới

### Fields được thêm vào:
- `halim_tmdb_id` - TMDB ID
- `halim_tmdb_type` - Loại (movie/tv)
- `halim_tmdb_season` - Season (cho TV series)
- `halim_tmdb_vote_average` - Điểm đánh giá TMDB (0-10)
- `halim_tmdb_vote_count` - Số lượt vote
- `halim_imdb_id` - IMDB ID

### Fields được cập nhật:
- `halim_rating` - Giờ chứa TMDB rating (0-10)
- `halim_votes` - Giờ chứa TMDB vote count

## Các Helper Functions

### 1. `halim_get_tmdb_info($post_id = null)`
Lấy tất cả thông tin TMDB/IMDB của một post.

```php
$tmdb_info = halim_get_tmdb_info();
echo "Rating: " . $tmdb_info['tmdb_vote_average'] . "/10";
echo "Votes: " . $tmdb_info['tmdb_vote_count'];
echo "IMDB ID: " . $tmdb_info['imdb_id'];
```

### 2. `halim_display_rating_stars($post_id = null)`
Hiển thị rating dạng sao (5 sao).

```php
echo halim_display_rating_stars();
```

### 3. `halim_display_compact_rating($post_id = null)`
Hiển thị rating dạng compact badge.

```php
echo halim_display_compact_rating();
```

### 4. `halim_display_tmdb_imdb_info($post_id = null)`
Hiển thị thông tin chi tiết TMDB/IMDB.

```php
echo halim_display_tmdb_imdb_info();
```

### 5. `halim_display_external_links($post_id = null)`
Hiển thị links đến IMDB và TMDB.

```php
echo halim_display_external_links();
```

### 6. `halim_get_rating_text($post_id = null)`
Lấy text rating đơn giản.

```php
echo halim_get_rating_text(); // Output: "7.8/10"
```

### 7. `halim_display_compact_tmdb_imdb($post_id = null)`
Hiển thị thông tin TMDB/IMDB dạng compact badges (cho movie cards).

```php
echo halim_display_compact_tmdb_imdb();
```

### 8. `halim_display_sidebar_tmdb_imdb($post_id = null)`
Hiển thị thông tin TMDB/IMDB trong sidebar.

```php
echo halim_display_sidebar_tmdb_imdb();
```

### 9. `halim_display_actor_images($post_id = null)`
Hiển thị ảnh diễn viên với tên (cơ bản).

```php
echo halim_display_actor_images();
```

### 10. `halim_display_director_images($post_id = null)`
Hiển thị ảnh đạo diễn với tên (cơ bản).

```php
echo halim_display_director_images();
```

### 11. `halim_display_actor_images_with_movies($post_id = null)`
Hiển thị ảnh diễn viên với tính năng click để xem danh sách phim.

```php
echo halim_display_actor_images_with_movies();
```

### 12. `halim_display_director_images_with_movies($post_id = null)`
Hiển thị ảnh đạo diễn với tính năng click để xem danh sách phim.

```php
echo halim_display_director_images_with_movies();
```

### 13. `halim_get_actor_director_movies($tmdb_id, $type = 'actor')`
Lấy danh sách phim của diễn viên/đạo diễn từ TMDB.

```php
$movies = halim_get_actor_director_movies('12345', 'actor');
```

## Cách sử dụng trong Theme

### Trong single.php (trang chi tiết phim):
```php
<div class="movie-meta">
    <?php
    // Hiển thị rating sao
    $rating = halim_display_rating_stars();
    if ($rating) {
        echo '<div class="rating-section">' . $rating . '</div>';
    }
    
    // Hiển thị rating compact
    $compact_rating = halim_display_compact_rating();
    if ($compact_rating) {
        echo '<div class="compact-rating-section">' . $compact_rating . '</div>';
    }
    
    // Hiển thị thông tin TMDB/IMDB
    $tmdb_info = halim_display_tmdb_imdb_info();
    if ($tmdb_info) {
        echo '<div class="tmdb-imdb-section">' . $tmdb_info . '</div>';
    }
    
    // Hiển thị external links
    $links = halim_display_external_links();
    if ($links) {
        echo '<div class="external-links-section">' . $links . '</div>';
    }
    ?>
</div>
```

### Trong loop-item.php (movie cards):
```php
<div class="movie-card">
    <div class="movie-rating">
        <?php 
        $rating_text = halim_get_rating_text();
        if ($rating_text) {
            echo '<span class="rating-badge">' . $rating_text . '</span>';
        }
        ?>
    </div>
    
    <!-- Hiển thị thông tin TMDB/IMDB compact -->
    <div class="movie-card-tmdb-imdb">
        <?php 
        $compact_tmdb_imdb = halim_display_compact_tmdb_imdb();
        if ($compact_tmdb_imdb) {
            echo $compact_tmdb_imdb;
        }
        ?>
    </div>
</div>
```

### Trong sidebar hoặc widget:
```php
<?php
// Hiển thị rating
$tmdb_info = halim_get_tmdb_info();
if ($tmdb_info['tmdb_vote_average'] > 0) {
    echo '<div class="sidebar-rating">';
    echo '<h4>Đánh giá từ TMDB</h4>';
    echo halim_display_rating_stars();
    echo '<p>Dựa trên ' . number_format($tmdb_info['tmdb_vote_count']) . ' lượt đánh giá</p>';
    echo '</div>';
}

// Hiển thị thông tin TMDB/IMDB
$sidebar_info = halim_display_sidebar_tmdb_imdb();
if ($sidebar_info) {
    echo $sidebar_info;
}
?>
```

## Styling CSS

Tất cả CSS cần thiết đã được tự động thêm vào `<head>` của trang. Bạn có thể override các styles này bằng cách thêm CSS vào theme của mình.

### Các class CSS chính:
- `.halim-rating-stars` - Rating stars
- `.halim-compact-rating` - Compact rating badge
- `.halim-tmdb-imdb-info` - TMDB/IMDB info box
- `.halim-external-links` - External links

## Lưu ý quan trọng

1. **halim_rating** giờ chứa TMDB rating (0-10), không phải IMDB ID
2. **halim_votes** giờ chứa TMDB vote count
3. IMDB ID được lưu trong field mới `halim_imdb_id`
4. Tất cả functions đều có fallback để tương thích ngược

## Troubleshooting

### Nếu không hiển thị gì:
1. Kiểm tra xem post có dữ liệu TMDB/IMDB không
2. Sử dụng `var_dump(halim_get_tmdb_info())` để debug
3. Kiểm tra console browser có lỗi JavaScript không

### Nếu rating không đúng:
1. Kiểm tra field `halim_rating` trong database
2. Đảm bảo plugin crawl đã chạy thành công
3. Kiểm tra TMDB API key đã được cấu hình

### Trong movie meta section:
```php
<div class="movie-meta-tmdb-imdb">
    <?php
    // Hiển thị thông tin TMDB/IMDB đầy đủ
    $full_info = halim_display_tmdb_imdb_info();
    if ($full_info) {
        echo $full_info;
    }
    
    // Hiển thị badges compact
    $compact_badges = halim_display_compact_tmdb_imdb();
    if ($compact_badges) {
        echo '<div class="meta-badges">' . $compact_badges . '</div>';
    }
    ?>
</div>
```

## Ví dụ hoàn chỉnh

Xem file `example-tmdb-usage.php` để có các ví dụ chi tiết về cách sử dụng tất cả functions.

## 🆕 Tính năng mới: Thông tin chi tiết diễn viên & đạo diễn từ TMDB

### **Tính năng đã được thêm:**

#### **1. Thay thế hoàn toàn thông tin từ API KKPHIM:**
- **Trước**: Chỉ lưu danh sách tên đơn giản từ API KKPHIM
- **Sau**: Lấy thông tin chi tiết từ TMDB API cho từng diễn viên/đạo diễn
- **Kết quả**: Thông tin phong phú hơn, chính xác hơn từ cơ sở dữ liệu TMDB

#### **2. Thông tin chi tiết từ TMDB API:**
- **TMDB ID**: ID chính thức trên TMDB
- **Department**: Bộ phận chuyên môn (Acting, Directing, Production...)
- **Popularity**: Độ nổi tiếng (0-100)
- **Biography**: Tiểu sử chi tiết
- **Birthday/Deathday**: Ngày sinh/mất
- **Place of Birth**: Nơi sinh
- **Gender**: Giới tính
- **Combined Credits**: Danh sách phim đã tham gia

#### **3. Lưu ảnh vào WordPress:**
- Ảnh profile chính thức từ TMDB
- Tự động tạo các kích thước ảnh khác nhau
- Placeholder đẹp mắt nếu không có ảnh
- Liên kết với post phim tương ứng

#### **4. Hiển thị trong theme:**
- **Layout 1**: Thông tin chi tiết thay thế text cũ
- **Layout 2**: Thông tin chi tiết thay thế text cũ
- Responsive grid layout với hover effects
- Hiển thị department và popularity
- **Không còn hiển thị trùng lặp** thông tin diễn viên/đạo diễn

### **Cách sử dụng:**

```php
// Hiển thị ảnh diễn viên
$actor_images = halim_display_actor_images();
if ($actor_images) {
    echo $actor_images;
}

// Hiển thị ảnh đạo diễn  
$director_images = halim_display_director_images();
if ($director_images) {
    echo $director_images;
}
```

### **Cấu trúc dữ liệu mới:**
- `halim_actor_images` - Mảng chứa thông tin chi tiết diễn viên từ TMDB
- `halim_director_images` - Mảng chứa thông tin chi tiết đạo diễn từ TMDB

### **Cấu trúc dữ liệu chi tiết:**
```php
array(
    'name' => 'Jensen Ackles',
    'tmdb_id' => '12345',
    'known_for_department' => 'Acting',
    'popularity' => 85.6,
    'profile_path' => '/abc123.jpg',
    'image_url' => 'https://yoursite.com/wp-content/uploads/...',
    'image_id' => 678,
    'biography' => 'Jensen Ackles is an American actor...',
    'birthday' => '1978-03-01',
    'deathday' => null,
    'place_of_birth' => 'Dallas, Texas, USA',
    'gender' => 2
)
```

### **Lưu ý:**
- Cần có TMDB API key để lấy thông tin chi tiết
- Thông tin chỉ được lưu khi crawl phim mới hoặc re-update
- Tự động fallback về tên cũ nếu không tìm thấy trên TMDB
- Cache TMDB API trong 24 giờ để tối ưu hiệu suất

## 🆕 Tính năng mới: Truy cập danh sách phim của diễn viên/đạo diễn

### **Tính năng đã được thêm:**

#### **1. Hình ảnh tròn 64x64 với layout hàng ngang:**
- **Kích thước**: 64x64px (responsive: 56x56px trên mobile)
- **Layout**: Flexbox với `flex-wrap` để tự động xuống dòng
- **Spacing**: Khoảng cách đồng nhất giữa các items
- **Responsive**: Tự động điều chỉnh trên mobile

#### **2. Clickable diễn viên/đạo diễn:**
- **Tên clickable**: Chỉ hiển thị cho diễn viên/đạo diễn có TMDB ID
- **Visual feedback**: Màu xanh, gạch chân, hover effect
- **Modal popup**: Hiển thị danh sách phim trong modal đẹp mắt

#### **3. Danh sách phim từ TMDB:**
- **Lấy trực tiếp**: Gọi TMDB API `/credits` để lấy cast/crew
- **Thông tin chi tiết**: Tên phim, vai diễn, năm, loại (Movie/TV)
- **Sắp xếp**: Theo popularity (độ nổi tiếng)
- **Giới hạn**: Top 20 phim nổi tiếng nhất
- **Cache**: 12 giờ để tối ưu hiệu suất

#### **4. Modal hiển thị phim:**
- **Responsive design**: Tự động điều chỉnh kích thước
- **Poster images**: Hiển thị poster phim từ TMDB
- **Thông tin chi tiết**: Vai diễn, năm, loại phim
- **Loading state**: Hiển thị trạng thái đang tải
- **Error handling**: Xử lý lỗi khi không thể tải dữ liệu

### **Cách sử dụng:**

```php
// Hiển thị diễn viên với tính năng xem danh sách phim
echo halim_display_actor_images_with_movies();

// Hiển thị đạo diễn với tính năng xem danh sách phim  
echo halim_display_director_images_with_movies();

// Lấy danh sách phim của diễn viên/đạo diễn
$movies = halim_get_actor_director_movies('12345', 'actor');
```

### **Tính năng tương tác:**
1. **Click vào tên diễn viên/đạo diễn** (có TMDB ID)
2. **Modal hiển thị** với tiêu đề "Danh sách phim của [Tên]"
3. **Danh sách phim** được tải từ TMDB API
4. **Thông tin chi tiết** bao gồm poster, tên, vai diễn, năm
5. **Đóng modal** bằng nút X hoặc click bên ngoài

### **Lưu ý:**
- Chỉ diễn viên/đạo diễn có TMDB ID mới có thể click
- Cần TMDB API key để lấy danh sách phim
- Dữ liệu được cache để tối ưu hiệu suất
- Modal responsive và hoạt động tốt trên mobile
