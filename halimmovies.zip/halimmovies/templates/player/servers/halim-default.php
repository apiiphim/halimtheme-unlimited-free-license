<?php

use HaLim\Player\Servers;

class halim_default_host extends Servers
{
	public function get_link($link)
	{
		$json[] = array(
			'file' => $link,
			'type' => 'hls'
		);
		return json_encode($json);
	}
}
