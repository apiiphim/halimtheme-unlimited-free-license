<?php

use HaLim\Player\Player;

$meta            = get_post_meta($post->ID, '_halim_metabox_options', true );
$is_copyright    = isset($meta['is_copyright']) ? $meta['is_copyright'] : false;
$is_adult        = isset($meta['is_adult']) ? $meta['is_adult'] : false;
$player_options  = cs_get_option('halim_jw_player_options');
$player_autonext = isset($player_options['jw_player_autonext'])
? $player_options['jw_player_autonext'] : false;
$status          = isset($meta['halim_movie_status']) ? $meta['halim_movie_status'] : '';
$player_layout   = cs_get_option('player_layout') == 'fullwidth' ? : 'default';
$server          = get_query_var('halim_server');
$episode_slug    = get_query_var('episode_slug') ?
str_replace('-', '_', get_query_var('episode_slug')) : '';

do_action('halim_player_enqueue_scripts');

if($is_copyright):
    $msg = apply_filters('halim_copyright_msg', __('We are unable to find the video you are looking for.<br>There could be several reasons for this, for example it got removed by the owner <span style="color: yellow; font-weight: bold">or this content is not available in your country!</span>', 'halimthemes'));
     ?>
    <div id="is_copyright">
        <p><i class="hl-attention"></i> <?php echo $msg; ?></p>
    </div>
<?php else: ?>
    <?php do_action('halim_before_player_box', $post->ID); ?>
    <div id="halim-player-wrapper" class="ajax-player-loading" data-adult-content="<?php echo $is_adult; ?>">
        <?php
            if ( ! post_password_required( $post ) ) {
            ?>

                <?php if(cs_get_option('player_types') == 'html') : ?>
                    <div id="html-player" class="player">
                        <div id="halim-player-loader"></div>
                        <?php
                            $player = new Player();
                            $player->Player($post->ID, $episode_slug, $server);
                        ?>
                    </div>
                <?php else: ?>
                    <div id="halim-player-loader"></div>
                    <div id="ajax-player" class="player"></div>
                <?php endif;
                    if($status == 'is_trailer'){
                        echo '<span class="trailer-button">Trailer</span>';
                    }
            } else {
                echo get_the_password_form();
            }
        ?>
    </div>
    <?php do_action('halim_after_player_box', $post->ID); ?>

    <div class="clearfix"></div>

    <div class="player-control text-center <?php echo $player_layout; ?>">
            <?php do_action('halim_before_player_control', $post->ID); ?>
            <?php if(cs_get_option('enable_next_prev_episode_button')) : ?>
                <div class="plyr-ctrl-btn halim-prev-episode"><i class="hl-next prev"></i> <?php _e('Prev EP', 'halimthemes'); ?></div>
                <div class="plyr-ctrl-btn halim-next-episode"><?php _e('Next EP', 'halimthemes'); ?> <i class="hl-next"></i></div>
            <?php endif; ?>
            <?php if($player_autonext == true) : ?>
                <div id="autonext" class="plyr-ctrl-btn btn-cs autonext">
                    <i class="icon-autonext-sm"></i>
                    <span><i class="hl-next"></i> <?php _e('Auto next ep', 'halimthemes') ?>: <span id="autonext-status"><?php _e('On', 'halimthemes') ?></span></span>
                </div>
            <?php endif ?>
            <?php if(cs_get_option('player_layout') == 'default') : ?>
                <div id="explayer" class="plyr-ctrl-btn hidden-xs"><i class="hl-resize-full"></i>
                    <?php _e('Expand', 'halimthemes') ?>
                </div>
            <?php endif ?>
            <div id="toggle-light" class="plyr-ctrl-btn"><i class="hl-adjust"></i>
                <?php _e('Light Off', 'halimthemes') ?>
            </div>
            <?php if(get_option('halim_report_enable')) : ?>
            <div id="report" class="plyr-ctrl-btn halim-switch"><i class="hl-attention"></i> <?php _e('Report', 'halimthemes'); ?></div>
            <?php endif; ?>
            <?php if(cs_get_option('show_post_view_count')): ?>
            <div class="view-count plyr-ctrl-btn"><i class="hl-fire"></i>
                <span><?php echo halim_display_post_view_count($post->ID) ?></span> <?php _e('view', 'halimthemes') ?>
            </div>
            <?php endif; ?>
            <?php do_action('halim_after_player_control', $post->ID); ?>
    </div>
<?php endif; ?>
<div class="clearfix"></div>