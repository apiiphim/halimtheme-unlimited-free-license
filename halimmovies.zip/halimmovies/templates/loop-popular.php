<?php

    $meta = get_post_meta($post->ID, '_halim_metabox_options', true );
    $org_title = !empty($meta['halim_original_title'])?$meta['halim_original_title']:'';
    $quality = !empty($meta['halim_quality'])?$meta['halim_quality']:'';
    $lastep = HALIMHelper::is_type('tv_series')
    ? halim_add_episode_name_to_the_title(halim_get_last_episode($post->ID)) : '';
    $episode = !empty($meta['halim_episode'])?$meta['halim_episode']:$lastep;
    $runtime = !empty($meta['halim_runtime'])?$meta['halim_runtime']:'';
    $type = isset($args['type'])?$args['type']:'day';
    $show_info = isset($args['show_info'])?$args['show_info']:false;
    $show_view_count = isset($args['show_view_count'])?$args['show_view_count']:false;
    $lazyload = cs_get_option('halim_lazyload_image');

    ?>
    <div class="item post-<?php echo $post->ID; ?>">
        <a href="<?php the_permalink();?>" title="<?php echo esc_html($post->post_title); ?>">
            <div class="item-link">
                <?php if($lazyload) : ?>
                <img src="data:image/gif;base64,R0lGODlhAQABAAAAACH5BAEKAAEALAAAAAABAAEAAAICTAEAOw==" data-src="<?php echo esc_url(halim_image_display()) ?>" class="lazyload blur-up post-thumb" alt="<?php echo esc_html($post->post_title); ?>" title="<?php echo esc_html($post->post_title); ?>" />
                <?php else : ?>
                <img src="<?php echo esc_url(halim_image_display()) ?>" class="post-thumb" alt="<?php echo esc_html($post->post_title); ?>" title="<?php echo esc_html($post->post_title); ?>" />
                <?php endif; ?>
                <?php
                if(!empty($post->post_password)) {
                    echo '<span class="has_password"><i class="hl-lock"></i></span>';
                }
                if(HALIMHelper::is_status('is_trailer')){
                    echo '<span class="is_trailer">Trailer</span>';
                }  ?>
            </div>
            <h3 class="title"><?php echo esc_html($post->post_title); ?></h3>
            <?php if($org_title) echo '<p class="original_title">'.esc_html($org_title).'</p>'; ?>
        </a>
        <?php if($show_view_count) : ?>
            <div class="viewsCount"><?php echo halim_display_post_view_count($post->ID, $type) ?> <?php _e('view', 'halimthemes') ?></div>
        <?php endif; ?>
        <?php if($show_info == true) : ?>
            <span class="post_meta"><?php echo HALIMHelper::is_type('tv_series') ? $episode : $runtime; ?></span>
        <?php endif; ?>
    </div>