<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<nav class="bottom-nav hiddenx">
  <a href="<?php echo home_url(); ?>" class="bottom-nav__link">
    <!-- <i class="hl-home"></i> -->
    <i class="material-icons bottom-nav__icon">home</i>
    <span class="bottom-nav__text">Home</span>
  </a>
  <a href="#" class="bottom-nav__link bottom-nav__link--active">
    <i class="material-icons bottom-nav__icon">person</i>
    <span class="bottom-nav__text">Movies</span>
  </a>
  <a href="#" class="bottom-nav__link">
    <i class="material-icons bottom-nav__icon">devices</i>
    <span class="bottom-nav__text">TV-Series</span>
  </a>
  <a href="#" class="bottom-nav__link">
    <i class="material-icons bottom-nav__icon">search</i>
    <span class="bottom-nav__text">Search</span>
  </a>
  <a href="#" class="bottom-nav__link">
    <i class="material-icons bottom-nav__icon">settings</i>
    <span class="bottom-nav__text">Account</span>
  </a>
</nav>