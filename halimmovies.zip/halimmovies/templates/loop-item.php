<?php
	$meta = get_post_meta($post->ID, '_halim_metabox_options', true );
	$quality = $meta['halim_quality']??'';
	$org_title = $meta['halim_original_title']??'';
	$lastep = HALIMHelper::is_type('tv_series')
	? halim_add_episode_name_to_the_title(halim_get_last_episode($post->ID)) : '';
	$episode = $meta['halim_episode']??$lastep;
	$duration = $meta['halim_runtime']??'';
	$imdb_rating = $meta['halim_rating']??'';
	$is_slider = $args['is_slider']??false;
	$isTvSeries = HALIMHelper::is_type('tv_series');
	$layout = $args['layout']??'4col';
	$col = $layout == '4col' ?
	'col-md-3 col-sm-3 col-xs-6 ' : 'col-md-2 col-sm-4 col-xs-6 ';
	$tooltip = cs_get_option('halim_tooltip_post_info');
	$lazyload = cs_get_option('halim_lazyload_image');
	$post_content = apply_filters('the_content', $post->post_content);
	$post_categories = wp_get_post_categories($post->ID);
	$cats = $country = '';
	foreach($post_categories as $c){
	    $cat = get_category($c);
	    $cats .= '<span class=category-name>'.$cat->name.'</span>';
	}
	$countries = get_the_terms($post->ID, 'country');
	if(is_array($countries)){
	    foreach($countries as $ct){
	        $country .= '<span class=category-name>'.$ct->name.'</span>';
	    }
	}
	$post_password = '';

	$is_movie_class = !$isTvSeries ? ' mv' : '';
	?>
	<article class="<?php echo ($is_slider !== true) ? $col : ''; ?>thumb grid-item post-<?php echo $post->ID; ?>">
	    <div class="halim-item">
	        <a class="halim-thumb" href="<?php echo get_the_permalink($post->ID); ?>" title="<?php echo htmlspecialchars($post->post_title); ?>">
	            <?php if($lazyload) : ?>
	            <figure><img class="lazyload blur-up img-responsive" data-sizes="auto" data-src="<?php echo esc_url(halim_image_display()) ?>" alt="<?php echo htmlspecialchars($post->post_title); ?>" title="<?php echo htmlspecialchars($post->post_title); ?>"></figure>
	            <?php else: ?>
	            <figure><img class="img-responsive" src="<?php echo esc_url(halim_image_display()) ?>" alt="<?php echo htmlspecialchars($post->post_title); ?>" title="<?php echo htmlspecialchars($post->post_title); ?>"></figure>
	            <?php endif; ?>
	            <?php

					if(!empty($post->post_password)) {
						echo '<span class="has_password"><i class="hl-lock"></i></span>';
					}
	                if($quality) echo '<span class="status'.$is_movie_class.'">'.esc_html($quality).'</span>';
	                if(HALIMHelper::is_status('is_trailer')){
	                    echo '<span class="is_trailer"><i class="hl-play"></i> Trailer</span>';
	                } else {
	                    if($episode && $isTvSeries) echo '<span class="episode">'.esc_html($episode).'</span>';
	                }
	            ?>
	            <div class="icon_overlay"<?php if($tooltip) : ?>
	                    data-html="true" data-toggle="halim-popover" data-placement="top" data-trigger="hover" title="&lt;span class=film-title&gt;<?php echo htmlspecialchars($post->post_title); ?>&lt;/span&gt;" data-content="<?php echo $org_title ? '&lt;div class=org-title&gt;'.htmlspecialchars($org_title).'&lt;/div&gt;' : ''; ?>&lt;div class=film-meta&gt;&lt;div class=text-center&gt;<?php echo has_term('', 'release') ? '&lt;span class=released&gt;&lt;i class=hl-calendar>&lt;/i&gt; '.get_the_terms($post->ID, 'release')[0]->name.'&lt;/span&gt;' : ''; ?><?php echo $duration ? '&lt;span class=runtime&gt;&lt;i class=hl-clock>&lt;/i&gt; '.$duration.'&lt;/span&gt;' : ''; ?>&lt;/div&gt;&lt;div class=film-content&gt;<?php echo htmlspecialchars(wp_trim_words($post_content, 18)); ?>&lt;/div&gt;<?php echo $country ? '&lt;p class=category&gt;'.__('Country', 'halimthemes').': '.$country.'&lt;/p&gt;' : ''; ?>&lt;p class=category&gt;<?php _e('Genres', 'halimthemes'); ?>: <?php echo $cats; ?>&lt;/p&gt;&lt;/div&gt;"<?php endif; ?>>
	            </div>

	            <div class="halim-post-title-box">
	                <div class="halim-post-title <?php echo (!$org_title) ? 'title-2-line' : ''; ?>">
	                    <?php echo '<h2 class="entry-title">'.esc_html($post->post_title).'</h2>';
	                        if($org_title) echo '<p class="original_title">'.esc_html($org_title).'</p>';
	                    ?>
	                </div>
	            </div>
	        </a>
	    </div>
	</article>
