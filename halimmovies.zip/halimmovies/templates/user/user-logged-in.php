<?php
    global $current_user;
?>
<div class="user" id="pc-user-logged-in">
    <div class="dropdown">
        <a href="#" class="avt"><?php echo get_avatar( $current_user->ID, 40 ); ?></a>
        <a href="#" id="userInfo" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
            <span class="name"><?php echo $current_user->data->display_name; ?></span>
            <i class="hl-angle-down"></i>
        </a>
        <ul class="dropdown-menu" aria-labelledby="userInfo">
            <li><a href="<?php echo home_url()."/author/".get_the_author_meta('user_login', $current_user->ID); ?>"><i class="hl-user"></i> <?php _e('Profile', 'halimthemes'); ?></a></li>
            <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="hl-off"></i> <?php _e('Logout', 'halimthemes') ?></a></li>
        </ul>
    </div>
</div>
