<?php


function halim_get_actors($limit = 10)
{
    global $post;
    $html = '';
    $actors = get_the_terms($post->ID, 'actor');
    if(is_array($actors)){
        foreach(array_slice($actors, 0, $limit) as $actor){
            $html .= '<a href="'.home_url($actor->taxonomy . '/' . $actor->slug).'" title="'.$actor->name.'">'.$actor->name.'</a>';
        }
    }
    return $html;
}

function halim_get_country()
{
    global $post;
    $html = '';
    $country = get_the_terms($post->ID, 'country');
    if(is_array($country)){
        foreach($country as $ct){
            $html .= '<a href="'.home_url($ct->taxonomy . '/' . $ct->slug).'" title="'.$ct->name.'">'.$ct->name.'</a>';
        }
    }
    return $html;
}


function halim_get_directors()
{
    global $post;
    $html = '';
    $directors = get_the_terms($post->ID, 'director');
    if(is_array($directors)){
        foreach($directors as $director){
            if($director->name != '') {
                $html .= '<a class="director" href="'.home_url($director->taxonomy . '/' . $director->slug).'" title="'.$director->name.'">'.$director->name.'</a>';
            }
        }
    }
    return $html;
}


function halim_get_movie_title()
{
    global $post;

    $episode = get_query_var('halim_episode');
    if(isset($episode)){
        $eps_name = HALIMHelper::is_type('tv_series') ? __('episode', 'halimthemes').' '.$episode : '';
        $title = ($episode) ? $post->post_title.' '.$eps_name : $post->post_title;
    } else {
        $title = $post->post_title;
    }
    echo '<h1 class="entry-title"><a href="'.get_the_permalink().'" title="'.$post->post_title.'" class="tl">'.$title.'</a></h1>';
}

function halim_get_movie_detail($single = false)
{
    global $post;
    ob_start();
    $directors = get_the_terms($post->ID, 'director');
    if(is_array($directors)){

        echo '<p class="directors">';
        _e('Director', 'halimthemes');
        echo ':';
        foreach($directors as $director){
            if($director->name != '') {
                echo '<a class="director" href="'.home_url($director->taxonomy . '/' . $director->slug).'" title="'.$director->name.'">'.$director->name.'</a>';
            }
        }
        echo '</p>';
    }

    $country = get_the_terms($post->ID, 'country');
    if(is_array($country)){
        echo '<p class="actors">';
        _e('Country', 'halimthemes'); echo ':';
        foreach($country as $ct){
            echo '<a href="'.home_url($ct->taxonomy . '/' . $ct->slug).'" title="'.$ct->name.'">'.$ct->name.'</a>';
        }
        echo '</p>';
    }

    if($single){
        $meta = get_post_meta($post->ID, '_halim_metabox_options', true );
        $eps = isset($meta['halim_episode']) ? $meta['halim_episode'] : '';
        $duration = isset($meta['halim_runtime']) ? $meta['halim_runtime'] : '';
        if($eps) {
            echo '<p class="_episode">';
            _e('Episode', 'halimthemes');
            echo ':';
            echo '<span>'.$eps.'</span></p>';
        }
        if($duration)
        {
            echo '<p class="_showtime">';
            _e('Duration', 'halimthemes');
            echo ':';
            echo '<span>'.$duration.'</span></p>';
        }

        echo '<p class="genres">';
            _e('Genres', 'halimthemes'); echo ':'; the_category(', ');
        echo '</p>';

    }

    $actors = get_the_terms($post->ID, 'actor');
    if(is_array($actors)){
        echo '<p class="actors">';
        _e('Actors', 'halimthemes'); echo ':';
        foreach(array_slice($actors, 0, 10) as $actor){
            echo '<a href="'.home_url($actor->taxonomy . '/' . $actor->slug).'" title="'.$actor->name.'">'.$actor->name.'</a>';
        }
        echo '</p>';
    }
    $html = ob_get_clean();
    echo $html;
}
