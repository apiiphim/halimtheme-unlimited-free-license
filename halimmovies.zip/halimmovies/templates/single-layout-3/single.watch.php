<?php
    $episode         = get_query_var('halim_episode');
    $server          = get_query_var('halim_server');
    $sorter_modules  = cs_get_option('single_watch_module_sorter');
    $date            = explode(' ', esc_html($post->post_date))[0];
    $episode_slug = get_query_var('episode_slug');

    if (have_posts()): while (have_posts()): the_post();

        ?>

        <?php foreach($sorter_modules['enabled'] as $key => $module){ ?>

            <?php if($key == "ads_top_player"): ?>
                <div class="clearfix"></div>
                <?php dynamic_sidebar('halim-ad-above-player') ?>
                <div class="clearfix"></div>
            <?php endif; ?>

            <?php if($key == "player_box" ): ?>
                <?php do_action('halim_player_default', $post->ID); ?>
                <div class="clearfix"></div>
            <?php endif; ?>

            <?php if($key == "ads_bottom_player"): ?>
                <?php dynamic_sidebar('halim-ad-below-player') ?>
                <div class="clearfix"></div>
            <?php endif; ?>

            <?php if($key == "title_box" ): ?>
                <?php get_template_part('templates/title', 'block'); ?>
            <?php endif; ?>

            <?php if($key == "season_box" ): ?>
                <?php do_action('halim_movie_season_box', $post->ID); ?>
            <?php endif; ?>

            <?php if($key == "content_box"): ?>
                <?php do_action('halim_before_single_watch_content', $post->ID); ?>
                <div class="entry-content htmlwrap clearfix collapse <?php echo cs_get_option('post_content_display_watch_page') == 'visible' ? 'in' : ''; ?>" id="expand-post-content">
                    <article id="post-<?php echo $post->ID; ?>" class="item-content post-<?php echo $post->ID; ?>">
                        <?php the_content(); ?>
                    </article>
                </div>
                <?php do_action('halim_after_single_watch_content', $post->ID); ?>
            <?php endif; ?>

            <?php if($key == "download_box"): ?>
                  <?php do_action('halim_download_box', $post->ID); ?>
            <?php endif; ?>

            <?php if($key == "alternate_server"): ?>
                <?php do_action('halim_alternate_server_display', ['post_id' => $post->ID, 'server' => $server, 'episode_slug' => $episode_slug]); ?>
            <?php endif; ?>

            <?php if($key == "episode_list"): ?>
                <div class="clearfix"></div>
                <?php display_episodes_list($post->ID); ?>
                <div class="clearfix"></div>
            <?php endif; ?>

            <?php
            }
        endwhile;
    endif;

    if(cs_get_option('enable_fb_comment') == 1) : ?>
        <div class="htmlwrap fb-comment clearfix">
            <div class="fb-comments" data-href="<?php the_permalink(); ?>/" data-width="100%" data-mobile="true" data-colorscheme="dark" data-numposts="<?php echo cs_get_option('fb_comment_display'); ?>" data-order-by="<?php echo cs_get_option('fb_comment_order_by'); ?>" data-lazy="true"></div>
        </div>
    <?php endif;

    if ( cs_get_option('enable_site_comment') == 1 && comments_open()) :
        if(class_exists('WpdiscuzCore')) {
            comments_template();
        } else {
            echo '<div class="halim--notice">This theme requires the following plugin: <a href="https://wordpress.org/plugins/wpdiscuz/" rel="nofollow" target="_blank">wpDiscuz Comments</a></div>';
        }
    endif;

    if(cs_get_option('enable_disqus_comment') == 1) : ?>

        <div class="htmlwrap clearfix">
            <div id="disqus_thread"></div>
            <script>
                var disqus_shortname = '<?php echo cs_get_option('disqus_shortname'); ?>';
                (function() {
                    var dsq = document.createElement('script'); dsq.async = true;
                    dsq.src = '//' + disqus_shortname + '.disqus.com/embed.js';
                    (document.getElementsByTagName('head')[0] || document.getElementsByTagName('body')[0]).appendChild(dsq);
                })();
            </script>

        </div>
    <?php endif; ?>
    <div id="lightout"></div>
