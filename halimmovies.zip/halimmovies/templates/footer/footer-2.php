
</div>
</div><!--./End .container -->
    <?php if(cs_get_option('enable_footer_banner_ads')) : ?>
    	<div class="container">
		    <div class="a--d-wrapper" style="text-align: center; margin: 10px 0 -10px;">
		        <?php echo cs_get_option('footer_banner_ads'); ?>
		    </div>
    	</div>
    <?php endif; ?>
<div class="clearfix"></div>

<footer id="footer" class="clearfix">
	<div class="container footer-columns">
		<div class="row container">
			<?php dynamic_sidebar('footer'); ?>
		</div>
	</div>
</footer>

<div class="footer-credit">
	<div class="container credit">
		<div class="row container">
			<div class="col-xs-12 col-sm-4 col-md-6">
				<?php echo halim_footer_copyright(); ?>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-6 text-right pull-right">
				<p class="blog-info">
		            <?php echo (cs_get_option('footer_right_text') !== NULL) ? cs_get_option('footer_right_text') : bloginfo( 'name' );;
					?>
				</p>
			</div>
		</div>
	</div>
</div>

<div id="easy-top"></div>
<div class="modal-html"></div>
<?php wp_footer(); if (cs_get_option('footer_code')) echo cs_get_option('footer_code')."\n"; ?>
</body>
</html>