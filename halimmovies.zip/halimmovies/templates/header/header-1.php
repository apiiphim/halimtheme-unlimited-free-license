    <header id="header">
        <div class="container">
            <div class="row" id="headwrap">
                <div class="col-md-3 col-sm-6 slogan">
                    <?php if ( is_front_page() ) : ?>
                        <h1 class="site-title"><a class="logo" href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
                    <?php else : ?>
                        <p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></p>
                    <?php endif; ?>
                </div>
                <div class="col-md-5 col-sm-6 halim-search-form hidden-xs">
                    <div class="header-nav">
                        <div class="col-xs-12">
                            <form id="search-form-pc" name="halimForm" role="search" action="<?php echo esc_url(home_url('/')); ?>" method="GET">
                                <div class="form-group">
                                    <div class="input-group col-xs-12">
                                        <input id="search" type="text" name="s" value="<?php echo get_search_query(); ?>" class="form-control" placeholder="<?php cs_get_option('show_total_post_in_search_form') && wp_count_posts() ? printf(__('Search with %s movie...', 'halimthemes'), number_format(wp_count_posts()->publish)) : _e('Search', 'halimthemes'); ?>" autocomplete="off" required>
                                        <i class="animate-spin hl-spin4 hidden"></i>
                                    </div>
                                </div>
                            </form>
                            <ul class="ui-autocomplete ajax-results hidden"></ul>
                        </div>
                        <?php do_action('halim-after-search-form'); ?>
                    </div>
                </div>
                <div class="col-md-4 hidden-xs">
                    <?php
                        $enable_user_login_register = cs_get_option('enable_user_login_register');
                        if($enable_user_login_register || is_user_logged_in()){
                            $user = new HaLim\Ajax\Users\User();
                            $user->userAccess();
                        }
                    ?>
                </div>

            </div>
        </div>
    </header>
    <div class="navbar-container">
        <div class="container">
            <nav class="navbar halim-navbar main-navigation" role="navigation" data-dropdown-hover="<?php echo cs_get_option('hover_dropdown_menu'); ?>">
                <div class="navbar-header desktop-mode">
                    <button type="button" class="navbar-toggle collapsed pull-left" data-toggle="collapse" data-target="#halim" aria-expanded="false">
                        <span class="sr-only"><?php _e('Menu', 'halimthemes') ?></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <button id="userInfo" type="button" class="navbar-toggle-pc collapsed pull-right" data-toggle="dropdown" aria-expanded="true"
                    <?php echo !is_user_logged_in() ? 'onclick="openLoginModal();"' : ''; ?>>
                        <?php echo is_user_logged_in() ? '<i class="hl-user-circle"></i>' : '<i class="hl-login-1"></i>'; ?>
                    </button>

                    <button type="button" class="navbar-toggle collapsed pull-right expand-search-form" data-toggle="collapse" data-target="#search-form" aria-expanded="false">
                        <span class="hl-search" aria-hidden="true"></span>
                    </button>
                    <button type="button" class="toggle-pagination-pc navbar-toggle-pc collapsed pull-right">
                        <i class="hl-sort-name-up"></i>
                    </button>
                    <?php if(cs_get_option('disable_filter_movie') !== true) : ?>
                    <button type="button" class="navbar-toggle-pc collapsed pull-right" id="expand-filter-movie">
                        <i class="hl-equalizer"></i>
                    </button>
                    <?php endif; ?>
                    <button type="button" class="navbar-toggle-pc navbar-toggle-bookmark collapsed pull-right get-bookmark-on-mobile" data-toggle="modal" data-target="#bookmark-modal">
                        <i class="hl-bookmark" aria-hidden="true"></i>
                        <span class="count">0</span>
                    </button>
                    <?php if(is_user_logged_in()) : ?>
                    <ul class="dropdown-menu" aria-labelledby="userInfo">
                        <li><a href="<?php echo home_url()."/author/".get_the_author_meta('user_login', get_current_user_id()); ?>"><i class="hl-user"></i> <?php _e('Profile', 'halimthemes'); ?></a></li>
                        <li><a href="<?php echo wp_logout_url(home_url()); ?>"><i class="hl-off"></i> <?php _e('Logout', 'halimthemes') ?></a></li>
                    </ul>
                    <?php endif; ?>
                </div>
                <div class="collapse navbar-collapse" id="halim">
                    <?php
                        wp_nav_menu( array(
                            'depth'             => 2,
                            'theme_location'    => 'header_menu',
                            'menu_class'        => 'nav navbar-nav navbar-left',
                            'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                            'walker'            => new wp_bootstrap_navwalker())
                        );
                    ?>
                </div>
                <!-- /.navbar-collapse -->
            </nav>
            <div class="collapse navbar-collapse" id="search-form">
                <div id="mobile-search-form" class="halim-search-form"></div>
            </div>
        </div>
    </div>
<!-- /header -->
<div class="container">
    <?php if(cs_get_option('enable_header_banner_ads')) : ?>
    <div class="a--d-wrapper" style="text-align: center; margin: 10px 0;">
        <?php echo cs_get_option('header_banner_ads'); ?>
    </div>
    <?php endif; ?>
    <div class="row fullwith-slider">
        <?php if(is_home()) dynamic_sidebar('bs-slider') ?>
    </div>
</div>
<?php do_action('halim-header-area-before-container'); ?>
<div class="container">
    <div class="row container" id="wrapper">
        <?php
            if(cs_get_option('alphabet_filter')) get_template_part('templates/letter.tpl');
            if(!is_home()) get_template_part('templates/breadcrumb');
            if(cs_get_option('disable_filter_movie') !== true) get_template_part('templates/filter-movie');