<?php

	/**
	* Template Name: Filter Movies
	*/
	get_header();
?>
<main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
	<?php if ( is_active_sidebar( 'halim-ad-above-category' ) ) { ?>
	    <div class="a--d-wrapper" style="text-align: center; margin: 10px 0;">
	        <?php dynamic_sidebar( 'halim-ad-above-category' ); ?>
	    </div>
	<?php } ?>
	<section>
		<div class="section-bar is-tabs clearfix">
		   <h3 class="section-title">
			<span><?php _e('Lists films', 'halimthemes') ?></span>
		   </h3>
		</div>
		<div class="halim_box">
		<?php
			$wp_query = new WP_Query(get_filter_args());
			while($wp_query->have_posts()): $wp_query->the_post();
				get_template_part( 'templates/loop', 'item' );
			endwhile; wp_reset_postdata(); ?>
		</div>
		<div class="clearfix"></div>
		<?php halim_pagination(); ?>
	</section>
	<?php if ( is_active_sidebar( 'halim-ad-below-category' ) ) { ?>
	    <div class="a--d-wrapper" style="text-align: center; margin: 10px 0;">
	        <?php dynamic_sidebar( 'halim-ad-below-category' ); ?>
	    </div>
	<?php } ?>
</main><!--./End #primary -->
<?php get_sidebar(); get_footer(); ?>