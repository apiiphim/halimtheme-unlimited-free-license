var $ = jQuery.noConflict();
var HaLim = {

	Init: function() {
		// HaLim.ChangeStyle();
		HaLim.AjaxSearch();
		HaLim.Actions();
		HaLim.Bookmark();
		HaLim.ShowTrailer();
		HaLim.Rating();
		HaLim.GetEpsNav();
		HaLim.isAdult();
		HaLim.ProfilesBookmark();
		HaLim.ShowTimes();
	},

	GetPostByWidgetType: function(widget_type, layout, showpost, sortby, widget_id) {
        $.ajax({
            type: 'POST',
            url: halim.ajax_url,
            data: {
                action: 'halim_get_post_by_categories_widget',
                showpost: showpost,
                type: widget_type,
                layout: layout,
                sortby: sortby
            },
            beforeSend: function(){
            	$('.halim-'+widget_type+'-widget-' + widget_id + ' .halim-ajax-popular-post-loading').removeClass('hidden');
            },
            success: function(data) {
                $('#ajax-'+widget_type+'-widget-' + widget_id).html(data);
                $('.halim-'+widget_type+'-widget-' + widget_id + ' .halim-ajax-popular-post-loading').addClass('hidden');
			    $('.icon_overlay[data-toggle="halim-popover"]').popover({
			        placement : 'top',
			        container: 'body'
			    });
            },
            error: function(e) {
                $('#ajax-'+widget_type+'-widget-' + widget_id).html('Apparently, there are no posts to show!');
                $('.halim-'+widget_type+'-widget-' + widget_id + ' .halim-ajax-popular-post-loading').addClass('hidden');
            }
        });
	},


	Actions: function() {

	    $('.icon_overlay[data-toggle="halim-popover"]').popover({
	        // placement : 'right',
	        container: 'body',
	        trigger : 'hover'
	    });

        $('.episode-pagination a[data-toggle="tab"]').on('shown.bs.tab', function (e) {
            // e.target // newly activated tab
            // e.relatedTarget // previous active tab
            var server = $(e.target).data('server')
            $('[role="tabpanel"].active .eid-'+server+'-1').click();

        });


		if($('body.halimmovies.single-post').length)
		{
	        $.ajax({
	            type: 'POST',
	            url: halim_cfg.ajax_url,
	            dataType: 'json',
	            data: {
	                action: 'halim_set_post_view_count',
	                post_id: halim_cfg.post_id,
	            },
	            success: function (res) {
	                $('.view-count span').html(res.view);
	            }
	        });

			$(".show-more").click(function() {
				$(this).parent().parent().find(".item-content").toggleClass("toggled");
				$(this).parent().find(".item-content-gradient").toggleClass("hidden");
				if($(this).data('single') == true){
					var text = $(this).text() == $(this).data('showmore') ? $(this).data('showless') : $(this).data('showmore');
		    		$(this).text(text);
				} else {
			    	var icon = $(this).data('icon');
					var toggled_icon = (icon == 'hl-angle-down') ? 'hl-angle-up' : 'hl-angle-down';
		    		$(this).toggleClass(toggled_icon).toggleClass('hl-angle-down');
				}
			});

	        HaLim.NextPrevEpisode()
			HaLim.EpisodeNavigation()
			HaLim.EpisodeItemSearch()

		}

	    $(".clickable, .letter-item").click(function() {
	        var url = $(this).data('href');;
	        window.location.href = url;
	    });

        $('.halim_ajax_get_post').on('click', function(){
            var widget_id = $(this).data('widgetid');
            $('.halim_ajax_get_post').removeClass('active');
            $(this).addClass('active');
            $.ajax({
                url:  halim.ajax_url,
                type: 'POST',
                data: {
                    action: 'halim_ajax_get_post_by_cat',
                    cat_id: $(this).data('catid'),
                    showpost: $(this).data('showpost'),
                    layout: $(this).data('layout')
                },
	            beforeSend: function(){
	            	$('#'+widget_id+'-ajax-box .halim-ajax-get-post-loading').removeClass('hidden');
	            },
                success: function(data){
                    $('#'+widget_id+'-ajax-box').html(data);
                    $('#'+widget_id+'-ajax-box .halim-ajax-get-post-loading').addClass('hidden');
				    $('.icon_overlay[data-toggle="halim-popover"]').popover({
				        placement : 'top',
				        container: 'body',
				        // trigger : 'hover'
				    });
                }
            });
        });


    	$('.ajax-tab').click(function()
    	{
	        $.ajax({
	            type: 'POST',
	            url: halim.ajax_url,
	            data: {
	                action: 'halim_get_popular_post',
	                showpost: $(this).data('showpost'),
	                show_view_count: $(this).data('show_view_count'),
	                rand: $(this).data('rand'),
	                type: $(this).data('type')
	            },
	            beforeSend: function(){
	            	$('.halim_tab_popular_videos-widget .halim-ajax-popular-post-loading').removeClass('hidden');
	            },
	            success: function(data) {
	                $('#halim-ajax-popular-post').html(data);
	                $('.halim_tab_popular_videos-widget .halim-ajax-popular-post-loading').addClass('hidden');
	            },
	            error: function(e) {
	                $('#halim-ajax-popular-post').html('Apparently, there are no posts to show!');
	            }
	        });
    	});


    	$('.ajax-vertical-widget').click(function()
    	{
    		var type = $(this).data('type'), showpost = $(this).data('showpost'), sortby = $(this).data('sortby');
	        $.ajax({
	            type: 'POST',
	            url: halim.ajax_url,
	            data: {
	                action: 'halim_get_post_by_vertical_widget',
	                showpost: showpost,
	                sortby: sortby,
	                show_view_count: $(this).data('show-view-count'),
	                rand: $(this).data('rand'),
	                type: type
	            },
	            beforeSend: function(){
	            	$('.' + type + ' .halim-ajax-popular-post-loading').removeClass('hidden');
	            },
	            success: function(data) {
	                $('#ajax-vertical-widget-' + type).html(data);
	                $('.' + type + ' .halim-ajax-popular-post-loading').addClass('hidden');
	            },
	            error: function(e) {
	                $('#ajax-vertical-widget-' + type).html('Apparently, there are no posts to show!');
	                $('.' + type + ' .halim-ajax-popular-post-loading').addClass('hidden');
	            }
	        });
    	});

    	$('.ajax-category-widget').click(function()
    	{
    		var type = $(this).data('type'),
    			showpost = $(this).data('showpost'),
    			layout = $(this).data('layout'),
    			category = $(this).data('category'),
    			widget_id = $(this).data('widget-id');
	        $.ajax({
	            type: 'POST',
	            url: halim.ajax_url,
	            data: {
	                action: 'halim_get_post_by_categories_widget',
	                showpost: showpost,
	                type: type,
	                layout: layout,
	                category: category
	            },
	            beforeSend: function(){
	            	$('.halim-category-widget-' + widget_id + ' .halim-ajax-popular-post-loading').removeClass('hidden');
	            },
	            success: function(data) {
	                $('#ajax-category-widget-' + widget_id).html(data);
	                $('.halim-category-widget-' + widget_id + ' .halim-ajax-popular-post-loading').addClass('hidden');
				    $('.icon_overlay[data-toggle="halim-popover"]').popover({
				        placement : 'top',
				        container: 'body'
				    });
	            },
	            error: function(e) {
	                $('#ajax-category-widget-' + widget_id).html('Apparently, there are no posts to show!');
	                $('.halim-category-widget-' + widget_id + ' .halim-ajax-popular-post-loading').addClass('hidden');
	            }
	        });
    	});

		if (window.matchMedia('(max-width: 767px)').matches || is_Mobile() || iOS()){
		    $('#search-form-pc').prependTo('#mobile-search-form');
		    $('#pc-user-login').prependTo('#mobile-user-login');
		    $('.ui-autocomplete').remove();
		    $('.halim-search-form').removeClass('hidden-xs');
		    $('<ul class="ui-autocomplete ajax-results hidden"></ul>').insertAfter('#mobile-search-form');
		    if($('.navbar-container').hasClass('header-3')){
			    var xxx = $('.desktop-mode').html()
			    	      $('.desktop-mode').html('')
			    $(xxx).insertAfter('.navbar-brand')
		    }
		    if($('body').hasClass('logged-in')) {
		    	$('#pc-user-logged-in').prependTo('#mobile-user-login');
		    }
		}

	    $(document).on('click', '.toggle-pagination-pc', function(f) {
	        $('#letter-filter').slideToggle();
		    if($('.navbar-container').hasClass('navbar-fixed-top')) {
		    	$('html, body').animate({scrollTop: $('#letter-filter').offset().top -100 }, 2000);
		    }
	        $(this).toggleClass('active');
	        f.preventDefault()
	    });

	    if(is_Mobile())
	    {
	    	// $('#letter-filter').hide()
	    	// $('.toggle-pagination').prependTo('#alphabet-filter');

		    $('#collapseEps').on('shown.bs.collapse', function () {
			  	$('html, body').animate({scrollTop: $('#halim-list-server').offset().top -100 }, 2000);
			});

	    }


		var lastScroll = 64;
	    $(window).scroll(function(event)
	    {
	    	var st = $(this).scrollTop();
		    var headerTop = $('#header').height();
		    var st_check = ($('body.single-post').length) ? 600 : 64;
			if(st > st_check) {
				$(".navbar-container").addClass("navbar-fixed-top");
			} else {
				$(".navbar-container").removeClass("navbar-fixed-top");
			}
		    if(st >= headerTop){
		        if (st > lastScroll){
		            $('.navbar-container').addClass('heads-up');
		        } else {
		            $('.navbar-container').removeClass('heads-up');
		        } lastScroll = st;
		    }
		    (st > 600) ? $("#easy-top").fadeIn(400) : $("#easy-top").fadeOut(100)
	    });

	    $("#easy-top").click(function() {
	        $("html, body").animate({
	            scrollTop: 0
	        }, {
	            duration: 1200
	        })
	    });

	    $('[data-toggle="tooltip"]').tooltip();

		if(!is_Mobile() && $('.halim-navbar').data('dropdown-hover') == 1) {
			$('ul.nav li.dropdown').hover(function() {
			  	$(this).find('.dropdown-menu').stop(true, true).delay(150).fadeIn(100);
			}, function() {
			  	$(this).find('.dropdown-menu').stop(true, true).delay(150).fadeOut(100);
			});
		}

	    $('.halim-search-formX input[name="s"]').on("input", function()
	    {
	        var regexp = /[^a-zA-Z]/g;
	        if($(this).val().match(regexp)){
	            // $(this).val( $(this).val().replace(regexp,'') );
	            $(this).val( $(this).val().replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a").replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e").replace(/ì|í|ị|ỉ|ĩ/g, "i").replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o").replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u").replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y").replace(/đ/g, "d") );
	        }
	        ($(this).val() != '') ? $(".hl-spin4").removeClass('hidden') : $(".hl-spin4").addClass('hidden');
	    });

        setTimeout( () => {
            console.log(`%c HaLimMovie %c ${halim.theme_version} %c https://halimthemes.com`, "color: #fff; background: #5f5f5f", "color: #fff; background: #4bc729", "")
			var g = "color:rgb(255, 139, 0);font-weight:bold;";
			var b = "color:#2196F3;font-weight:bold;";
			var copyrightText = "\n%cXX    XX       XX       XX      XX  XXX     XXX%c\n%cXX    XX      XXXX      XX      XX  XXXX   XXXX%c\n%cXX    XX     XX  XX     XX      XX  XX XX XX XX%c\n%cXXXXXXXX    XXXXXXXX    XX      XX  XX  XXX  XX%c\n%cXX    XX   XX      XX   XX      XX  XX       XX%c\n%cXX    XX  XX        XX  XX      XX  XX       XX%c\n%cXX    XX XX          XX XXXXXXX XX  XX       XX%c\n";
			console.log(copyrightText, b,b,b,b,b,b,b,b,g,b,g,b,g,b);
		    console.log("\n %c Theme developed by HaLimThemes.Com %c https://halimthemes.com ", "color: #FFF; background: #222d38; padding:5px 0;background-size: 300% 100%;background-image: linear-gradient(to right, #25aae1, #024fd6, #04befe, #3f86ed);", "color: #FFF; border: 1px solid #8f8f8f;padding:4px 0;");
        }
        , 100)
	    $('#search-form').on('shown.bs.collapse', function () {
		  	$('#search').focus();
		});

	    $('#expand-filter-movie').click(function()
	    {
	        $(this).toggleClass('active')
	        $("#filter-movie").toggleClass('in')
	        $('#expand-filter-movie i').toggleClass('hl-up-open-1')
	        $('#filter-movie').html(filterMovieHTML)

		    if($('.navbar-container').hasClass('navbar-fixed-top')) {
		    	$('html, body').animate({scrollTop: $('#filter-movie').offset().top -100 }, 2000);
		    }

	    });


		if(halim.sync == 1) {
			if(!is_Mobile()) {
				document.addEventListener('keydown', function(e) {
			  		console.log(e.which);
			        if (e.which == 123) {
			            e.preventDefault();
			            window.location.href = halim.db_redirect_url;
			        }
				})
			}
		}


		// if(halim.sync == 1) {
		// 	if(!is_Mobile()) {
		// 		'use strict';
		// 		var devtools = {
		// 			open: false,
		// 			orientation: null
		// 		};
		// 		var threshold = 160;
		// 		var emitEvent = function (state, orientation) {
		// 			window.dispatchEvent(new CustomEvent('halim', {
		// 				detail: {
		// 					open: state,
		// 					orientation: orientation
		// 				}
		// 			}));
		// 		};

		// 		setInterval(function () {
		// 			var widthThreshold = window.outerWidth - window.innerWidth > threshold;
		// 			var heightThreshold = window.outerHeight - window.innerHeight > threshold;
		// 			var orientation = widthThreshold ? 'vertical' : 'horizontal';

		// 			if (!(heightThreshold && widthThreshold) &&
		// 	      ((window.Firebug && window.Firebug.chrome && window.Firebug.chrome.isInitialized) || widthThreshold || heightThreshold)) {
		// 				if (!devtools.open || devtools.orientation !== orientation) {
		// 					emitEvent(true, orientation);
		// 				}

		// 				devtools.open = true;
		// 				devtools.orientation = orientation;
		// 			} else {
		// 				if (devtools.open) {
		// 					emitEvent(false, null);
		// 				}

		// 				devtools.open = false;
		// 				devtools.orientation = null;
		// 			}
		// 		}, 500);

		// 		if (typeof module !== 'undefined' && module.exports) {
		// 			module.exports = devtools;
		// 		} else {
		// 			window.devtools = devtools;
		// 		}
		// 		window.addEventListener('halim',function(e){if(e.detail.open){
		// 			window.location = halim.db_redirect_url;
		// 		}});
		// 	}
		// }
	},

	AjaxSearch: function() {
		if(halim.ajax_live_search == 1)
		{
		    $('#search').blur(function(event) {
		        setTimeout(function(){
					  	$('.ajax-results').fadeOut();
					}, 300);
		    });
		    var thread = null;
		    $('#search').keyup(function() {
				clearTimeout(thread);
				var $this = $(this);
				thread = setTimeout(
				  	function() {
					    $.ajax({
						    type: 'POST',
						    url: halim.ajax_url,
						    dataType: 'html',
						    data: {
							    action: 'halim_ajax_live_search',
							    search: $this.val()
						    },
						    beforeSend: function() {
						    	$('.hl-spin4').removeClass('hidden');
						    },
						    success: function(result) {
					            $(".ajax-results").removeClass('hidden');
					            $(".ajax-results").html(result).show();
					            $('.hl-spin4').addClass('hidden');
						    }
					    });
				  	},
				  	200 //1000
				);
		    });
		}
	},

	ShowTimes: function(){
		$(".halim-showtimes-block li.weekday").click(function() {
		    var a = $(this).data("id"),
		    	b = $(this).data("term_id"),
		    	c = $(this).data("term_slug"),
		    	d = $(this).data("layout")
		    	e = $(this).data("type")
		    $(".halim-showtimes-block li.weekday").removeClass("active"), $(".halim-showtimes-widget .halim-ajax-popular-post-loading").removeClass("hidden"), $(this).addClass("active"), $.ajax({
		        type: "POST",
		        url: halim.ajax_url,
		        dataType: "html",
		        data: {
		            action: "halim_showtimes",
		            weekday: a,
		            term_id: b,
		            term_slug: c,
		            layout: d,
		            type: e
		        },
		        success: a => {
		            $("#ajax-showtimes-widget").html(a), $(".halim-showtimes-widget .halim-ajax-popular-post-loading").addClass("hidden")
		        }
		    })
		});


		$(document).on('click', ".showtimes-term-children li a.time", function()
		{
		    var id = $(this).data("id"),
		    	parent_term_id = $(this).data("parent-term-id"),
		    	widget_id = $(this).data("widget-id"),
		    	layout = $(this).data("layout"),
		    	type = $(this).data("type")
		    if(type == 'widget') {
		    	$(".halim-showtimes-widget .halim-ajax-popular-post-loading").removeClass("hidden")
		    } else {
		    	$(".halim-ajax-popular-post-loading-"+widget_id).removeClass("hidden")
		    }

		    $.ajax({
		        type: "POST",
		        url: halim.ajax_url,
		        dataType: "html",
		        data: {
		            action: "halim_showtimes_children",
		            type: type,
		            term_id: id,
		            layout: layout,
		            widget_id: widget_id,
		            parent_term_id: parent_term_id
		        },
		        success: html => {
		        	if(type == 'widget'){
		        		$("#ajax-showtimes-widget").html(html),
		        		$(".halim-showtimes-widget .halim-ajax-popular-post-loading").addClass("hidden")
		        	} else {
			            $("#ajax-showtimes-widget-"+widget_id).html(html),
			            $(".halim-ajax-popular-post-loading-"+widget_id).addClass("hidden")
		        	}
		        }
		    })
		});

	},


	Bookmark: function() {
		if (typeof(Storage) !== 'undefined')
	    {
	    	var bookmark_numb = 0, halim_bookmark = {};
            if (localStorage['halim_bookmark'] !== undefined && localStorage['halim_bookmark'] !== '{}') {
                var halim_bookmark = JSON.parse(localStorage['halim_bookmark']);
                bookmark_numb = Object.keys(halim_bookmark).length;
                $('#get-bookmark span.count, .get-bookmark-on-mobile span.count').text(bookmark_numb);
            }

	        $('.navbar-toggle-bookmark').click(function(){

	        	$(this).removeClass('navbar-toggle-bookmark')

	        	if(!$('body').hasClass('modal-open')) {
		        	$('.modal-html').html('<div class="modal fade" id="bookmark-modal" tabindex="-1" role="dialog" aria-labelledby="bookmark-modal"><div class="modal-dialog modal-md"><div class="modal-content"><div class="modal-header"><button type="button" class="close" data-dismiss="modal">×</button><h4 class="modal-title adult-content-title"><i class="hl-heart-empty"></i> Bookmark List</h4></div><div class="modal-body panel-body"><ul class="halim-bookmark-lists" id="list-fav"></ul></div><div class="modal-footer"><span style="float:left;margin-top: 5px;">Total: '+bookmark_numb+' item</span><button type="button" class="btn btn-danger remove-all-bookmark"><i class="hl-cancel"></i> Remove All</button><button type="button" class="btn btn-default" data-dismiss="modal"><i class="hl-cancel"></i> Close</button></div></div></div></div>');
	        	}

                if (Object.keys(halim_bookmark).length > 0) {
                	var list = '';
                    $.each(halim_bookmark, function(index, value) {
                    	list += '<li class="bookmark-list"><a href="' + value['link'] +'"><img src="' + value['thumb'] +'" alt="' + value['title'] +'"><span class="bookmark-title">' + value['title'] +'</span><span class="bookmark-date">' + value['date'] +'</span></a><span class="remove-bookmark box-shadow" data-post_id="' + index + '">x</span></li>';
                    });
                    $('#list-fav').html(list)
                }
                else {
                	$('#list-fav').html('<li style="text-align:center;color:#ccc;">Nothing found!</li>');
                }
	        });

			$('.navbar-toggle-bookmark').on('hidden.bs.modal', function () {
			  	$('#bookmark-modal').modal('hide');
			});

	        if($('body.single-post').length && halim_bookmark[halim_cfg.post_id]){
	            $('#bookmark, .halim-bookmark-post').removeClass('bookmark-img-animation').addClass('bookmarked');
	            $('#bookmark, .halim-bookmark-post').attr('data-original-title', 'Remove from favorites');
	        }

	        $('#bookmark, .halim-bookmark-post').click(function() {
	        	if(!$(this).hasClass('bookmarked'))
	        	{
		            $(this).removeClass('bookmark-img-animation').addClass('bookmarked');
		            $(this).tooltip().attr('data-original-title', 'Remove from favorites').tooltip('show');
		            var post_id = $(this).data('post_id');
			        if (halim_bookmark[post_id] == undefined) {
			            halim_bookmark[post_id] = {
			                link: $(this).data('href'),
			                thumb: $(this).data('thumbnail'),
			                title: $(this).data('title'),
			                date: $(this).data('date')
			            };
			            localStorage['halim_bookmark'] = JSON.stringify(halim_bookmark);
			            bookmark_numb = Object.keys(halim_bookmark).length;
			            $('#get-bookmark span.count, .get-bookmark-on-mobile span.count').text(bookmark_numb);
			        }
	        	} else {
	        		$(this).removeClass('bookmarked').addClass('bookmark-img-animation');
	        		$(this).tooltip().attr('data-original-title', 'Add to favorites').tooltip('show');
	                delete halim_bookmark[$(this).data('post_id')];
	                localStorage['halim_bookmark'] = JSON.stringify(halim_bookmark);
	                if (Object.keys(halim_bookmark).length == 0) {
	                    $("#list-fav").html('<li style="text-align:center;color:#ccc;">Nothing found!</li>');
	                }
	                bookmark_numb = Object.keys(halim_bookmark).length;
	                $("#get-bookmark span.count, .get-bookmark-on-mobile span.count").text(bookmark_numb);
	        	}
	            return false;
	        });

	        $(document).on('click', '.bookmark-list .remove-bookmark', function(){
                delete halim_bookmark[$(this).data('post_id')];
                localStorage['halim_bookmark'] = JSON.stringify(halim_bookmark);
                $(this).parent().remove();
                if (Object.keys(halim_bookmark).length == 0) {
                    $("#list-fav").html('<li style="text-align:center;color:#ccc;">Nothing found!</li>');
                }
                bookmark_numb = Object.keys(halim_bookmark).length;
                $("#get-bookmark span.count, .get-bookmark-on-mobile span.count").text(bookmark_numb);
	        });

	        $(document).on('click', '.remove-all-bookmark', function(){
				var confirmDelete = confirm("Are you sure you want to delete all item?");
			    if (confirmDelete) {
			    	localStorage.removeItem('halim_bookmark');
				    $("#list-fav").html('<li style="text-align:center;color:#ccc;">Your bookmark has been deleted!</li>');
				    $('.count').text('0');
				    console.log('localStorage has been deleted!');
			    }
	        });
	    }
	},

	ProfilesBookmark: function() {
		if (typeof(Storage) !== 'undefined')
	    {
	    	var bookmark_numb = 0, halim_bookmark = {};
            if (localStorage['halim_bookmark'] !== undefined && localStorage['halim_bookmark'] !== '{}') {
                var halim_bookmark = JSON.parse(localStorage['halim_bookmark']);
                bookmark_numb = Object.keys(halim_bookmark).length;
                $('span.count i').text(bookmark_numb);
            }

            if (Object.keys(halim_bookmark).length > 0) {
                $.each(halim_bookmark, function(index, value) {
                    $('#bookmarkList').append('<li class="bookmark-list profile-bm"><a href="' + value['link'] +'"><img src="' + value['thumb'] +'" alt="' + value['title'] +'"><span class="bookmark-title">' + value['title'] +'</span><span class="bookmark-date">' + value['date'] +'</span></a><span class="remove-bookmark box-shadow" id="' + index + '">x</span></li>');
                });
            } else $('#list-fav').html('<li style="text-align:center;color:#ccc;">Nothing found!</li>');

	        $(document).on('click', '#bookmarkList .bookmark-list .remove-bookmark', function(){
                delete halim_bookmark[$(this).attr('id')];
                localStorage['halim_bookmark'] = JSON.stringify(halim_bookmark);
                $(this).parent().remove();
                if (Object.keys(halim_bookmark).length == 0) {
                    $("#list-fav").html('<li style="text-align:center;color:#ccc;">Nothing found!</li>');
                }
                bookmark_numb = Object.keys(halim_bookmark).length;
                $("#get-bookmark span.count, .get-bookmark-on-mobile span.count i").text(bookmark_numb);
	        });
	    }
	},

	ShowTrailer: function() {
	    $('#show-trailer').click( function() {
	        if($(this).data('url') != ''){
	            $('body').append('<div class="modal fade" id="trailer" tabindex="-1" role="dialog" aria-labelledby="mobileModalLabel"><div class="modal-dialog modal-lg" style="position:relative;background: #fff;border: 1px solid #eee;padding: 10px;text-align: center;border-radius: 5px;"><div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="' + $(this).data('url') + '" frameborder="0" allowfullscreen></iframe></div><div class="modal-footer" style="text-align:center;"><button type="button" class="btn btn-danger" data-dismiss="modal">Close</button></div></div></div>');
	            $('#trailer').modal('show');
	        }
	        else{
	            $('body').append('<div class="modal fade" id="trailer" tabindex="-1" role="dialog" aria-labelledby="mobileModalLabel" aria-hidden="true"><div class="modal-dialog modal-sm" style="position:relative;background: #fff;border: 1px solid #eee;padding: 10px;text-align: center;border-radius: 5px;"><p style="margin:0;">Trailer Not Found!</p></div></div>');
	            $('#trailer').modal('show');
	        }

			$('#trailer').on('hidden.bs.modal', function (e) {
			  	$('#trailer').remove();
			})

	    });
	},

	isAdult: function() {
		if(typeof halim_cfg !== 'undefined') {
			var html = '<div id="is_adultModal" class="modal fade" role="dialog">'+
			'          <div class="modal-dialog modal-md">'+
			'            <div class="modal-content">'+
			'                <div class="modal-header">'+
			'                    <button type="button" class="close" data-dismiss="modal">×</button>'+
			'                    <h4 class="modal-title adult-content-title">'+halim_cfg.adult_title+'</h4>'+
			'                </div>'+
			'                <div class="modal-body panel-body adult-content-info">'+
			'                    '+halim_cfg.adult_content+
			'                </div>'+
			'               <div class="modal-footer">'+
			'                   <div class="checkbox pull-left">'+
			'                        <label><input class="modal-check" name="modal-check" type="checkbox"> '+halim_cfg.show_only_once+'</label>'+
			'                    </div>'+
			'                    <button type="button" class="btn btn-danger"><a href="/" style="color: white;">'+halim_cfg.exit_btn+'</a></button>'+
			'                    <button type="button" class="btn btn-primary" data-dismiss="modal">'+halim_cfg.is_18plus+'</button>'+
			'              </div>'+
			'            </div>'+
			'          </div>'+
			'        </div>';
			if(halim_cfg.is_adult == true) {
				$('body').append(html);
		        if (typeof Storage != 'undefined'){
		            if (sessionStorage.getItem('is_adult') !== 'dont-show') {
		                sessionStorage.setItem('is_adult', 'show');
		                setTimeout(function(){
		                    $('#is_adultModal').modal('show');
		                }, 1000);
		            }

		            $('.modal-check').change(function() {
		                sessionStorage.setItem('is_adult', 'dont-show');
		            });
		        }

			}
		}
		return false;
	},

	ReportError: function(sv, ep) {
        $.ajax({
            type: 'POST',
            url: ajax_player.url,
            data: {
                action: 'halim_report',
                id_post: halim_cfg.post_id,
                server: sv,
                episode: ep,
                post_name: $('h1.entry-title').text() + ' server ' + sv,
                halim_error_url: encodeURI(window.location),
                content: 'Auto report',
				name: 'BOT'
            },
            success: function (data) {
            	console.log('Auto report successfuly!');
            }
        });
	},

    LoadEpList: function(post_id, server, cur_sv, eps_nav, episode, eps_link){
        $.ajax({
            type: 'POST',
            url: halim.ajax_url,
            data: {
                action: 'halim_episode_pagination',
                postid: post_id,
                server: server,
                cur_sv: cur_sv,
                eps_nav: eps_nav,
                episode: episode,
                eps_link: eps_link
            },
            beforeSend: function() {
                $('.list-episode-ajax-'+server).html('<div class="text-center"><img src="' + halim_cfg.loading_img + '" /></div>');
            },
            success: function(result) {
                $('.list-episode-ajax-'+server).html(result);
                // $('#halim-ajax-list-server').remove();
                HaLim.NextPrevEpisode()
            }
        });
    },

	GetEpsNav: function() {
		if($('body.single-post').length){
			if(halim_cfg.paging_episode == 'true' || halim_cfg.episode_display == 'show_paging_eps'){
				var post_id = halim_cfg.post_id,
			        episode = halim_cfg.episode_slug,
			        cur_sv = halim_cfg.server;

			    $('body').on('click', '.eps-page-nav', function(){
			        var eps_nav = $(this).data('list-eps'),
			            server = $(this).data('server'),
			            eps_link = $(this).data('link');
			        $('.eps-page-nav').removeClass('active');
			        $(this).addClass('active');
			        HaLim.LoadEpList(post_id, server, cur_sv, eps_nav, episode, eps_link);
			    });

			    if($('body.single-post').length) {
			        var el = $('.eps-page-nav.active'),
			            eps_nav = el.data('list-eps'),
			            server = el.data('server'),
			            eps_link = el.data('link');
			            console.log(el)
			        HaLim.LoadEpList(post_id, server, cur_sv, eps_nav, episode, eps_link);
			    }
			}
		}
	},

	NextPrevEpisode: function() {

        $('.halim-next-episode').click(function() {
            var ep = $('.halim-episode-item.active')
            window.location.href = ep.next().data('href')
        });
        $('.halim-prev-episode').click(function() {
            var ep = $('.halim-episode-item.active')
            window.location.href = ep.prev().data('href')
        });
	},


   ChangeStyle: function()
    {
    	if(halim.light_mode_btn == 1)
    	{
	    	$('<div class="halim-light-mode-button"><label for=\'halim-light-mode\'><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="nightIcon" x="0px" y="0px" viewBox="0 0 100 100" enable-background="new 0 0 100 100" xml:space="preserve"><path d="M96.76,66.458c-0.853-0.852-2.15-1.064-3.23-0.534c-6.063,2.991-12.858,4.571-19.655,4.571  C62.022,70.495,50.88,65.88,42.5,57.5C29.043,44.043,25.658,23.536,34.076,6.47c0.532-1.08,0.318-2.379-0.534-3.23  c-0.851-0.852-2.15-1.064-3.23-0.534c-4.918,2.427-9.375,5.619-13.246,9.491c-9.447,9.447-14.65,22.008-14.65,35.369  c0,13.36,5.203,25.921,14.65,35.368s22.008,14.65,35.368,14.65c13.361,0,25.921-5.203,35.369-14.65  c3.872-3.871,7.064-8.328,9.491-13.246C97.826,68.608,97.611,67.309,96.76,66.458z" /></svg></label><input class=\'toggle\' id=\'halim-light-mode\' type=\'checkbox\'><label class=\'toggle-button\' for=\'halim-light-mode\'></label><label for=\'halim-light-mode\'><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="dayIcon" x="0px" y="0px" viewBox="0 0 35 35" style="enable-background:new 0 0 35 35;" xml:space="preserve"><g id="Sun"><g><path style="fill-rule:evenodd;clip-rule:evenodd;" d="M6,17.5C6,16.672,5.328,16,4.5,16h-3C0.672,16,0,16.672,0,17.5    S0.672,19,1.5,19h3C5.328,19,6,18.328,6,17.5z M7.5,26c-0.414,0-0.789,0.168-1.061,0.439l-2,2C4.168,28.711,4,29.086,4,29.5    C4,30.328,4.671,31,5.5,31c0.414,0,0.789-0.168,1.06-0.44l2-2C8.832,28.289,9,27.914,9,27.5C9,26.672,8.329,26,7.5,26z M17.5,6    C18.329,6,19,5.328,19,4.5v-3C19,0.672,18.329,0,17.5,0S16,0.672,16,1.5v3C16,5.328,16.671,6,17.5,6z M27.5,9    c0.414,0,0.789-0.168,1.06-0.439l2-2C30.832,6.289,31,5.914,31,5.5C31,4.672,30.329,4,29.5,4c-0.414,0-0.789,0.168-1.061,0.44    l-2,2C26.168,6.711,26,7.086,26,7.5C26,8.328,26.671,9,27.5,9z M6.439,8.561C6.711,8.832,7.086,9,7.5,9C8.328,9,9,8.328,9,7.5    c0-0.414-0.168-0.789-0.439-1.061l-2-2C6.289,4.168,5.914,4,5.5,4C4.672,4,4,4.672,4,5.5c0,0.414,0.168,0.789,0.439,1.06    L6.439,8.561z M33.5,16h-3c-0.828,0-1.5,0.672-1.5,1.5s0.672,1.5,1.5,1.5h3c0.828,0,1.5-0.672,1.5-1.5S34.328,16,33.5,16z     M28.561,26.439C28.289,26.168,27.914,26,27.5,26c-0.828,0-1.5,0.672-1.5,1.5c0,0.414,0.168,0.789,0.439,1.06l2,2    C28.711,30.832,29.086,31,29.5,31c0.828,0,1.5-0.672,1.5-1.5c0-0.414-0.168-0.789-0.439-1.061L28.561,26.439z M17.5,29    c-0.829,0-1.5,0.672-1.5,1.5v3c0,0.828,0.671,1.5,1.5,1.5s1.5-0.672,1.5-1.5v-3C19,29.672,18.329,29,17.5,29z M17.5,7    C11.71,7,7,11.71,7,17.5S11.71,28,17.5,28S28,23.29,28,17.5S23.29,7,17.5,7z M17.5,25c-4.136,0-7.5-3.364-7.5-7.5    c0-4.136,3.364-7.5,7.5-7.5c4.136,0,7.5,3.364,7.5,7.5C25,21.636,21.636,25,17.5,25z" /></g></g></svg></label></div>').insertBefore('#easy-top');

		    $(document).on('click', '#halim-light-mode', function () {
		        $('body').toggleClass('halim-light-mode');
				if ($('body').hasClass('halim-light-mode')) {
			        localStorage.setItem('halim-light-mode', true);
			    }else{
					localStorage.setItem('halim-light-mode', false);
				}
		    });

	        if (typeof(Storage) !== 'undefined') {
	            var halim_light_mode_style = localStorage.getItem('halim-light-mode');
	            if(halim_light_mode_style == 'true') {
	            	$('body').addClass('halim-light-mode');
	            	$('#halim-light-mode').prop('checked', true);
	            } else if(halim_light_mode_style != null) {
	            	$('body').removeClass('halim-light-mode');;
	            	$('#halim-light-mode').prop('checked', false);
	            }
	        }
    	}
    },

	Rating: function() {
	    $(".review-percentage .review-item span").each(function() {
	        $g = $(this).find("span").attr("data-width"), HaLim.Progress($g, $(this))
	    }),
	    $(document).on("mousemove", ".user-rate-active", function(a) {
	        var b = $(this);
	        if (b.hasClass("rated-done")) return !1;
	        a.offsetX || (a.offsetX = a.clientX - $(a.target).offset().left);
	        var c = a.offsetX + 4;
	        c > 100 && (c = 100), b.find(".user-rate-image span").css("width", c + "%");
	        var d = Math.floor(c / 10 * 5) / 10;
	        d > 5 && (d = 5)
	    }),

	    $(document).on("click", ".user-rate-active", function() {
	        var a = $(this);
	        if (a.hasClass("rated-done")) return !1;
	        var b = a.find(".user-rate-image span").width();
	        a.find(".user-rate-image").hide(), a.append('<span class="taq-load"></span>'),
	        b > 100 && (b = 100),
	        ngg = 5 * b / 100;
	        var c = a.attr("data-id"),
	            d = $(".total_votes").text();
	        return $.post(halim_rate.ajaxurl, {
	            action: "halim_rate_post",
	            nonce: halim_rate.nonce,
	            post: c,
	            value: ngg
	        },
	        function(data){
	        	// console.log(data);
	            a.addClass("rated-done").attr("data-rate", b), a.find(".user-rate-image span").width(b + "%"), $(".taq-load").fadeOut(function() {
	                if(data !== 'Voted'){
		                $("span.score").html(ngg);
		                $(".total_votes").html(parseInt(d) + 1);
		                $(".tks").html(halim_rate.your_rating),
		                $(".user-rate-image").fadeIn();
		                $('[data-toggle="rate_this"]').popover('hide');
	                } else {
	                	$('.user-rate-active').html('You have already rated!');
	                	$('[data-toggle="rate_this"]').popover('show');
	                	setTimeout(function(){
	                		$('[data-toggle="rate_this"]').popover('hide');
	                	}, 2000)
	                }
	            })
	        }, "html"), !1
	    }), $(document).on("mouseleave", ".user-rate-active", function() {
	        var a = $(this);
	        if (a.hasClass("rated-done")) return !1;
	        var b = a.attr("data-rate");
	        a.find(".user-rate-image span").css("width", b + "%")
	    });
	},

	Progress: function (a, b) {
	    b.find("span").animate({
	        width: a + "%"
	    }, 700)
	},

	EpisodeNavigation: function()
	{
	    $("#server-episodes").change(function() {
	        var id = $(this).val();
	        $('a[href="' + id + '"]').tab('show');
	    });

	    if(typeof(jsonEpisodes) != 'undefined'){
	        $.each(jsonEpisodes, function(key, data) {
	            EpisodeItemLoop(data, 'server-'+key)
	        });
	        // if($('.halim-server.active ul.halim-list-eps li.active').length){
	    	// 	$('.halim-server.active ul.halim-list-eps li.active')[0].scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
	        // }
	        // if($('body').hasClass('single-watch'))
	        // {
		    //     setTimeout(() => {
			// 		$('html, body').animate({ scrollTop: 0 }, 'slow');
		    //     }, 1000)
	        // }
	    }

		function EpisodeItemLoop(data, serverId)
		{
		    var output = '';
		    output += '<ul id="listsv-'+serverId+'" class="halim-list-eps">';
		    $.each(data, function(key, val) {
		        if(val) {
		            output += '<li data-href="'+val.postUrl+'" class="clickable halim-btn '+val.activeItem+'halim-episode-item" data-post-id="'+val.postId+'" data-number="'+val.episodeName.toLowerCase()+'" data-server="'+val.serverId+'" data-episode-slug="'+val.episodeSlug+'" data-position="'+val.position+'" data-embed="'+val.embed+'">';
		            if(val.activeItem) output += '<div class="halim-pulse-ring"></div>';
		            output += '<a href="'+val.postUrl+'" title="'+val.episodeName+'"><span>'+val.episodeName+'</span></a>';
		            output += '</li>';
		        }
		    });
		    output += '</ul>';
		    $('#'+serverId).html(output)
		}

	},

	EpisodeItemSearch: function()
	{
		var thread = null;
        $('.search-episode-item').keyup(function() {
            clearTimeout(thread)
            var $this = $(this),
                val = $this.val().toLowerCase()
            $('ul.halim-list-eps').find("li").removeClass('matched')
            $('#episode-result').hide()
            thread = setTimeout(
                function() {
                    var matched = $('.halim-server.active ul.halim-list-eps').find("li[data-number*='"+val+"']")
                        matched.addClass('matched')
                    $('#episode-result').show().html(matched.html())
                    if(val == '') {
                        $('#episode-result').hide()
                    }
                    var xx = $('.halim-server.active ul.halim-list-eps li[data-number*="'+val+'"]')[0];
                    if(typeof(xx) !== 'undefined'){
                    	xx.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
                    }
                }, 200
            );

        });
	}

}

jQuery(document).ready(function($) {
	HaLim.Init();
});

function is_Mobile() {
	var isMobile = false;
	(function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))) isMobile = true;})(navigator.userAgent||navigator.vendor||window.opera);
	return isMobile;
}

function iOS() {
  return [
    'iPad Simulator',
    'iPhone Simulator',
    'iPod Simulator',
    'iPad',
    'iPhone',
    'iPod'
  ].includes(navigator.platform)
  // iPad on iOS 13 detection
  || (navigator.userAgent.includes("Mac") && "ontouchend" in document)
}

if(iOS()) {
	alert('ios')
}