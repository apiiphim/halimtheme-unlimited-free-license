var $ = jQuery.noConflict();
jQuery(function ($) {

    // add new ep
    $(document).on("click", "#add-new-eps", function(){
        var ep_total = $(this).data("ep-total");
        var ep = ep_total + 1;
        $(this).data('ep-total',ep);
        var server = $(this).data("server");
        var new_ep = '<div class="halimmovies_episodes episodes_'+ep+' row" data-ep="'+ep+'" data-server="'+server+'"><div class="form-group col-lg-1" style="margin-right: -1px"><label for="halimmovies_ep_name_'+server+'_'+ep+'">Episode Name</label><input id="halimmovies_ep_name_'+server+'_'+ep+'" name="halimmovies_ep_name[]" type="text" class="form-control" value="'+ep+'" placeholder="Episode name"></div><div class="form-group col-lg-1" style="margin-right: -1px"><label for="halimmovies_ep_slug_'+server+'_'+ep+'">Episode Slug</label><input id="halimmovies_ep_slug" type="text" class="form-control" name="halimmovies_ep_slug[]" value="'+episode_slug_default+'-'+ep+'" placeholder="Episode Slug"></div><div class="form-group col-lg-2" style="margin-right: -1px"><label>Type: </label><select name="halimmovies_ep_type[]" id="halimmovies_ep_type_'+server+'_'+ep+'" style="display:block;width:100%;margin-top: 1px;height: 32px;">'+episode_type+'</select></div><div class="form-group col-lg-8"><label for="halimmovies_ep_link_'+server+'_'+ep+'">Link: </label><input class="form-control" type="text" id="halimmovies_ep_link_'+server+'_'+ep+'" name="halimmovies_ep_link[]" style="width:100%" value="" placeholder="Episode link"/></div><a class="del_ep"><span class="dashicons dashicons-no"></span></a><div class="clearfix"></div></div>';
        $('#halimmovies_episodes').append( new_ep );
    });
    $(document).on("click", ".del_ep", function(){
       $(this).parent('.halimmovies_episodes').remove();
    });
    // add new sub
    var index = (current_subtitle_count-1);
    $(document).on("click", ".add_new_sub", function(){
        var server = $(this).data("server");
        var ep = $(this).data("ep");
        index++;
        var new_sub = '<div class="halimmovies_subs" style="margin-bottom: 10px"><label>Label: </label> <input  type="text" name="sub_label[]" style="width:15%" value="" placeholder="Vietnamese"/><input id="sub_label_default_'+server+'_'+index+'" type="radio" name="sub_default[]" value="'+index+'"><label for="sub_label_default_'+server+'_'+index+'">Default</label><span><label style="margin-left: 1%;">File: </label> <input type="text" name="sub_file[]" style="width:69.77%" value="" placeholder="http://example.com/files/subtitle/vietnamese.srt"/><a class="del_sub" style="padding: 4.5px 5px;top: -5px;"><span class="dashicons dashicons-no"></span></a><span class="sortable"><span class="dashicons dashicons-move"></span></span></span></div>';
        $( '#halimmovies_listsv_'+server+'_'+ep).find( "#halimmovies_subs").append( new_sub );
        $('.add-new-subtitle').show();
        $('.list-subtitle').css('padding-bottom', '30px');

    });
    $(document).on("click", ".del_sub", function(){
       $(this).parent().parent('.halimmovies_subs').remove();
    });


    // add new listsv

    $(document).on("click", ".add_new_listsv", function(){
        var server = $(this).data("server");
        var ep = $(this).data("ep");

        var new_sub = '<div class="halimmovies_listsv" style="margin-bottom: 10px"><label>Name: </label> <input placeholder="Server name" type="text" name="listsv_name[]" style="width:15%" value="#" /><label>Type: </label><select name="listsv_type[]" id="listsv_type">'+episode_type+'</select><label>Link: </label> <input type="text" name="listsv_link[]" style="width:71%" value="" placeholder="Alternative video url"/><a class="del_listsv"><span class="dashicons dashicons-no"></span></a></div>';

        $( '#halimmovies_listsv_'+server+'_'+ep).find( "#halimmovies_listsv").append( new_sub );
        $('#add-list-sv').show();
    });

    $(document).on("click", ".del_listsv", function(){
       $(this).parent('.halimmovies_listsv').remove();
    });


    var placeholder = 'EP 1|https://drive.google.com/file/d/1ATilCtX62rLXwpo7Gm7h2ba6wiGjbL3I/view|link \nEP 2|https://drive.google.com/file/d/1ATilCtX62rLXwpo7Gm7h2ba6wiGjbL3I/view|embed';
    $('textarea#import-multi-episode, #multiple-import-list, #addnewsv-list').attr('placeholder', placeholder);

    $('textarea#import-multi-episode, #multiple-import-list, #addnewsv-list').focus(function(){
        if($(this).val() === placeholder){
            $(this).attr('placeholder', '');
        }
    });

    // $('textarea#import-multi-episode, #multiple-import-list, #addnewsv-list').blur(function(){
    //     if($(this).val() ===''){
    //         $(this).attr('value', placeholder);
    //     }
    // });

    $('#category_select, #country_select, #release_select, #status_select, #formality_select, #orderby_select').on('change', function () {
        var url = $(this).val();
        if (url) {
            window.location = url;
        }
        return false;
    });

    $('.publish_post').click(function(){
        var el = this, post_id = $(el).data('post-id');
        $(el).find('.publish-post-btn').addClass('loading');
        $.ajax({
            type: 'POST',
            url: ajax_url,
            data: {
                action: 'halim_ajax_publish_post',
                post_id: post_id
            },
            success: function(data) {
                if(data.status == true) {
                    $(el).find('.publish-post-btn').removeClass('dashicons-update-alt loading').addClass('dashicons-yes-alt');
                    $(el).parent().html('<strong>Publish</strong>');
                } else {
                    $(el).parent().html('<strong>Error!</strong>');
                }
            }
        });
    });


    $('#add-server').click(function(){
        var server_name = $('#add-first-server input[name=server_name]').val(),
            halimmovies_ep_name = $(document).find('input[name="halimmovies_ep_name[]"]').map(function(){return $(this).val();}).get(),
            halimmovies_ep_slug = $(document).find('input[name="halimmovies_ep_slug[]"]').map(function(){return $(this).val();}).get(),
            halimmovies_ep_link = $(document).find('input[name="halimmovies_ep_link[]"]').map(function(){return $(this).val();}).get();
        var halimmovies_ep_type = [];
        $('select[name="halimmovies_ep_type[]"] option:selected').each(function() {
            halimmovies_ep_type.push($(this).val());
        });

        // console.log(halimmovies_ep_type);

        var server = $(this).data('server');
        $('#add-server > span')
        .removeClass('dashicons-plus')
        .addClass('dashicons-image-rotate loading');
        $.ajax({
            type: 'POST',
            url: ajax_url,
            data: {
                action: 'halim_add_server',
                post_id: post_id,
                server: server,
                server_name: server_name,
                halimmovies_ep_name: halimmovies_ep_name,
                halimmovies_ep_slug: halimmovies_ep_slug,
                halimmovies_ep_link: halimmovies_ep_link,
                halimmovies_ep_type: halimmovies_ep_type

            },
            success: function(data) {
                $('#add-server > span')
                .removeClass('dashicons-image-rotate loading')
                .addClass('dashicons-yes');
                setTimeout(function(){
                    window.location = '?page=halim-episode-manager&act=edit_ep&post_id='+post_id+'&server='+server;
                }, 500);
            }
        });
    });

    $('.del-server').click(function(){
        var index = $(this).data('index');
        var el = this;
        if (confirm('Are you sure you want to delete this server & all episodes?')) {
            $.ajax({
                type: 'POST',
                url: ajax_url,
                data: {
                    action: 'halim_delete_server',
                    post_id: post_id,
                    server: index
                },
                success: function(data) {
                    $(el).closest('.svitem').addClass('fadeout-tomato');
                    $(el).closest('.svitem').fadeOut(800, function(){
                        $(this).remove();
                    });
                    setTimeout(function(){
                        if(index !== '0'){
                            window.location = '?page=halim-episode-manager&act=edit_ep&post_id='+post_id+'&server='+(index-1)+'&paged=1&cat';
                        } else {
                            location.reload();
                        }
                    }, 1500);
                }
            });
        }
    });

    $('#add-eps').click(function(){
        var halimmovies_server_name = $('input[name=halimmovies_server_name]').val(),
            halimmovies_ep_name = $(document).find('input[name="halimmovies_ep_name[]"]').map(function(){return $(this).val();}).get(),
            halimmovies_ep_slug = $(document).find('input[name="halimmovies_ep_slug[]"]').map(function(){return $(this).val();}).get(),
            halimmovies_ep_link = $(document).find('input[name="halimmovies_ep_link[]"]').map(function(){return $(this).val();}).get(),
            episode_number = $(document).find('input[name="episode_number[]"]').map(function(){return $(this).val();}).get();
        var halimmovies_ep_type = [];
        $('select[name="halimmovies_ep_type[]"] option:selected').each(function() {
            halimmovies_ep_type.push($(this).val());
        });
        $('#add-eps').html('Adding...');
        $.ajax({
            type: 'POST',
            url: ajax_url,
            data: {
                action: 'halim_ajax_add_episode',
                post_id: post_id,
                server: server,
                halimmovies_server_name: halimmovies_server_name,
                halimmovies_ep_name: halimmovies_ep_name,
                halimmovies_ep_slug: halimmovies_ep_slug,
                halimmovies_ep_link: halimmovies_ep_link,
                halimmovies_ep_type: halimmovies_ep_type,
                // episode_number: episode_number
            },
            success: function(data) {
                $('#add-eps').html('&#10003; Done!');
                setTimeout(function(){
                    // location.reload();
                }, 800);
            }
        });

    });

    $('#update-eps').click(function(){
        var ep_name = $('input[name=halimmovies_ep_name]').val(),
            ep_slug = $('input[name=halimmovies_ep_slug]').val(),
            ep_link = $('input[name=halimmovies_ep_link]').val(),
            ep_type = $('select[name="halimmovies_ep_type"] option:selected').val(),
            old_ep = $('#episode_slug').data('old-ep');
        $('#update-eps > span').addClass('loading');
        $.ajax({
            type: 'POST',
            url: ajax_url,
            data: {
                action: 'halim_ajax_update_ep',
                server: server,
                post_id: post_id,
                ep_slug: ep_slug,
                ep_name: ep_name,
                ep_link: ep_link,
                ep_type: ep_type,
                old_ep: old_ep
            },
            success: function(data) {
                $('#update-eps > span')
                .removeClass('loading')
                .addClass('dashicons-yes');
                $('.disable-add-new-ep').remove();
            }
        });
    });



    $('body').on('click', '.halim-episode-saving', function(){
        var el = this;
        var halimmovies_ep_name = $(document).find('#list--episodes input[name="halimmovies_ep_name[]"]').map(function(){return $(this).val();}).get(),
            halimmovies_ep_slug = $(document).find('#list--episodes input[name="halimmovies_ep_slug[]"]').map(function(){return $(this).val();}).get(),
            halimmovies_ep_link = $(document).find('#list--episodes input[name="halimmovies_ep_link[]"]').map(function(){return $(this).val();}).get();
        var server_name = $(document).find('#list--episodes input[name="halim_server_name"]').val();
        var halimmovies_ep_type =[];
        $('#list--episodes select[name="halimmovies_ep_type[]"] option:selected').each(function() {
            halimmovies_ep_type.push($(this).val());
        });

        // console.log(halimmovies_ep_type);

        $(el).html('<span class="dashicons dashicons-image-rotate loading"></span> Updating...');

        $.ajax({
            type: 'POST',
            url: ajax_url,
            data: {
                action: 'halim_ajax_update_ep',
                post_id: post_id,
                server: server,
                server_name: server_name,
                halimmovies_ep_name: halimmovies_ep_name,
                halimmovies_ep_slug: halimmovies_ep_slug,
                halimmovies_ep_link: halimmovies_ep_link,
                halimmovies_ep_type: halimmovies_ep_type
            },
            success: function(data) {
                $(el).html('&#10003; Done!');
                setTimeout(function(){
                    $(el).html('Update episodes');
                }, 1200);
            }
        });
    });




    $('.update-list-sv').click(function(){
        var el = this,
            ep_slug = $(el).data('ep-slug'),
            listsv_name = $(document).find('#list-server-'+ep_slug).find('input[name="listsv_name[]"]').map(function(){return $(this).val();}).get(),
            listsv_link = $(document).find('#list-server-'+ep_slug).find('input[name="listsv_link[]"]').map(function(){return $(this).val();}).get(),
            listsv_type =[];
            $('#list-server-'+ep_slug+' select[name="listsv_type[]"] option:selected').each(function() {
                listsv_type.push($(this).val());
            });

        $('.update-list-sv').find('span.'+ep_slug).addClass('loading');
        $.ajax({
            type: 'POST',
            url: ajax_url,
            data: {
                action: 'halim_update_listsv',
                post_id: post_id,
                server: server,
                episode_slug: ep_slug,
                listsv_name: listsv_name,
                listsv_link: listsv_link,
                listsv_type: listsv_type
            },
            success: function(data) {
                $('.update-list-sv').find('span.'+ep_slug).removeClass('loading').addClass('dashicons-yes');
            }
        });
    });


    $('body').on('click', '.update-subtitle', function(){
        var el = this,
            ep_slug = $(el).data('ep-slug'),
            sub_label = $(document).find('#list-subtitle-'+ep_slug).find('input[name="sub_label[]"]').map(function(){return $(this).val();}).get(),
            sub_file = $(document).find('#list-subtitle-'+ep_slug).find('input[name="sub_file[]"]').map(function(){return $(this).val();}).get(),
            sub_default = $(document).find('#list-subtitle-'+ep_slug).find('input[name="sub_default[]"]:checked').map(function(){return $(this).val();}).get();
            $(el).html('<span class="dashicons dashicons-image-rotate loading"></span> Updating...');
        $.ajax({
            type: 'POST',
            url: ajax_url,
            data: {
                action: 'halim_update_subtitle',
                post_id: post_id,
                server: server,
                episode_slug: ep_slug,
                sub_label: sub_label,
                sub_file: sub_file,
                sub_default: sub_default
            },
            success: function(data) {
                $(el).html('&#10003; Done!');
                setTimeout(function(){
                    $(el).html('Update');
                }, 1200);
            }
        });
    });

});


function fastImport()
{
    var list_link = $('#import-multi-episode').val().split(/\r?\n/);
    $('#result').show().html('Please wait...');
    $.ajax({
        url: ajax_url,
        type: 'POST',
        data: {
            action: 'halim_ajax_fast_import_episode',
            post_id: post_id,
            server: server,
            list_link: list_link
        },
        success: function(result) {
            $('#result').show().html('Import successfuly! <a href="?page=halim-episode-manager&act=edit_ep&post_id='+post_id+'&server='+server+'&episode=1&paged=1">Edit Episode</a>');

            // setTimeout(function(){
            //     window.location = '?page=halim-episode-manager&act=edit_ep&post_id='+post_id+'&server='+server+'&episode=1&paged=1&cat=';
            // }, 1000);
        }
    });

}




function setMessage(msg) {
    $("#message").html(msg);
    $("#message").show();
}

function halim_ImportEPS() {
    $("#halim_data_rebuild").prop("disabled", true);
    setMessage('Reading data...');
    var list_link = $('#import-multi-episode').val().split(/\r?\n/);

    $.ajax({
        url: ajax_url,
        type: 'POST',
        data: 'action=halim_ajax_import_episode&do=getList&list_link='+list_link+'&post_id='+post_id+'&server='+server,
        success: function(result) {
            var list = eval(result);
            var curr = 0;
            if (!list) {
                setMessage('No data found!');
                $("#halim_data_rebuild").prop("disabled", false);
                return;
            }

            function pushItem() {
                if (curr >= list.length) {
                    $("#halim_data_rebuild").prop("disabled", false);
                    $('#status p:first-child').addClass('ok');
                    setMessage("Done!");
                    return;
                }

                setMessage( 'Importing ' + (curr + 1) + ' of ' + list.length + ' (Episode ' + list[curr].ep_name + ')...');

                $.ajax({
                    url: ajax_url,
                    type: 'POST',
                    data: {
                        action: 'halim_ajax_import_episode',
                        do: 'insertEpisode',
                        post_id: post_id,
                        server: server,
                        ep_name: list[curr].ep_name,
                        ep_link: list[curr].ep_link,
                        ep_type: list[curr].ep_type,
                    },
                    success: function(result) {
                        curr = curr + 1;
                        if (result != '-1') {
                            $('#status').show().prepend('<p><span style="color:#46b450;font-size: 17px;font-weight: bold;">✓</span> '+result+'</p>');
                        }
                        pushItem();
                    }
                });
            }

            pushItem();

        },
        error: function(request, status, error) {
            setMessage('Error ' + request.status);
        }
    });
}


$(".halim-list-eps, #halimmovies_listsv, #halimmovies_subs, .sortable-list-sv-box").sortable({ //.list_eps
    placeholder: 'slide-placeholder',
    axis: "y",
    revert: 150,
    start: function(e, ui){
        placeholderHeight = ui.item.outerHeight();
        ui.placeholder.height(placeholderHeight + 15);
        $('<div class="slide-placeholder-animator" data-height="' + placeholderHeight + '"></div>').insertAfter(ui.placeholder);
    },
    change: function(event, ui) {
        ui.placeholder.stop().height(0).animate({
            height: ui.item.outerHeight() + 15
        }, 300);
        placeholderAnimatorHeight = parseInt($(".slide-placeholder-animator").attr("data-height"));
        $(".slide-placeholder-animator").stop().height(placeholderAnimatorHeight + 15).animate({
            height: 0
        }, 300, function() {
            $(this).remove();
            placeholderHeight = ui.item.outerHeight();
            $('<div class="slide-placeholder-animator" data-height="' + placeholderHeight + '"></div>').insertAfter(ui.placeholder);
        });
    },
    stop: function(e, ui) {
        $(".slide-placeholder-animator").remove();
    },
});