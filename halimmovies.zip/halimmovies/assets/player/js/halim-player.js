function getURLParameterValues(parameterName, url) {
    if (!url) url = window.location.href;
    parameterName= parameterName.replace(/[\[\]]/g, "\\><");
    var regularExpression = new RegExp("[?&]" + parameterName + "(=([^&#]*)|&|#|$)"),
    results = regularExpression.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

var $ = jQuery.noConflict();
jQuery(document).ready(function($)
{

    if($('#html-player').length){
        // $('#html-player iframe, iframe.embed-responsive-item').on('load', function() {
        //     $('#halim-player-loader').hide()
        // } );

        $('#html-player iframe').ready(function(){
            $('#halim-player-loader').hide()
        });

    }

    if($('#ajax-player').length){

        var svid = getURLParameterValues("svid");

        if(svid == null) {
            halimPlayer(halim_cfg.episode_slug, halim_cfg.server, halim_cfg.post_id, $('body').data('nonce'),  '', halim_cfg.custom_var);
        } else {
            var episode_slug = $('.halim-btn.active').data('episode-slug'),
                server = $('.halim-btn.active').data('server'),
                post_id = $('.halim-btn.active').data('post-id'),
                subsv_id = svid;
            if(typeof playerInstance != 'undefined') playerInstance.pause();
            $('#server-item-' + svid).addClass('active').siblings().removeClass('active');
            $('#halim-player-wrapper').css('z-index', '99999');
            $('button.close').click();
            halimPlayer(episode_slug, server, post_id, '', subsv_id, halim_cfg.custom_var);
        }

        setTimeout(function(){
            var embed = $(document).find('.halim-btn.active').data('embed');
            if(embed == 1){
                $("#autonext").hide();
            }else{
                $("#autonext").show();
            }
        }, 2000);
    }

    $('body').on('click', '.play-listsv', function()
    {
        var episode_slug = $('.halim-btn.active').data('episode-slug'),
            server = $('.halim-btn.active').data('server'),
            post_id = $('.halim-btn.active').data('post-id'),
            subsv_id = $(this).data('subsv-id');
        if(typeof playerInstance != 'undefined') playerInstance.pause();
        $(this).addClass('active').siblings().removeClass('active');
        $('#halim-player-wrapper').css('z-index', '99999');
        $('#halim-player-loader').show().css('position', 'absolute')
        $('button.close').click();
        halimPlayer(episode_slug, server, post_id, '', subsv_id, halim_cfg.custom_var);
    });

    $("#autonext").on('click', function(){
        if($("#autonext-status").text() == 'On'){
            $("#autonext-status").text('Off');
        } else {
            $("#autonext-status").text('On');
        }
    });

    $('body').on('click', '#reBuildPlayer', function(){
        var episode_slug = $('.halim-btn.active').data('episode-slug'),
            server = $('.halim-btn.active').data('server'),
            post_id = $('.halim-btn.active').data('post-id');
        $('#halim-player-wrapper').css('z-index', '99999');
        $('#icon-rebuild-player').addClass('animate-spin');
        $('button.close').click();
        $('#halim-player-loader').show().css('position', 'absolute')
        halimPlayerResetCache(episode_slug, server, post_id);
        halimPlayer(episode_slug, server, post_id, '', '', halim_cfg.custom_var);
        console.log('Player has been reloaded!');
    });

    halimExpandPlayer();
    // halimResizePlayerFullWidth();
    ToggleLight();
});

function halimPlayer(episode_slug, server, post_id, nonce, subsv_id, custom_var)
{
    if($('#ajax-player, #html-player').length)
    {
        $.ajax({
            url: halim_cfg.player_url,
            dataType: 'html',
            // cache: false,
            data : {
                episode_slug: episode_slug,
                server_id: server,
                subsv_id: subsv_id,
                post_id: post_id,
                nonce: nonce,
                custom_var: custom_var
            },
            beforeSend: function() {
                $('#halim-player-loader').show().html('<p style="margin-top: 15px">'+halim_cfg.player_loading+'</p>');
            },
            success: function(res) {
                // var response = JSON.parse(res).data;
                // if(response.status == true) {
                    localStorage.removeItem('reSizePlayerObject');
                    // $('#ajax-player, #html-player').html(response.sources)
                    $('#ajax-player, #html-player').html(res)
                    $('#playerLoadingModal').modal('hide')
                    $('#icon-rebuild-player').removeClass('animate-spin')
                    $("#halim-player-loader").hide();

                // }
            },
            error: function (xhr, ajaxOptions, thrownError) {
                console.log(xhr.status + ' ' + thrownError);
            }
        });
    }
    return false;
}


function halimJwConfig(playerInstance)
{


    playerInstance.on('ready', function() {
        // var reSizePlayerObject = {'width': playerInstance.getWidth(), 'height': playerInstance.getHeight()};
        // localStorage.setItem('reSizePlayerObject', JSON.stringify(reSizePlayerObject));
        if (!is_Mobile()) {
            halimJwAddButton(playerInstance);
        }
        $("#halim-player-loader").hide();
    });

    playerInstance.on('error', function() {

        if(halim_cfg.player_error_detect == 'display_modal'){
            halimPlayerErrorDetect();
        } else if(halim_cfg.player_error_detect == 'autoload_server') {
            var listsv = svlists[Math.floor(Math.random() * svlists.length)];
            $('#server-item-'+listsv).click();
        } else {
            if (!$.fn.customErrorHandler) {
                customErrorHandler();
            }
        }

        if(halim_cfg.auto_reset_cache == true) {
            var episode_slug = $('.halim-btn.active').data('episode-slug'),
                server = $('.halim-btn.active').data('server'),
                post_id = $('.halim-btn.active').data('post-id');
            halimPlayerResetCache(episode_slug, server, post_id);
        }
    });

    playerInstance.on('play', function() {
        jQuery('#reLoadPlayerModal').modal('hide');
    });

    playerInstance.on('complete', function(){
        halimPlayerAutoNext();
    });
}

function halimJwAddButton(playerInstance){
    var playerContainer = playerInstance.getContainer(),
    logoDiv = $('<div></div>').addClass('jw-icon jw-icon-inline jw-button-color jw-reset halim-toggle-light halim-icon-toggle-light').append($('<div></div>').addClass('player-tooltip').html('Toggle Light')),
    resizeDiv = $('<div></div>').addClass('jw-icon jw-icon-inline jw-button-color jw-reset halim-resize-bar halim-icon-expand size-small').append($('<div></div>').addClass('player-tooltip').html('Resize Player'));
    $(playerContainer).find('.jw-icon-fullscreen').before(resizeDiv).before(logoDiv);
}


function halimPlayerResetCache(episode_slug, server, post_id){

    $.ajax({
        url: ajax_player.url,
        type: 'POST',
        data : {
            action: 'reset_player_cache',
            episode_slug: episode_slug,
            server_id: server,
            post_id: post_id
        },
        success: function(res) {
            console.log(res);
        }
    });

    return false;
}


function halimPlayerErrorDetect() {
    var style = '', html;
    if($('#halim-ajax-list-server').length == 0) {
        style = ' style="display:none;"';
    }

    html = '<div id="reLoadPlayerModal" class="modal fade" role="dialog" style="top: 35px;z-index: 99999;">'+
    '  <div class="modal-dialog modal-md">'+
    '    <div class="modal-content">'+
    '        <div class="modal-header">'+
    '            <button type="button" class="close" data-dismiss="modal">×</button>'+
    '            <h4 class="modal-title adult-content-title">(Error&nbsp;Code:&nbsp;224003)</h4>'+
    '        </div>'+
    '        <div class="modal-body panel-body adult-content-info text-center">'+
    '            <h4><strong>'+halim_cfg.jw_error_msg_1+'</strong></h4>'+
    '            <p>'+halim_cfg.jw_error_msg_0+'</p>'+
    '            <p>'+halim_cfg.jw_error_msg_2+'</p>'+
    '            <button type="button" class="btn btn-danger" id="reBuildPlayer" style="margin-bottom: 5px;"><i id="icon-rebuild-player" class="hl-spin4"></i> '+halim_cfg.player_reload+'</button>'+
    '            <p'+style+'>'+halim_cfg.jw_error_msg_3+'</p>'+
    '            <div id="serverList"></div>'+
    '        </div>'+
    '    </div>'+
    '  </div>'+
    '</div>';
    if(!is_Mobile()) {
        $('#halim-player-wrapper').append(html);
        $('#halim-player-loader').css('z-index', '999999');
    } else {
        $('body').append(html);
    }
    $('#halim-ajax-list-server').prependTo('#serverList');
    $('#reLoadPlayerModal').modal('show');
    if(!is_Mobile()) $('.modal-backdrop').appendTo('#halim-player-wrapper');
    $('body').removeClass("modal-open");
    $('body').css("padding-right","");
    $('.modal, .modal-backdrop').css('position', 'absolute');
    $('#reLoadPlayerModal').on('hidden.bs.modal', function () {
        $('#halim-ajax-list-server').prependTo('.halim-ajax-list-server');
    });
}


function halimPlayerAutoNext()
{
    if($("#autonext-status").text() == "On"){
        var episode_slug, position, href;
        position = $(".halim-list-eps").find(".halim-episode-item.active").data("position");
        if(position != "last"){
            if(halim_cfg.server > 1) {
                href = $('.halim-episode-item.active').next().data('href');
            } else {
                href = $('.halim-episode-item.active').next().find('a').attr('href');
            }
            var counter = 5;
            var interval = setInterval(function() {
                counter--;
                if (counter <= 0) {
                    clearInterval(interval);
                    window.location = href;
                    return;
                } else {
                    $('#halim-player-loader').show().css('position', 'absolute').html('<p style="padding-top:25px;">'+halim_cfg.player_autonext+' <span>['+counter+'s]</span></p>');
                }
            }, 1000);
        } else {
            $('#halim-player-loader').show().css('position', 'absolute').html('<p style="padding-top:25px;">Chưa có tập mới hoặc đây là tập cuối!</span></p>');
        }
    }
}

function halimExpandPlayer() {
    resizeCheck="small",
    playerWrapper = $("#halim-player-wrapper");
    playersize = JSON.parse(localStorage.getItem('reSizePlayerObject'));
    if(playersize == null) {
        playersize = {width:810,height:456}
    }
    $(document).on("click", "#explayer, .halim-resize-bar", function() {
        $('.halim-resize-bar').toggleClass('size-large');
        if("small"==resizeCheck){
        var e = 1140, pc = e/playersize.width, new_h = playersize.height * pc,t={width:e,height:Math.ceil(new_h)};
            $("#explayer").offset().top, $(playerWrapper).animate({width:t.width,height:t.height}),
            $("#sidebar").animate({marginTop:t.height+20}),
            $('#explayer').html('<i class="hl-resize-small"></i> '+halim_cfg.collapse),
            resizeCheck="large"
        } else {
            $(playerWrapper).animate({width:playersize.width,height:playersize.height}),
            $("#sidebar").animate({marginTop:"0px"}),
            $('#explayer').html('<i class="hl-resize-full"></i> '+halim_cfg.expand),
            resizeCheck="small"
        }
        $("html, body").animate({scrollTop: $(playerWrapper).offset().top -63 }, 1000);
    });
}

function halimResizePlayerFullWidth(){
    resizeCheck = 'small';
    $(document).on('click', '#explayer, .halim-resize-bar', function() {
        $('.halim-resize-bar').toggleClass('size-large');
        var $this = $('#ajax-player');
        if('small' == resizeCheck) {
            $('.halim-full-player').removeClass('hidden');
            $this.removeClass('player').prependTo('#halim-full-player');
            $('#halim-player-wrapper').addClass('hidden');
            $('.navbar-container').addClass('box-shadow-none');
            $('#explayer').html('<i class="hl-resize-small"></i> '+halim_cfg.collapse);
            resizeCheck = 'large'
        } else {
            $('.halim-full-player').addClass('hidden');
            $this.addClass('player').prependTo('#halim-player-wrapper');
            $('#halim-player-wrapper').removeClass('hidden');
            $('.navbar-container').removeClass('box-shadow-none');
            $('#explayer').html('<i class="hl-resize-full"></i> '+halim_cfg.expand);
            resizeCheck = 'small'
        }
    });
}

function halimResumeVideo(resumeId, playerInstance)
{
    if(halim_cfg.resume_playback == true)
    {
        playerInstance.on('ready', function() {
            if (typeof(Storage) !== 'undefined') {

                var resumeData = 'HaLimPlayerPosition-'+resumeId;
                if (localStorage[resumeData] == '' || localStorage[resumeData] == 'undefined') {
                    console.log("No cookie for position found");
                    var currentPosition = 0;
                } else {
                    if (localStorage[resumeData] == "null") {
                        localStorage[resumeData] = 0;
                    } else {
                        var currentPosition = localStorage[resumeData];
                    }
                    console.log("Position cookie found: "+localStorage[resumeData]);
                }


                playerInstance.once('play',function(){
                    console.log('Checking position cookie!');
                    console.log(Math.abs(playerInstance.getDuration() - currentPosition));
                    if (currentPosition > 0 && Math.abs(playerInstance.getDuration() - currentPosition) > 5) {
                        playerInstance.seek(currentPosition);

                        $('body').append('<div class="modal fade" id="resume" tabindex="-1" role="dialog" aria-labelledby="mobileModalLabel" aria-hidden="true" style="z-index: 99999;"><div id="resumeModal" class="modal-dialog modal-sm" style="position:relative;background: #fff;border: 1px solid #eee;padding: 20px 13px;text-align: center;border-radius: 5px;"><p>'+halim_cfg.resume_text+': <b style="color:#f52121;">'+ formatSeconds(currentPosition) +'</b></p><div style="text-align:center;"><strong class="yes"><i class="hl-ccw"></i> '+halim_cfg.playback+'</strong><strong class="no"><i class="hl-play-circled-o"></i> '+halim_cfg.continue_watching+'</strong></div></div></div>');

                        setTimeout(function(){
                            $('#resume').modal('show');
                        }, 800);

                        $('body').on('click', '.no', function(){
                            $('#resume').modal('hide');
                            playerInstance.play();
                        });

                        $('body').on('click', '.yes', function(){
                            $('#resume').modal('hide');
                            localStorage[resumeData] = 0;
                            playerInstance.seek(0);
                            playerInstance.play();
                        });
                    }
                });

                window.onunload = function() {
                   localStorage[resumeData] = playerInstance.getPosition();
                }

            } else {
                console.log('Your browser is too old!');
            }
        });
    }

}

function formatSeconds(seconds) {
    var date = new Date(1970, 0, 1);
    date.setSeconds(seconds);
    return date.toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1");
}


function ToggleLight() {
    var lightout = false;
    $('.player-control, #halim-full-player').css("position", "relative").css('z-index', 8);
    $(document).on("click", "#toggle-light, .halim-toggle-light", function() {
        if (!lightout) {
            lightout = true;
            $("#lightout").css("opacity", 0.98).hide().fadeIn();
        } else {
            lightout = false;
            $("#lightout").fadeOut();
        }
        $("#toggle-light").html(lightout ? "<i class='hl-light-up'></i> "+halim_cfg.light_on : "<i class='hl-adjust'></i> "+halim_cfg.light_off);
    });
}
function startChecking()
{
    secondsleft -= 1000;
    $("#counter span").html(Math.abs((secondsleft / 1000)));
    if(secondsleft == 0)
    {
        clearInterval(interval);
        $("#halim-player-timeleft").hide();
    }
}

function startschedule()
{
    clearInterval(interval);
    secondsleft = threshold;
    $("#counter span").html(Math.abs((secondsleft / 1000)));
    interval = setInterval(function() {
        startChecking();
    }, 1000)
}

function is_Mobile() {
    var isMobile = false;
    (function(a){if(/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino|android|ipad|playbook|silk/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4))) isMobile = true;})(navigator.userAgent||navigator.vendor||window.opera);
    return isMobile;
}
