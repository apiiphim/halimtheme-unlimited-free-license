<?php

class halim_related_video_Widget extends WP_Widget
{
	public function __construct() {
		parent::__construct(
			'halim_related_movies',
			__( 'Halim Related Movie', 'halimthemes' ),
			array(
				'classname'   => 'halim_related_movies',
				'description' => __( 'Display related movies', 'halimthemes' )
			)
		);
	}

	function widget($args, $instance)
	{
		global $post;
		extract($args);
		$title = $instance['title'];
		$postnum = $instance['postnum'];
		$type = $instance['type'];
		$layout = $instance['layout'];
		$related_by = $instance['related_by'];
		echo $before_widget;
		$class = $type == 'slider' ? 'owl-carousel owl-theme' : 'halim_box';
		$meta = get_post_meta($post->ID, '_halim_metabox_options', true);
		$post_format = halim_get_post_format_type($meta['halim_movie_formality']??'');

		?>

		<div id="<?php echo $widget_id; ?>xx" class="wrap-slider">
		<?php if($title != '') : ?>
			<div class="section-bar clearfix">
			   <h3 class="section-title"><span><?php echo $title; ?></span></h3>
			</div>
		<?php endif ?>
			<div id="<?php echo $widget_id; ?>" class="<?php echo $class; ?> related-film">
				<?php

					$args = array(
						'post_type' => 'post',
						'post_status' => 'publish',
						'post__not_in'        => array($post->ID),
						'posts_per_page'           => $postnum,
						'orderby'             => 'rand',
						'ignore_sticky_posts' => 1
					);
					if($related_by == 'tag')
					{
						$tags = wp_get_post_tags($post->ID);
						// dd($tags);
						if($tags) {
							$tag_ids = array();
	                        foreach($tags as $individual_tag){
	                        	$tag_ids[] = $individual_tag->term_id;
	                        }
							$args['tag__in'] = $tag_ids;
						}
					} else {
						$categories = get_the_category($post->ID);
						if ($categories){
							$category_ids = array();
							foreach ($categories as $individual_category) {
								$category_ids[] = $individual_category->term_id;
							}
							$args['category__in'] = $category_ids;
						}
					}

	                $args['tax_query'] = array(array(
	                    'taxonomy' => 'post_format',
	                    'field' => 'slug',
	                    'terms' => array('post-format-'.$post_format),
	                    'operator' => 'IN'
	                ));

					$wp_query = new WP_Query($args);

					if ($wp_query->have_posts()) {
						while ($wp_query->have_posts())
						{
							$wp_query->the_post();
							if($type == 'slider') {
								get_template_part( 'templates/loop', 'item', ['layout' => '', 'is_slider' => true] );
							} else {
								get_template_part( 'templates/loop', 'item', ['layout' => $layout]);
							}
						}
						wp_reset_postdata();
					}
				?>
			</div>
			<?php if($type == 'slider') : ?>
			<script>
				jQuery(document).ready(function($) {
				var owl = $('#<?php echo $widget_id; ?>');
				owl.owlCarousel({loop: true,margin: 4,autoplay: true,autoplayTimeout: 4000,autoplayHoverPause: true,nav: true,navText: ['<i class="hl-down-open rotate-left"></i>', '<i class="hl-down-open rotate-right"></i>'],responsiveClass: true,responsive: {0: {items:2},480: {items:3}, 600: {items:4},1000: {items: <?php echo $layout == '6col' ? 6:4; ?>}}})});
			</script>
			<?php endif; ?>
		</div>
		<?php
		echo $after_widget;
	}
	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['postnum'] = $new_instance['postnum'];
		$instance['type'] = $new_instance['type'];
		$instance['layout'] = $new_instance['layout'];
		$instance['related_by'] = $new_instance['related_by'];

		return $instance;
	}

	function form($instance)
	{
		$instance = wp_parse_args( (array) $instance, array(
			'title' 	=> 'Similar movies',
			'postnum' 	=> 8,
			'type'		=> 'slider',
			'layout'	=> '6col',
			'related_by' => 'category'
		) );
		extract($instance);

		 ?>
			<p>
				<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'halimthemes') ?></label>
				<br>
				<input class="widefat" type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
			</p>


			<p>
			<label><?php _e('Related by', 'halimthemes') ?></label>
			<br>
			<?php
			  $fx = array( 'tag' => __('Tag', 'halimthemes'), 'category' => __('Category', 'halimthemes'));
				foreach ($fx as $x => $n ) { ?>
				<label for="<?php echo $this->get_field_id("related_by"); ?>_<?php echo $x ?>">
					<input id="<?php echo $this->get_field_id("related_by"); ?>_<?php echo $x ?>" class="<?php echo $x ?>" name="<?php echo $this->get_field_name("related_by"); ?>" type="radio" value="<?php echo $x ?>" <?php if (isset($related_by)) { checked( $x, $related_by, true ); } ?> /> <?php echo $n ?>
				</label>
			<?php } ?>
			</p>
			<p>
			<label><?php _e('Type', 'halimthemes') ?></label>
			<br>
			<?php
			  $f = array( 'slider' => __('Slide show', 'halimthemes'), 'grid' => __('Grid box', 'halimthemes'));
				foreach ($f as $x => $n ) { ?>
				<label for="<?php echo $this->get_field_id("type"); ?>_<?php echo $x ?>">
					<input id="<?php echo $this->get_field_id("type"); ?>_<?php echo $x ?>" class="<?php echo $x ?>" name="<?php echo $this->get_field_name("type"); ?>" type="radio" value="<?php echo $x ?>" <?php if (isset($type)) { checked( $x, $type, true ); } ?> /> <?php echo $n ?>
				</label>
			<?php } ?>
			</p>
			<p style="clear: both;">
				<label for="<?php echo $this->get_field_id('layout'); ?>">
				<?php _e('Layout', 'halimthemes') ?>
				<br />
					<select id="<?php echo $this->get_field_id('layout'); ?>" name="<?php echo $this->get_field_name('layout'); ?>" class="widefat">
						<?php
						  	$vl = array( '4col' => __('4 item/row', 'halimthemes'), '6col' => __('6 item/row', 'halimthemes') );
								foreach ($vl as $layout_id => $layout_name) { ?>
									<option value="<?php echo $layout_id ?>" <?php selected( $layout_id, $instance['layout'], true ); ?>>
									<?php echo $layout_name ?>
									</option>
						<?php } ?>
					</select>
				</label>
			</p>
			<p>
				<label for="<?php echo $this->get_field_id('postnum'); ?>"><?php _e('Number of post to show', 'halimthemes') ?></label>
				<input type="number" class="widefat" style="width: 60px;" id="<?php echo $this->get_field_id('postnum'); ?>" name="<?php echo $this->get_field_name('postnum'); ?>" value="<?php echo $instance['postnum']; ?>" />
			</p>
		<?php
	}
}

add_action('widgets_init', 'halim_related_video_widgets');
function halim_related_video_widgets()
{
	register_widget('halim_related_video_Widget');
}
