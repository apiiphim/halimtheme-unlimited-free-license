<?php

class halim_popular_movie_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'halim_popular_movie-widget',
			__( 'HaLim TOP Movies', 'halimthemes' ),
			array(
				'classname'   => 'halim_popular_movie-widget',
				'description' => __( 'Display popular post by movie', 'halimthemes' )
			)
		);
	}

	function widget($args, $instance)
	{
		global $post;
		extract($args);
		extract($instance);
		echo $before_widget;
		if($title != '') : ?>
			<div class="section-bar clearfix">
				<div class="section-title">
					<span><?php echo $title; ?></span>
				</div>
			</div>
		<?php endif ?>
	   <section class="tab-content">
			<div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
				<div class="popular-post">
					<?php
						$args = array(
							'post_type' => 'post',
							'posts_per_page' => $postnum,
							'orderby' => 'meta_value_num',
				        	'tax_query' => array(array(
					            'taxonomy' => 'post_format',
					            'field' => 'slug',
					            'terms' => array('post-format-aside'),
					            'operator' => 'IN' //NOT IN
				           	)),
							'meta_query' => array(
								// 'relation' => 'AND',
								array('key' => 'halim_view_post_all'),
					            // array(
					            //    'key' => '_halim_metabox_options',
					            //    'value' => 'single_movies',
					            //    'compare' => 'LIKE'
					            // )
							),
						);

						if($rand) {
							$args['orderby'] = 'rand';
						}
						$day = new WP_Query( $args );
						if ($day->have_posts()) : while ($day->have_posts()) : $day->the_post();
							get_template_part( 'templates/loop', 'popular', ['type' => 'all', 'show_info' => false, 'show_view_count' => $show_view_count] );
						endwhile; endif; wp_reset_postdata(); ?>
				</div>
			</div>
		</section>
		<div class="clearfix"></div>
	<?php
		echo $after_widget;
	}

	function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['postnum'] = $new_instance['postnum'];
		$instance['rand'] = $new_instance['rand'];
		$instance['show_view_count'] = $new_instance['show_view_count'];
		return $instance;
	}

	function form($instance)
	{
		$defaults = array(
			'title' 		=> __('TOP Movies', 'halimthemes'),
			'postnum' 		=> 6,
			'rand' => 0,
			'show_view_count' => 0
		);
		$instance = wp_parse_args((array) $instance, $defaults);
		extract($instance);
		 ?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'halimthemes') ?></label>
			<br />
			<input class="widefat" type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $title; ?>" />
		</p>
		<p class="random" style="clear: both; display:block;">
			<label for="<?php echo $this->get_field_id("rand"); ?>">
				<input id="<?php echo $this->get_field_id("rand"); ?>" class="rand" name="<?php echo $this->get_field_name("rand"); ?>" type="checkbox" value="1" <?php if (isset($rand)) { checked($rand, 1 ); } ?>/> <?php _e('Random post', 'halimthemes') ?>
			</label>
		</p>
		<p class="show_view_count" style="clear: both; display:block;">
			<label for="<?php echo $this->get_field_id("show_view_count"); ?>">
				<input id="<?php echo $this->get_field_id("show_view_count"); ?>" class="show_view_count" name="<?php echo $this->get_field_name("show_view_count"); ?>" type="checkbox" value="1" <?php if (isset($show_view_count)) { checked($show_view_count, 1 ); } ?>/> <?php _e('Show post view count', 'halimthemes') ?>
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('postnum'); ?>"><?php _e('Number of post to show', 'halimthemes') ?></label>
			<br />
			<input type="number" class="widefat" style="width: 60px;" id="<?php echo $this->get_field_id('postnum'); ?>" name="<?php echo $this->get_field_name('postnum'); ?>" value="<?php echo $postnum; ?>" />
		</p>
	<?php
	}
}

function halim_popular_movie_Widgets(){
	register_widget('halim_popular_movie_Widget');
}
add_action('widgets_init', 'halim_popular_movie_Widgets');