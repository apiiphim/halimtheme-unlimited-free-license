<?php

class halim_latest_update_movie_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'halim_latest_update_movie-widget',
			__( 'Latest update movie (Sidebar)', 'halimthemes' ),
			array(
				'classname'   => 'halim_latest_update_movie-widget',
				'description' => __( 'Display Latest Updated Movie & TV Series', 'halimthemes' )
			)
		);
	}

	function widget($args, $instance)
	{
		global $post;
		extract($args);
		extract($instance);
		echo $before_widget;
		?>
	   	<section>
			<div class="section-bar clearfix">
				<div class="section-title">
					<span><?php echo $title; ?></span>
				</div>
			</div>
			<div class="popular-post">
				<?php
					$value = $type == 'movie' ? 'single_movies' : 'tv_series';



					$args = array(
						'post_type' => 'post',
						'posts_per_page' => $postnum,
						'orderby' => 'modified',
						'meta_query' => array(
				            array(
				               'key' => '_halim_metabox_options',
				               'value' => $value,
				               'compare' => 'LIKE'
				            )
						),
					);

					$day = new WP_Query( $args );
					if ($day->have_posts()) : while ($day->have_posts()) : $day->the_post();
						get_template_part( 'templates/loop', 'popular', ['type' => 'all', 'show_info' => true, 'show_view_count' => $show_view_count] );
					endwhile; endif; wp_reset_postdata(); ?>
			</div>
		</section>
	<?php
		echo $after_widget;
	}
	function update($new_instance, $old_instance){
		$instance = $old_instance;
		$instance['title'] = $new_instance['title'];
		$instance['postnum'] = $new_instance['postnum'];
		$instance['type'] = $new_instance['type'];
		$instance['show_view_count'] = $new_instance['show_view_count'];
		return $instance;
	}

	function form($instance)
	{
		$instance = wp_parse_args( (array) $instance, array(
			'title' 	=> 'Latest updates',
			'postnum' 	=> 5,
			'type'		=> 'movie',
			'show_view_count' => 0
		) );
		extract($instance);

		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'halimthemes') ?></label>
			<br />
			<input class="widefat" type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		<p class="show_view_count" style="clear: both; display:block;">
			<label for="<?php echo $this->get_field_id("show_view_count"); ?>">
				<input id="<?php echo $this->get_field_id("show_view_count"); ?>" class="show_view_count" name="<?php echo $this->get_field_name("show_view_count"); ?>" type="checkbox" value="1" <?php if (isset($show_view_count)) { checked($show_view_count, 1 ); } ?>/> <?php _e('Show post view count', 'halimthemes') ?>
			</label>
		</p>
		<p>
			<label><?php _e('Type', 'halimthemes') ?></label>
			<br>
			<?php
			  $f = array( 'movie' => __('Movie', 'halimthemes'), 'tv_series' => __('TV Series', 'halimthemes'));
				foreach ($f as $x => $n ) { ?>
				<label for="<?php echo $this->get_field_id("type"); ?>_<?php echo $x ?>">
					<input id="<?php echo $this->get_field_id("type"); ?>_<?php echo $x ?>" class="<?php echo $x ?>" name="<?php echo $this->get_field_name("type"); ?>" type="radio" value="<?php echo $x ?>" <?php if (isset($type)) { checked( $x, $type, true ); } ?> /> <?php echo $n ?>
				</label>
			<?php } ?>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id('postnum'); ?>"><?php _e('Number of post to show', 'halimthemes') ?></label>
			<br />
			<input type="number" class="widefat" style="width: 60px;" id="<?php echo $this->get_field_id('postnum'); ?>" name="<?php echo $this->get_field_name('postnum'); ?>" value="<?php echo $instance['postnum']; ?>" />
		</p>
	<?php
	}
}

function halim_latest_update_movie_Widgets(){
	register_widget('halim_latest_update_movie_Widget');
}
add_action('widgets_init', 'halim_latest_update_movie_Widgets');