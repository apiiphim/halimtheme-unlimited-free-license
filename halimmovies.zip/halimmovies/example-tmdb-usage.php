<?php
/**
 * Example usage of TMDB/IMDB helper functions in theme templates
 * Copy these examples to your theme files where needed
 */

// Example 1: Display rating stars in single post
function example_display_rating() {
    global $post;
    $rating_stars = halim_display_rating_stars($post->ID);
    if ($rating_stars) {
        echo '<div class="movie-rating">';
        echo '<strong>Đánh giá:</strong> ' . $rating_stars;
        echo '</div>';
    }
}

// Example 2: Display external links
function example_display_external_links() {
    global $post;
    $external_links = halim_display_external_links($post->ID);
    if ($external_links) {
        echo '<div class="movie-external-links">';
        echo '<strong>Xem thêm tại:</strong><br>';
        echo $external_links;
        echo '</div>';
    }
}

// Example 3: Get TMDB info for custom display
function example_custom_tmdb_display() {
    global $post;
    $tmdb_info = halim_get_tmdb_info($post->ID);
    
    if ($tmdb_info['tmdb_vote_average'] > 0) {
        echo '<div class="movie-tmdb-info">';
        echo '<p><strong>TMDB Rating:</strong> ' . $tmdb_info['tmdb_vote_average'] . '/10</p>';
        echo '<p><strong>Vote Count:</strong> ' . number_format($tmdb_info['tmdb_vote_count']) . ' votes</p>';
        
        if ($tmdb_info['tmdb_type'] === 'tv' && $tmdb_info['tmdb_season']) {
            echo '<p><strong>Season:</strong> ' . $tmdb_info['tmdb_season'] . '</p>';
        }
        
        echo '</div>';
    }
}

// Example 4: Usage in single.php template
?>
<div class="movie-meta">
    <div class="movie-info">
        <?php
        // Display rating stars
        $rating = halim_display_rating_stars();
        if ($rating) {
            echo '<div class="rating-section">' . $rating . '</div>';
        }
        
        // Display compact rating
        $compact_rating = halim_display_compact_rating();
        if ($compact_rating) {
            echo '<div class="compact-rating-section">' . $compact_rating . '</div>';
        }
        
        // Display external links
        $links = halim_display_external_links();
        if ($links) {
            echo '<div class="external-links-section">' . $links . '</div>';
        }
        
        // Display full TMDB/IMDB info
        $tmdb_info = halim_display_tmdb_imdb_info();
        if ($tmdb_info) {
            echo '<div class="tmdb-imdb-section">' . $tmdb_info . '</div>';
        }
        ?>
    </div>
</div>

<?php
// Example 5: Usage in loop-item.php for movie cards
?>
<div class="movie-card">
    <div class="movie-card-rating">
        <?php 
        $rating_text = halim_get_rating_text();
        if ($rating_text) {
            echo '<span class="rating-badge">' . $rating_text . '</span>';
        }
        ?>
    </div>
    
    <!-- Display compact TMDB/IMDB info -->
    <div class="movie-card-tmdb-imdb">
        <?php 
        $compact_tmdb_imdb = halim_display_compact_tmdb_imdb();
        if ($compact_tmdb_imdb) {
            echo $compact_tmdb_imdb;
        }
        ?>
    </div>
</div>

<?php
// Example 6: Check if movie has IMDB/TMDB data
function example_check_external_data() {
    global $post;
    $tmdb_info = halim_get_tmdb_info($post->ID);
    
    $has_imdb = !empty($tmdb_info['imdb_id']);
    $has_tmdb = !empty($tmdb_info['tmdb_id']);
    
    if ($has_imdb || $has_tmdb) {
        echo '<div class="has-external-data">';
        if ($has_imdb) echo '<span class="imdb-available">IMDB</span>';
        if ($has_tmdb) echo '<span class="tmdb-available">TMDB</span>';
        echo '</div>';
    }
}

// Example 7: Display rating in movie cards
function example_movie_card_rating() {
    global $post;
    
    // Compact rating badge
    $compact_rating = halim_display_compact_rating($post->ID);
    if ($compact_rating) {
        echo '<div class="movie-rating-badge">' . $compact_rating . '</div>';
    }
    
    // Or simple text rating
    $rating_text = halim_get_rating_text($post->ID);
    if ($rating_text) {
        echo '<div class="movie-rating-text">' . $rating_text . '</div>';
    }
}

// Example 8: Display in sidebar or widget
function example_sidebar_tmdb_info() {
    global $post;
    
    $tmdb_info = halim_get_tmdb_info($post->ID);
    
    if ($tmdb_info['tmdb_vote_average'] > 0) {
        echo '<div class="sidebar-rating">';
        echo '<h4>Đánh giá từ TMDB</h4>';
        echo '<div class="rating-display">';
        echo halim_display_rating_stars($post->ID);
        echo '</div>';
        echo '<p>Dựa trên ' . number_format($tmdb_info['tmdb_vote_count']) . ' lượt đánh giá</p>';
        echo '</div>';
    }
}

// Example 9: Display TMDB/IMDB info in sidebar
function example_sidebar_tmdb_imdb_info() {
    global $post;
    
    $sidebar_info = halim_display_sidebar_tmdb_imdb($post->ID);
    if ($sidebar_info) {
        echo $sidebar_info;
    }
}

// Example 10: Display TMDB/IMDB info in movie meta section
function example_movie_meta_tmdb_imdb() {
    global $post;
    
    echo '<div class="movie-meta-tmdb-imdb">';
    
    // Full TMDB/IMDB info
    $full_info = halim_display_tmdb_imdb_info($post->ID);
    if ($full_info) {
        echo $full_info;
    }
    
    // Compact badges
    $compact_badges = halim_display_compact_tmdb_imdb($post->ID);
    if ($compact_badges) {
        echo '<div class="meta-badges">' . $compact_badges . '</div>';
    }
    
    echo '</div>';
}

// Example 11: Display in archive/loop pages
function example_archive_tmdb_imdb() {
    global $post;
    
    // Show compact info for each movie
    $compact_info = halim_display_compact_tmdb_imdb($post->ID);
    if ($compact_info) {
        echo '<div class="archive-tmdb-imdb">' . $compact_info . '</div>';
    }
}
?>

<!-- Example CSS for styling -->
<style>
.movie-rating {
    margin: 15px 0;
}

.movie-external-links {
    margin: 15px 0;
}

.rating-badge {
    background: #f39c12;
    color: white;
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: bold;
}

.has-external-data span {
    display: inline-block;
    margin-right: 5px;
    padding: 2px 6px;
    border-radius: 2px;
    font-size: 10px;
    font-weight: bold;
}

.imdb-available {
    background: #f5de50;
    color: #000;
}

.tmdb-available {
    background: #01b4e4;
    color: #fff;
}
</style>
