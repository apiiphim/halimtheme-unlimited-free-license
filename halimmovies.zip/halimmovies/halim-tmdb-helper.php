<?php
/**
 * TMDB/IMDB Helper Functions for HalimMovies Theme
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Get TMDB/IMDB information for a post
 */
function halim_get_tmdb_info($post_id = null) {
	if (!$post_id) {
		global $post;
		$post_id = $post->ID;
	}
	
	$meta = get_post_meta($post_id, '_halim_metabox_options', true);
	return array(
		'tmdb_id' => $meta['halim_tmdb_id'] ?? '',
		'tmdb_type' => $meta['halim_tmdb_type'] ?? '',
		'tmdb_season' => $meta['halim_tmdb_season'] ?? '',
		'tmdb_vote_average' => $meta['halim_tmdb_vote_average'] ?? ($meta['halim_rating'] ?? 0),
		'tmdb_vote_count' => $meta['halim_tmdb_vote_count'] ?? ($meta['halim_votes'] ?? 0),
		'imdb_id' => $meta['halim_imdb_id'] ?? '',
		'imdb_rating' => $meta['halim_rating'] ?? 0, // TMDB rating stored in halim_rating field
	);
}

/**
 * Get IMDB URL for a post
 */
function halim_get_imdb_url($post_id = null) {
    $tmdb_info = halim_get_tmdb_info($post_id);
    $imdb_id = $tmdb_info['imdb_id'] ?: $tmdb_info['imdb_rating'];
    
    if ($imdb_id && strpos($imdb_id, 'tt') === 0) {
        return "https://www.imdb.com/title/{$imdb_id}/";
    }
    return '';
}

/**
 * Get TMDB URL for a post
 */
function halim_get_tmdb_url($post_id = null) {
    $tmdb_info = halim_get_tmdb_info($post_id);
    
    if ($tmdb_info['tmdb_id']) {
        $type = $tmdb_info['tmdb_type'] === 'tv' ? 'tv' : 'movie';
        return "https://www.themoviedb.org/{$type}/{$tmdb_info['tmdb_id']}";
    }
    return '';
}

/**
 * Display rating stars based on TMDB rating
 */
function halim_display_rating_stars($post_id = null) {
    $tmdb_info = halim_get_tmdb_info($post_id);
    $rating = $tmdb_info['tmdb_vote_average'];
    
    if ($rating > 0) {
        $stars = round($rating / 2, 1); // Convert 10-point to 5-point scale
        $full_stars = floor($stars);
        $half_star = ($stars - $full_stars) >= 0.5;
        $empty_stars = 5 - $full_stars - ($half_star ? 1 : 0);
        
        $output = '<div class="halim-rating-stars" title="TMDB Rating: ' . $rating . '/10">';
        
        // Full stars
        for ($i = 0; $i < $full_stars; $i++) {
            $output .= '<span class="star full">★</span>';
        }
        
        // Half star
        if ($half_star) {
            $output .= '<span class="star half">☆</span>';
        }
        
        // Empty stars
        for ($i = 0; $i < $empty_stars; $i++) {
            $output .= '<span class="star empty">☆</span>';
        }
        
        $output .= " <span class=\"rating-text\">({$rating}/10)</span>";
        $output .= '</div>';
        
        return $output;
    }
    
    return '';
}

/**
 * Get formatted rating text
 */
function halim_get_rating_text($post_id = null) {
    $tmdb_info = halim_get_tmdb_info($post_id);
    
    if ($tmdb_info['tmdb_vote_average'] > 0) {
        return $tmdb_info['tmdb_vote_average'] . '/10';
    }
    
    return '';
}

/**
 * Display external links (IMDB, TMDB)
 */
function halim_display_external_links($post_id = null) {
    $imdb_url = halim_get_imdb_url($post_id);
    $tmdb_url = halim_get_tmdb_url($post_id);
    
    $output = '<div class="halim-external-links">';
    
    if ($imdb_url) {
        $output .= '<a href="' . esc_url($imdb_url) . '" target="_blank" rel="noopener" class="imdb-link">';
        $output .= '<img src="https://img.icons8.com/color/48/000000/imdb.png" alt="IMDB" width="24" height="24"> IMDB';
        $output .= '</a>';
    }
    
    if ($tmdb_url) {
        $output .= '<a href="' . esc_url($tmdb_url) . '" target="_blank" rel="noopener" class="tmdb-link">';
        $output .= '<img src="https://img.icons8.com/?size=96&id=AxHFXpfUuWsm&format=png" alt="TMDB" width="24" height="24"> TMDB';
        $output .= '</a>';
    }
    
    $output .= '</div>';
    
    return ($imdb_url || $tmdb_url) ? $output : '';
}



/**
 * Display compact TMDB/IMDB info (for movie cards)
 */
function halim_display_compact_tmdb_imdb($post_id = null) {
	$tmdb_info = halim_get_tmdb_info($post_id);
	
	if (!$tmdb_info['tmdb_id'] && !$tmdb_info['imdb_id']) {
		return '';
	}
	
	$output = '<div class="halim-compact-tmdb-imdb">';
	
	// TMDB Badge
	if ($tmdb_info['tmdb_id']) {
		$output .= '<span class="tmdb-badge">';
		$output .= '<i class="fa fa-database"></i> TMDB: ' . esc_html($tmdb_info['tmdb_id']);
		if ($tmdb_info['tmdb_type']) {
			$output .= ' (' . esc_html(ucfirst($tmdb_info['tmdb_type'])) . ')';
		}
		if ($tmdb_info['tmdb_season']) {
			$output .= ' S' . esc_html($tmdb_info['tmdb_season']);
		}
		$output .= '</span>';
	}
	
	// IMDB Badge
	if ($tmdb_info['imdb_id']) {
		$output .= '<span class="imdb-badge">';
		$output .= '<i class="fa fa-star"></i> IMDB: ' . esc_html($tmdb_info['imdb_id']);
		$output .= '</span>';
	}
	
	$output .= '</div>';
	
	return $output;
}

/**
 * Display TMDB/IMDB info in sidebar
 */
function halim_display_sidebar_tmdb_imdb($post_id = null) {
	$tmdb_info = halim_get_tmdb_info($post_id);
	
	if (!$tmdb_info['tmdb_id'] && !$tmdb_info['imdb_id']) {
		return '';
	}
	
	$output = '<div class="halim-sidebar-tmdb-imdb">';
	$output .= '<h4>Thông tin bổ sung</h4>';
	
	if ($tmdb_info['tmdb_id']) {
		$output .= '<div class="sidebar-tmdb">';
		$output .= '<p><strong>TMDB ID:</strong> ' . esc_html($tmdb_info['tmdb_id']) . '</p>';
		$output .= '<p><strong>Loại:</strong> ' . esc_html(ucfirst($tmdb_info['tmdb_type'])) . '</p>';
		
		if ($tmdb_info['tmdb_season']) {
			$output .= '<p><strong>Season:</strong> ' . esc_html($tmdb_info['tmdb_season']) . '</p>';
		}
		$output .= '</div>';
	}
	
	if ($tmdb_info['imdb_id']) {
		$output .= '<div class="sidebar-imdb">';
		$output .= '<p><strong>IMDB ID:</strong> ' . esc_html($tmdb_info['imdb_id']) . '</p>';
		$output .= '</div>';
	}
	
	$output .= '</div>';
	
	return $output;
}

/**
 * Display compact TMDB rating info
 */
function halim_display_compact_rating($post_id = null) {
	$tmdb_info = halim_get_tmdb_info($post_id);
	
	if ($tmdb_info['tmdb_vote_average'] <= 0) {
		return '';
	}
	
	$output = '<div class="halim-compact-rating">';
	$output .= '<span class="rating-value">' . $tmdb_info['tmdb_vote_average'] . '</span>';
	$output .= '<span class="rating-max">/10</span>';
	
	if ($tmdb_info['tmdb_vote_count'] > 0) {
		$output .= '<span class="vote-count">(' . number_format($tmdb_info['tmdb_vote_count']) . ' votes)</span>';
	}
	
	$output .= '</div>';
	
	return $output;
}

/**
 * Add CSS for rating stars and external links
 */
function halim_tmdb_styles() {
	echo '<style>
	/* Rating Stars - Đồng bộ với theme HalimMovies */
	.halim-rating-stars {
		display: inline-block;
		font-family: inherit;
	}
	.halim-rating-stars .star {
		color: #f39c12;
		font-size: 18px;
		margin-right: 3px;
		text-shadow: 0 1px 2px rgba(0,0,0,0.1);
	}
	.halim-rating-stars .star.empty {
		color: #bdc3c7;
	}
	.halim-rating-stars .rating-text {
		margin-left: 8px;
		font-size: 13px;
		color: #7f8c8d;
		font-weight: 500;
	}
	
	/* External Links - Style giống buttons của theme */
	.halim-external-links {
		margin: 0;
		padding: 0;
		border: none;
		flex: 0 0 auto;
	}
	.halim-external-links a {
		display: inline-block;
		margin-right: 12px;
		text-decoration: none;
		padding: 6px 12px;
		background: #34495e;
		border-radius: 4px;
		font-size: 12px;
		color: #fff;
		transition: all 0.3s ease;
		border: 1px solid #2c3e50;
	}
	.halim-external-links a:hover {
		background: #2c3e50;
		transform: translateY(-1px);
		box-shadow: 0 2px 4px rgba(0,0,0,0.2);
	}
	.halim-external-links img {
		vertical-align: middle;
		margin-right: 5px;
		width: 16px;
		height: 16px;
	}
	

	
	/* Compact Rating - Style giống rating của theme */
	.halim-compact-rating {
		display: inline-block;
		background: linear-gradient(135deg, #3498db, #2980b9);
		color: white;
		padding: 6px 12px;
		border-radius: 20px;
		font-weight: 600;
		box-shadow: 0 2px 4px rgba(52, 152, 219, 0.3);
	}
	.halim-compact-rating .rating-value {
		font-size: 16px;
		font-weight: 700;
	}
	.halim-compact-rating .rating-max {
		font-size: 12px;
		opacity: 0.9;
	}
	.halim-compact-rating .vote-count {
		font-size: 11px;
		opacity: 0.8;
		margin-left: 8px;
	}
	
	/* Compact TMDB/IMDB badges - Style đồng bộ với theme */
	.halim-compact-tmdb-imdb {
		margin: 8px 0;
		text-align: left;
	}
	.halim-compact-tmdb-imdb .tmdb-badge,
	.halim-compact-tmdb-imdb .imdb-badge {
		display: inline-block;
		margin: 3px;
		padding: 5px 10px;
		border-radius: 15px;
		font-size: 10px;
		font-weight: 600;
		text-decoration: none;
		transition: all 0.3s ease;
		box-shadow: 0 1px 3px rgba(0,0,0,0.2);
	}
	.halim-compact-tmdb-imdb .tmdb-badge {
		background: linear-gradient(135deg, #01b4e4, #0099cc);
		color: white;
		border: 1px solid #0088b3;
	}
	.halim-compact-tmdb-imdb .tmdb-badge:hover {
		background: linear-gradient(135deg, #0099cc, #007399);
		transform: translateY(-1px);
	}
	.halim-compact-tmdb-imdb .imdb-badge {
		background: linear-gradient(135deg, #f5de50, #f1c40f);
		color: #2c3e50;
		border: 1px solid #f39c12;
	}
	.halim-compact-tmdb-imdb .imdb-badge:hover {
		background: linear-gradient(135deg, #f1c40f, #f39c12);
		transform: translateY(-1px);
	}
	.halim-compact-tmdb-imdb i {
		margin-right: 4px;
		font-size: 11px;
	}
	
	/* Sidebar TMDB/IMDB info - Style đồng bộ với sidebar */
	.halim-sidebar-tmdb-imdb {
		background: #fff;
		border: 1px solid #e9ecef;
		border-radius: 6px;
		padding: 16px;
		margin: 16px 0;
		box-shadow: 0 1px 3px rgba(0,0,0,0.1);
	}
	.halim-sidebar-tmdb-imdb h4 {
		margin: 0 0 12px 0;
		color: #2c3e50;
		font-size: 15px;
		border-bottom: 1px solid #ecf0f1;
		padding-bottom: 6px;
		font-weight: 600;
	}
	.halim-sidebar-tmdb-imdb p {
		margin: 6px 0;
		font-size: 13px;
		color: #555;
	}
	.halim-sidebar-tmdb-imdb .sidebar-tmdb,
	.halim-sidebar-tmdb-imdb .sidebar-imdb {
		margin-bottom: 12px;
		padding: 8px;
		background: #f8f9fa;
		border-radius: 4px;
	}
	
	/* TMDB/IMDB Row - Hiển thị rating và external links ngang hàng */
	.tmdb-imdb-row {
		display: block;
		align-items: center;
		justify-content: flex-start;
		margin: 20px 0;
		padding: 0;
		border: none;
		flex-wrap: wrap;
		gap: 20px;
	}
	
	/* Movie Rating Stars - Style cho movie detail */
	.movie-rating-stars {
		margin: 0;
		padding: 0;
		border: none;
		flex: 0 0 auto;
	}
	
	/* Movie TMDB/IMDB sections - Style cho movie detail */
	.movie-tmdb-imdb-compact {
		margin: 20px 0;
		text-align: left;
	}
	.movie-external-links {
		margin: 0;
		padding: 0;
	}
	

	
	/* Responsive adjustments */
	@media (max-width: 768px) {
		.halim-compact-tmdb-imdb .tmdb-badge,
		.halim-compact-tmdb-imdb .imdb-badge {
			display: block;
			margin: 3px 0;
			text-align: left;
		}

		.tmdb-imdb-row {
			flex-direction: column;
			align-items: flex-start;
			text-align: left;
			gap: 15px;
		}
		
		.halim-external-links a {
			display: block;
			margin: 5px 0;
			text-align: left;
		}
		
		.movie-tmdb-imdb-compact {
			text-align: left;
		}

	}
	</style>';
}
add_action('wp_head', 'halim_tmdb_styles');
