<?php get_header(); ?>

	<div class="col-xs-12 carausel-sliderWidget">
		<?php
			dynamic_sidebar('carousel-widget');
		?>
	</div>

	<main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
		<?php
			if( is_active_sidebar( 'home-widget' ) ) {
			    dynamic_sidebar( 'home-widget' );
			}
			else { ?>
				<div class="post-content" style="padding: 50px;">
					<div class="startPage box-shadow2">
						<p style="margin: 0"><?php _e('This is widget area. Go to Appearance -> Widgets to add some widgets.', 'halimthemes'); ?></p>
					</div>
				</div>

			<?php
		}
		?>
	</main>

<?php get_sidebar(); get_footer(); ?>