<?php
/**
 * Plugin Name: Bảo Vệ An Toàn HalimMovies
 * Plugin URI: https://t.me/apiionlines
 * Description: Plugin bảo mật toàn diện để bảo vệ theme HalimMovies khỏi các kết nối trái phép và theo dõi từ xa. Chia sẻ bởi Apii.
 * Version: 1.0.0
 * Author: Apii
 * Author URI: https://t.me/apiionlines
 * Text Domain: halim-security
 * Domain Path: /languages
 * Network: false
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Requires at least: 5.0
 * Tested up to: 6.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

/**
 * Plugin được chia sẻ bởi Apii
 * Telegram: https://t.me/apiionlines  
 * Nhóm hỗ trợ DEV với 304 thành viên
 * 
 * Chức năng bảo mật toàn diện:
 * - Chặn tất cả kết nối đến halimthemes.com và subdomain
 * - Bảo vệ thư mục theme khỏi truy cập trực tiếp
 * - Giám sát và ghi log các hoạt động đáng ngờ
 * - Tạo fake response cho license requests
 * - Bảo vệ theme khỏi update checks và tracking
 * - Thêm security headers và làm sạch thông tin server
 */

class HalimSecurityGuard {
    
    private $blocked_domains = [
        'halimthemes.com',
        'halimthemes.test',
        'halimthemes.net',
        'halimthemes.org',
        'halimthemes.info',
        'api.halimthemes.com',
        'license.halimthemes.com',
        'update.halimthemes.com',
        'cdn.halimthemes.com'
    ];
    
    private $theme_path;
    
    public function __construct() {
        $this->theme_path = get_template_directory();
        $this->init_hooks();
    }
    
    private function init_hooks() {
        // Block outbound HTTP requests
        add_filter('pre_http_request', [$this, 'block_suspicious_requests'], 1, 3);
        add_filter('http_request_args', [$this, 'modify_request_args'], 1, 2);
        add_filter('http_response', [$this, 'filter_responses'], 1, 3);
        
        // Protect theme directory
        add_action('init', [$this, 'protect_theme_directory']);
        
        // Fix .htaccess if needed
        add_action('admin_init', [$this, 'fix_htaccess_if_needed']);
        
        // Block direct file access
        add_action('template_redirect', [$this, 'block_direct_access']);
        
        // Monitor and log suspicious activities
        add_action('wp_loaded', [$this, 'monitor_activities']);
        
        // Clean up traces
        add_filter('wp_headers', [$this, 'clean_headers']);
        
        // Block theme update checks
        add_filter('pre_set_site_transient_update_themes', [$this, 'block_theme_updates']);
    }
    
    public function block_suspicious_requests($preempt, $args, $url) {
        $host = strtolower(wp_parse_url($url, PHP_URL_HOST) ?? '');
        
        // Block all requests to blocked domains
        if ($this->is_blocked_domain($host)) {
            $this->log_blocked_request($url, 'Blocked domain');
            
            // Return fake success response for license requests
            if (strpos($url, 'license') !== false || strpos($url, 'activate') !== false) {
                return $this->create_fake_success_response();
            }
            
            // Return empty response for other requests
            return new WP_Error('blocked_domain', 'Domain blocked by security policy');
        }
        
        // Block requests containing theme-related data
        $body = '';
        if (isset($args['body'])) {
            if (is_string($args['body'])) $body = $args['body'];
            elseif (is_array($args['body'])) $body = http_build_query($args['body']);
        }
        
        if ($this->contains_theme_data($body)) {
            $this->log_blocked_request($url, 'Theme data detected');
            return new WP_Error('blocked_theme_data', 'Theme data transmission blocked');
        }
        
        return $preempt;
    }
    
    public function modify_request_args($args, $url) {
        $host = strtolower(wp_parse_url($url, PHP_URL_HOST) ?? '');
        
        if ($this->is_blocked_domain($host)) {
            // Make request fail quickly
            $args['timeout'] = 0.1;
            $args['blocking'] = false;
            $args['sslverify'] = false;
        }
        
        return $args;
    }
    
    public function filter_responses($response, $args, $url) {
        $host = strtolower(wp_parse_url($url, PHP_URL_HOST) ?? '');
        
        if ($this->is_blocked_domain($host)) {
            $body = wp_remote_retrieve_body($response);
            
            // Replace failed license responses with success
            if (strpos($body, '"success":false') !== false && strpos($body, 'license') !== false) {
                $response['body'] = wp_json_encode($this->get_success_data());
                $this->log_activity('Modified license response to success');
            }
        }
        
        return $response;
    }
    
    public function protect_theme_directory() {
        $htaccess_path = $this->theme_path . '/.htaccess';
        
        if (!file_exists($htaccess_path)) {
            $rules = "# HalimMovies Security Protection\n";
            $rules .= "Options -Indexes\n";
            $rules .= "Options -ExecCGI\n";
            
            // Block PHP files but allow essential ones
            $rules .= "<Files *.php>\n";
            $rules .= "    Order Allow,Deny\n";
            $rules .= "    Deny from all\n";
            $rules .= "</Files>\n";
            
            // Allow essential PHP files
            $rules .= "<Files index.php>\n";
            $rules .= "    Order Allow,Deny\n";
            $rules .= "    Allow from all\n";
            $rules .= "</Files>\n";
            
            $rules .= "<Files player.php>\n";
            $rules .= "    Order Allow,Deny\n";
            $rules .= "    Allow from all\n";
            $rules .= "</Files>\n";
            
            $rules .= "<Files halim-ajax.php>\n";
            $rules .= "    Order Allow,Deny\n";
            $rules .= "    Allow from all\n";
            $rules .= "</Files>\n";
            
            // Block suspicious user agents but allow legitimate requests
            $rules .= "RewriteEngine On\n";
            $rules .= "# Block suspicious bots but allow legitimate crawlers\n";
            $rules .= "RewriteCond %{HTTP_USER_AGENT} (wget|curl|python|scraper) [NC]\n";
            $rules .= "RewriteCond %{HTTP_REFERER} !^https?://" . $_SERVER['HTTP_HOST'] . " [NC]\n";
            $rules .= "RewriteRule .* - [F,L]\n";
            
            @file_put_contents($htaccess_path, $rules);
        }
    }
    
    public function block_direct_access() {
        $request_uri = $_SERVER['REQUEST_URI'] ?? '';
        $theme_uri = str_replace(ABSPATH, '/', $this->theme_path);
        
        // Block direct access to theme files (but allow AJAX and legitimate requests)
        if (strpos($request_uri, $theme_uri) === 0) {
            $file_path = ABSPATH . ltrim($request_uri, '/');
            
            if (file_exists($file_path) && !is_dir($file_path)) {
                // Allow essential theme files
                $allowed_files = [
                    'style.css', 
                    'screenshot.png', 
                    'index.php',
                    'player.php',        // Allow player requests
                    'halim-ajax.php',    // Allow AJAX requests
                    'functions.php'      // Allow if called by WordPress
                ];
                
                $filename = basename($file_path);
                
                // Allow if it's an AJAX request or has valid nonce
                if ($this->is_legitimate_request()) {
                    return;
                }
                
                // Allow if it's from same domain (not external)
                $referer = $_SERVER['HTTP_REFERER'] ?? '';
                $site_url = home_url();
                if (strpos($referer, $site_url) === 0) {
                    return;
                }
                
                if (!in_array($filename, $allowed_files)) {
                    $this->log_activity('Blocked direct file access: ' . $request_uri);
                    wp_die('Access denied', 'Security', ['response' => 403]);
                }
            }
        }
    }
    
    private function is_legitimate_request() {
        // Check if it's an AJAX request
        if (defined('DOING_AJAX') && DOING_AJAX) {
            return true;
        }
        
        // Check if it's from WordPress admin
        if (is_admin()) {
            return true;
        }
        
        // Check if has valid nonce
        if (isset($_REQUEST['nonce']) && wp_verify_nonce($_REQUEST['nonce'], 'wp_rest')) {
            return true;
        }
        
        // Check if it's from same site
        $referer = $_SERVER['HTTP_REFERER'] ?? '';
        $site_url = home_url();
        if (strpos($referer, $site_url) === 0) {
            return true;
        }
        
        // Check for AJAX headers
        $ajax_headers = [
            'HTTP_X_REQUESTED_WITH' => 'XMLHttpRequest',
            'CONTENT_TYPE' => 'application/x-www-form-urlencoded'
        ];
        
        foreach ($ajax_headers as $header => $value) {
            if (isset($_SERVER[$header]) && strpos($_SERVER[$header], $value) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    public function fix_htaccess_if_needed() {
        // Force recreate .htaccess with correct rules
        $htaccess_path = $this->theme_path . '/.htaccess';
        
        if (file_exists($htaccess_path)) {
            $content = file_get_contents($htaccess_path);
            
            // If .htaccess doesn't contain player.php rules, recreate it
            if (strpos($content, 'player.php') === false || strpos($content, 'halim-ajax.php') === false) {
                unlink($htaccess_path);
                $this->protect_theme_directory();
                $this->log_activity('Fixed .htaccess rules for theme functionality');
            }
        }
    }
    
    public function monitor_activities() {
        // Monitor suspicious POST requests
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $suspicious_keys = ['license', 'activate', 'update', 'download', 'verify'];
            
            foreach ($suspicious_keys as $key) {
                if (isset($_POST[$key]) || isset($_GET[$key])) {
                    $this->log_activity('Suspicious request detected: ' . $key);
                    break;
                }
            }
        }
        
        // Monitor file modifications in theme directory
        $this->check_theme_integrity();
    }
    
    public function clean_headers($headers) {
        // Remove revealing headers
        unset($headers['X-Powered-By']);
        unset($headers['Server']);
        
        // Add security headers
        $headers['X-Content-Type-Options'] = 'nosniff';
        $headers['X-Frame-Options'] = 'SAMEORIGIN';
        $headers['X-XSS-Protection'] = '1; mode=block';
        
        return $headers;
    }
    
    public function block_theme_updates($transient) {
        if (isset($transient->response)) {
            $theme_name = get_option('template');
            if (isset($transient->response[$theme_name])) {
                unset($transient->response[$theme_name]);
                $this->log_activity('Blocked theme update check');
            }
        }
        
        return $transient;
    }
    
    private function is_blocked_domain($host) {
        foreach ($this->blocked_domains as $domain) {
            if ($host === $domain || str_ends_with($host, '.' . $domain)) {
                return true;
            }
        }
        return false;
    }
    
    private function contains_theme_data($body) {
        $theme_indicators = [
            'halimmovies',
            'halim',
            get_option('template'),
            get_option('stylesheet'),
            'theme_name',
            'theme_version'
        ];
        
        $body_lower = strtolower($body);
        foreach ($theme_indicators as $indicator) {
            if (strpos($body_lower, strtolower($indicator)) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    private function create_fake_success_response() {
        return [
            'response' => [
                'code' => 200,
                'message' => 'OK'
            ],
            'headers' => [
                'content-type' => 'application/json; charset=UTF-8',
                'date' => gmdate('D, d M Y H:i:s') . ' GMT'
            ],
            'body' => wp_json_encode($this->get_success_data()),
            'cookies' => []
        ];
    }
    
    private function get_success_data() {
        return [
            'success' => true,
            'license' => 'valid',
            'item_id' => '154',
            'item_name' => 'HaLimMovie',
            'checksum' => md5(time()),
            'expires' => 'lifetime',
            'payment_id' => 123456,
            'customer_name' => 'Licensed User',
            'customer_email' => 'user@localhost.com',
            'license_limit' => 0,
            'site_count' => 1,
            'activations_left' => 'unlimited',
            'price_id' => null
        ];
    }
    
    private function check_theme_integrity() {
        $hash_file = $this->theme_path . '/.security_hash';
        $current_hash = $this->get_theme_hash();
        
        if (file_exists($hash_file)) {
            $stored_hash = file_get_contents($hash_file);
            if ($stored_hash !== $current_hash) {
                $this->log_activity('Theme files modified - hash mismatch');
            }
        }
        
        file_put_contents($hash_file, $current_hash);
    }
    
    private function get_theme_hash() {
        $files = glob($this->theme_path . '/*.php');
        $content = '';
        
        foreach ($files as $file) {
            if (is_readable($file)) {
                $content .= filemtime($file) . filesize($file);
            }
        }
        
        return md5($content);
    }
    
    private function log_blocked_request($url, $reason) {
        $this->log_activity("BLOCKED REQUEST: {$reason} - {$url}");
    }
    
    private function log_activity($message) {
        $log_file = WP_CONTENT_DIR . '/security.log';
        $timestamp = date('Y-m-d H:i:s');
        $ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'unknown';
        
        $log_entry = "[{$timestamp}] IP: {$ip} | UA: {$user_agent} | {$message}\n";
        
        error_log($log_entry, 3, $log_file);
    }
}

// Initialize the security guard
new HalimSecurityGuard();
