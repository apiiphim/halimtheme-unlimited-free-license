<?php
/**
 * Plugin Name: Bỏ Qua Kiểm Tra License HalimMovies
 * Plugin URI: https://t.me/apiionlines
 * Description: Plugin đơn giản để bỏ qua kiểm tra license cho theme HalimMovies. Chia sẻ bởi Apii.
 * Version: 1.0.0
 * Author: Apii
 * Author URI: https://t.me/apiionlines
 * Text Domain: simple-license-bypass
 * Domain Path: /languages
 * Network: false
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

if (!defined('ABSPATH')) exit;

/**
 * Plugin được chia sẻ bởi Apii
 * Telegram: https://t.me/apiionlines
 * Nhóm hỗ trợ DEV với 304 thành viên
 * 
 * Chức năng: Bỏ qua kiểm tra license cho theme HalimMovies
 * - Chặn tất cả request đến halimthemes.com
 * - Thay đổi response thất bại thành thành công
 * - Đảm bảo theme hoạt động bình thường mà không cần license hợp lệ
 */

// Simple HTTP response interceptor
add_filter('http_response', function($response, $args, $url) {
    $host = strtolower(wp_parse_url($url, PHP_URL_HOST) ?? '');
    
    // Only intercept halimthemes.com requests
    if ($host === 'halimthemes.com' || $host === 'halimthemes.test') {
        $body = wp_remote_retrieve_body($response);
        
        // If response contains license-related data, modify it
        if (strpos($body, '"success":false') !== false && strpos($body, 'license') !== false) {
            // Replace the failed response with success
            $success_response = [
                'success' => true,
                'license' => 'valid',
                'item_id' => '154',
                'item_name' => 'HaLimMovie',
                'checksum' => '5a876e003cf6aa01b92f8a2005272b33',
                'expires' => 'lifetime',
                'payment_id' => 123456,
                'customer_name' => 'Licensed User',
                'customer_email' => 'user@halimthemes.com',
                'license_limit' => 0,
                'site_count' => 1,
                'activations_left' => 'unlimited',
                'price_id' => null
            ];
            
            // Modify the response body
            $response['body'] = wp_json_encode($success_response);
            
            // Log the modification
            error_log('License response modified: ' . $url);
        }
    }
    
    return $response;
}, 10, 3);

// Backup: Also intercept pre_http_request as last resort
add_filter('pre_http_request', function($preempt, $args, $url) {
    $host = strtolower(wp_parse_url($url, PHP_URL_HOST) ?? '');
    
    if ($host === 'halimthemes.com' || $host === 'halimthemes.test') {
        $body = '';
        if (isset($args['body'])) {
            if (is_string($args['body'])) $body = $args['body'];
            elseif (is_array($args['body'])) $body = http_build_query($args['body']);
        }
        
        // Check if this is a license request
        if (strpos($body, 'edd_action=') !== false && strpos($body, 'license=') !== false) {
            $success_response = [
                'success' => true,
                'license' => 'valid',
                'item_id' => '154',
                'item_name' => 'HaLimMovie',
                'checksum' => '5a876e003cf6aa01b92f8a2005272b33',
                'expires' => 'lifetime',
                'payment_id' => 123456,
                'customer_name' => 'Licensed User',
                'customer_email' => 'user@halimthemes.com',
                'license_limit' => 0,
                'site_count' => 1,
                'activations_left' => 'unlimited',
                'price_id' => null
            ];
            
            error_log('License request intercepted: ' . $url);
            
            return [
                'response' => [
                    'code' => 200,
                    'message' => 'OK'
                ],
                'headers' => [
                    'content-type' => 'application/json; charset=UTF-8',
                    'date' => gmdate('D, d M Y H:i:s') . ' GMT',
                    'server' => 'cloudflare'
                ],
                'body' => wp_json_encode($success_response),
                'cookies' => []
            ];
        }
    }
    
    return $preempt;
}, 1, 3);
