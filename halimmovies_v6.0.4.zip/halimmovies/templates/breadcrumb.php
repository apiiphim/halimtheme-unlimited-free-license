<div class="halim-breadcrumb-panel">
    <div class="panel-heading">
        <?php
            if(function_exists('yoast_breadcrumb')) {
                yoast_breadcrumb('<div class="yoast_breadcrumb">','</div>');
            } elseif(function_exists("seopress_display_breadcrumbs")) {
                seopress_display_breadcrumbs();
            } elseif(function_exists('rank_math_the_breadcrumbs')) {
                rank_math_the_breadcrumbs();
            } else {
                // custom breadcrumb
            }
		?>
    </div>
</div>

