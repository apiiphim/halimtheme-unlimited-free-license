<?php $date = explode(' ', esc_html($post->post_date))[0]; ?>
<div class="title-block watch-page">
    <div id="bookmark" class="bookmark-img-animation primary_ribbon pointer" data-post_id="<?php echo $post->ID; ?>" data-thumbnail="<?php echo esc_url(halim_image_display()) ?>" data-href="<?php get_the_permalink(); ?>" data-title="<?php echo $post->post_title; ?>" data-date="<?php echo $date; ?>">
    </div>
    <div class="title-wrapper full">
        <h1 class="entry-title"><a href="<?php echo get_the_permalink(); ?>" title="<?php echo halim_get_the_title($post->ID); ?>" class="tl"><?php echo halim_get_the_title($post->ID); ?></a></h1>
        <span class="plot-collapse" data-toggle="collapse" data-target="#expand-post-content" aria-expanded="false" aria-controls="expand-post-content" data-text="<?php _e('Movie plot', 'halimthemes'); ?>"><i class="hl-angle-down"></i></span>
    </div>
    <div class="ratings_wrapper">
        <?php echo halim_get_user_rate(); ?>
    </div>
</div>