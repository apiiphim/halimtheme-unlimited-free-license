<?php
    ob_start();
    $categories = get_categories();
    $country = get_terms('country');
    $release = get_terms('release');
    $status = get_terms('status');
        ?><div class="halim-search-filter">
        <div class="btn-group col-md-12">
                <form id="form-filter" class="form-inline" method="GET" action="<?php echo esc_url(home_url('/filter-movies')); ?>">
                    <div class="col-md-1 col-xs-12 col-sm-6">
                        <div class="filter-box">
                        <div class="filter-box-title"><?php _e('Sort by', 'halimthemes') ?></div>
                            <select class="form-control" id="sort" name="sort">
                                <option value="sort"><?php _e('Sort by', 'halimthemes') ?></option>
                                <option value="posttime"><?php _e('Newest', 'halimthemes') ?></option>
                                <option value="viewcount"><?php _e('Most viewed', 'halimthemes') ?></option>
                                <option value="updatetime"><?php _e('Latest update', 'halimthemes') ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-1 col-xs-12 col-sm-6">
                        <div class="filter-box">
                        <div class="filter-box-title"><?php _e('Types', 'halimthemes') ?></div>
                            <select class="form-control" id="type" name="types">
                                <option value="types"><?php _e('Types', 'halimthemes') ?></option>
                                <option value="movies"><?php _e('Movies', 'halimthemes') ?></option>
                                <option value="tv_series"><?php _e('TV Series', 'halimthemes') ?></option>
                                <option value="tv_shows"><?php _e('TV Shows', 'halimthemes') ?></option>
                                <option value="theater_movie"><?php _e('Theater movie', 'halimthemes') ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-2 col-xs-12 col-sm-6">
                        <div class="filter-box">
                        <div class="filter-box-title"><?php _e('Status', 'halimthemes') ?></div>
                            <select class="form-control" name="status">
                                <option value="status"><?php _e('Status', 'halimthemes') ?></option>
                                <?php foreach($status as $value): ?>
                                    <option value="<?php echo sanitize_title($value->slug); ?>"><?php echo esc_html($value->name); ?></option>
                                <?php endforeach;?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-2 col-xs-12 col-sm-6">
                        <div class="filter-box">
                        <div class="filter-box-title"><?php _e('Country', 'halimthemes') ?></div>
                            <select class="form-control" name="country">
                                <option value="country"><?php _e('Country', 'halimthemes') ?></option>
                                <?php foreach($country as $value): ?>
                                    <option value="<?php echo sanitize_title($value->slug); ?>">
                                        <?php echo esc_html($value->name); ?>
                                        </option>
                                <?php endforeach;?>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-1 col-xs-12 col-sm-6">
                        <div class="filter-box">
                        <div class="filter-box-title"><?php _e('Release', 'halimthemes') ?></div>
                            <select class="form-control" name="release">
                                <option value="release"><?php _e('Release', 'halimthemes') ?></option>
                                <?php foreach($release as $year):?>
                                    <option value="<?php echo esc_html($year->slug) ?>"><?php echo esc_html($year->name)?></option>
                                <?php endforeach;?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-3 col-xs-12 col-sm-6">
                        <div class="filter-box">
                        <div class="filter-box-title"><?php _e('Genres', 'halimthemes') ?></div>
                            <select class="form-control" id="category" name="category">
                                <option value="category"><?php _e('Genres', 'halimthemes') ?></option>
                                <?php foreach($categories as $cat):?>
                                    <option value="<?php echo esc_html($cat->term_id)?>"><?php echo esc_html($cat->cat_name)?></option>
                                <?php endforeach;?>
                            </select>
                        </div>
                    </div>

                    <div class="col-md-2 col-xs-12 col-sm-6">
                        <button type="submit" id="btn-movie-filter" class="btn btn-danger"><?php _e('Filter movie', 'halimthemes') ?></button>
                    </div>
                </form>
            </div>
        </div>
<?php $html = ob_get_clean(); ?>
<div id="filter-movie" class="panel-collapse collapse" aria-expanded="true" role="menu"></div>
<script>var filterMovieHTML = '<?php echo HaLim\Helpers\Helper::compress_htmlcode($html); ?>';</script>

