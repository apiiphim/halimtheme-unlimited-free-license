<div class="user user-login-option box-shadow" id="pc-user-login">
    <div class="dropdown">
        <a href="javascript:;" class="avt" id="userInfo" onclick="openLoginModal();">
            <img alt="" src="//0.gravatar.com/avatar/?s=20&amp;d=mm&amp;r=g" srcset="//1.gravatar.com/avatar/?s=40&amp;d=mm&amp;r=g 2x" class="avatar avatar-20 photo avatar-default" height="20" width="20" decoding="async">
            <span class="name"><?php _e( 'Login', 'halimthemes' ); ?></span>
        </a>
    </div>
</div>
