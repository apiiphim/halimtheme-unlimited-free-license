<?php

use HaLim\Player\Servers;

class halim_youtube_com extends Servers
{
	function get_link($link)
	{
		$yt = new HaLim\Player\YouTube();
		$json = $yt->getDownloadLinks($link);
		return json_encode($json);
	}
}
