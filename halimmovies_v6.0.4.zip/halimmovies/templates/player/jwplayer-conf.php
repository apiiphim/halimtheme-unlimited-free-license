<?php
    $post_id = $args['post_id'];
    $link = $args['link'];
    $cache_time         = cs_get_option('player_cache_time');
    $player_ad_cfg      = cs_get_option('halim_jw_player_ads');
    $player_cfg         = cs_get_option('halim_jw_player_options');
    $detect_adblock     = cs_get_option('detect_adblock');
    $adblock_msg        = cs_get_option('adblock_msg')?:'<p style="padding-top:15px;"><h2>Sorry!</h2> Users please remove ad blocker!</p>';
    $floating_player    = cs_get_option('floating_player');
    $meta               = get_post_meta($post_id, '_halim_metabox_options', true );
    $player_logo        = !empty($player_cfg['jw_player_logo'])?$player_cfg['jw_player_logo']:'';
    $player_logo_hide   = isset($player_cfg['jw_player_logo_hide'])?$player_cfg['jw_player_logo_hide']:false;
    $logo_position      = !empty($player_cfg['jw_player_logo_position'])?$player_cfg['jw_player_logo_position']:'';
    $player_logo_link   = !empty($player_cfg['jw_player_logo_link'])?$player_cfg['jw_player_logo_link']:'https://halimthemes.com';
    $captions_color     = !empty($player_cfg['jw_tracks_color'])?$player_cfg['jw_tracks_color']:'#eeee22';
    $captions_font_size = !empty($player_cfg['jw_tracks_font_size'])?$player_cfg['jw_tracks_font_size']:12;
    $jwplayer_key       = !empty($player_cfg['jw_player_license_key'])?$player_cfg['jw_player_license_key']:'MBvrieqNdmVL4jV0x6LPJ0wKB/Nbz2Qq/lqm3g==';
    $player_sharing     = !empty($player_cfg['jw_player_sharing_block'])?$player_cfg['jw_player_sharing_block']:'';
    $autoplay           = isset($player_cfg['jw_player_autoplay'])?$player_cfg['jw_player_autoplay']: 'false';
    $autopause          = isset($player_cfg['jw_player_autopause'])?$player_cfg['jw_player_autopause']: 'false';
    $poster             = !empty($meta['halim_poster_url'])?$meta['halim_poster_url']:'';
    $jw_adcode          = !empty($player_ad_cfg['jw_player_custom_ads_code'])?$player_ad_cfg['jw_player_custom_ads_code']:'';
    $tracks             = $args['tracks'];
    $sources            = $args['sources'];
    $timeleft = '';
    if(preg_match('#{{timeleft:(.*?)}}#', $sources, $timeleft)){
        $timeleft = $timeleft[1];
    }

    if(empty($sources) || $sources == '[]' || $sources == null || !json_decode($sources)[0]->file){
        $sources = '[{ file: "//content.jwplatform.com/videos/not-a-real-video-file.mp4", label: "720p", type: "video/mp4"}]';
    }
?>
<script>
    var resumeId = encodeURI('<?php echo md5($sources); ?>'),
        playerInstance = jwplayer('<?php echo cs_get_option('player_types') == 'html' ? 'html-player' : 'ajax-player'; ?>');
        playerCountDown = <?php echo (int)$timeleft; ?>;

    if(typeof playerInstance != 'undefined')
    {
        if(playerCountDown) {
            $('<div id="halim-player-timeleft"><span id="counter">Còn lại <span>'+playerCountDown+'</span> giây<p class="txt">Video đang xử lý, vui lòng chờ!</p></div>').insertBefore('#halim-player-loader').css('display', 'block');
            var $ = jQuery.noConflict();
            var timeout, interval
            var threshold = <?php echo ((int)$timeleft * 1000); ?>;
            var secondsleft = threshold;
            startschedule();
        }

        playerInstance.setup({
            key: "<?php echo $jwplayer_key; ?>",
            primary: "html5",
            playlist: [{
                title: "<?php echo get_the_title($post_id); ?>",
                image: "<?php echo $poster; ?>",
                sources: <?php echo $sources; ?>,
                tracks: <?php echo $tracks; ?>,
                captions: {
                    color: "<?php echo $captions_color; ?>",
                    fontSize: <?php echo $captions_font_size; ?>,
                    backgroundOpacity: 0,
                    edgeStyle: "raised"
                }
            }],
            <?php if($player_logo) : ?>
            logo: {
                file: "<?php echo $player_logo; ?>",
                link: "<?php echo $player_logo_link; ?>",
                hide: "<?php echo $player_logo_hide; ?>",
                target: "_blank",
                position: "<?php echo $logo_position; ?>",
            },
            <?php endif; ?>
            <?php if($floating_player) : ?>
            floating: {
                dismissible: true
            },
            <?php endif; ?>
            <?php if($autopause) : ?>
            autoPause: {
                viewability: true,
                pauseAds: true
            },
            <?php endif; ?>
            base: ".",
            cast: {
                enable: true
            },
            pip: true,
            width: "100%",
            height: "100%",
            hlshtml: true,
            autostart: <?php echo $autoplay; ?>,
            fullscreen: true,
            playbackRateControls: true,
            displayPlaybackLabel: true,
            aspectratio: "16:9",
            <?php if($player_sharing == true) : ?>
            sharing: {
                sites: ["reddit","facebook","twitter","googleplus","email","linkedin"]
            },
            <?php endif; ?>
            <?php echo $jw_adcode; ?>
        });
        halimJwConfig(playerInstance);
        playerInstance.addButton('<?php echo HALIM_THEME_URI.'/assets/images/forward.svg';?>', "Forward 10 Seconds", () => playerInstance.seek(playerInstance.getPosition() + 10), "Forward 10 seconds");
        playerInstance.addButton('<?php echo HALIM_THEME_URI.'/assets/images/rewind.svg';?>', "Rewind 10 seconds", () => playerInstance.seek(playerInstance.getPosition() - 10), "Rewind 10 Seconds");
        playerInstance.on('ready', function(){
            jQuery("#halim-player-loader").hide();
        });
        halimResumeVideo(resumeId, playerInstance);
        <?php if($detect_adblock) : ?>
            playerInstance.on('adBlock', function(){
                playerInstance.pause();
                jQuery("#halim-player-loader").show().html('<?php echo HaLim\Helpers\Helper::compress_htmlcode($adblock_msg); ?>');
            });
        <?php endif; ?>
    }
</script>