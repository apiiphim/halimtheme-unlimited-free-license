<?php
	get_header();
	$term_id = get_queried_object()->term_id;
	$term_slug = get_queried_object()->slug;
?>
<main id="main-contents" class="col-xs-12 col-sm-12 col-md-8">
	<section>
		<?php if ( is_active_sidebar( 'halim-ad-above-category' ) ) { ?>
		    <div class="a--d-wrapper" style="text-align: center; margin: 10px 0;">
		        <?php dynamic_sidebar( 'halim-ad-above-category' ); ?>
		    </div>
		<?php } ?>
		<div class="section-bar clearfix">
		   <h3 class="section-title">
			<span><i class="hl-calendar"></i> <?php single_tag_title();?></span>
		   </h3>
		</div>

		<div class="halim_box section-showtimes-movie">
			<div class="halim-ajax-get-post-loading halim-ajax-popular-post-loading-<?php echo $term_slug; ?> hidden"></div>
				<div id="ajax-showtimes-widget-<?php echo $term_slug; ?>">
				<?php

					showtimes_term_children($term_id, $term_slug, '4col', 'taxonomy');
					$args = array(
						'post_type'			=> 'post',
						'posts_per_page' 	=> get_option('posts_per_page'),
						'post_status' 		=> 'publish',
						'orderby'			=> 'modified'
					);
			        $args['tax_query'] = array(
				        array(
				            'taxonomy' => 'showtimes',
				            'field' => 'slug',
				            'terms' => $term_slug,
				            'operator' => 'IN'
				        )
			        );
					$wp_query = new WP_Query( $args );

					if($wp_query->have_posts()): while($wp_query->have_posts()): $wp_query->the_post();
						get_template_part( 'templates/loop', 'item');
					endwhile;
				?>
			</div>
		<div class="clearfix"></div>
		<?php halim_pagination(); ?>
	</div>
	<?php endif;?>
		<?php if ( is_active_sidebar( 'halim-ad-below-category' ) ) { ?>
		    <div class="a--d-wrapper" style="text-align: center; margin: 10px 0;">
		        <?php dynamic_sidebar( 'halim-ad-below-category' ); ?>
		    </div>
		<?php } ?>
	</section>
</main>
<?php get_sidebar(); get_footer(); ?>