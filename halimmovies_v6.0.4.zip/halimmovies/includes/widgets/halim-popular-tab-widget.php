<?php

class halim_tab_popular_Widget extends WP_Widget {

	public function __construct() {
		parent::__construct(
			'halim_tab_popular_videos-widget',
			__( 'HaLim Polpular Movies', 'halimthemes' ),
			array(
				'classname'   => 'halim_tab_popular_videos-widget',
				'description' => __( 'Display popular post by day, week, month and alltime', 'halimthemes' )
			)
		);
	}

	function widget($args, $instance)
	{
		global $post;
		extract($args);
		extract($instance);
		echo $before_widget;
		if($title != '') : ?>
			<div class="section-bar clearfix">
				<div class="section-title">
					<span><i class="hl-fire"></i> <?php echo $title; ?></span>
					<ul class="halim-popular-tab" role="tablist">
						<li role="presentation">
							<a class="ajax-tab" role="tab" data-toggle="tab" data-showpost="<?php echo $postnum; ?>" data-show_view_count="<?php echo $show_view_count; ?>" data-rand="<?php echo $rand ?>" data-type="day"><?php _e('Day', 'halimthemes') ?></a>
						</li>
						<li role="presentation" class="active">
							<a class="ajax-tab" role="tab" data-toggle="tab" data-showpost="<?php echo $postnum; ?>" data-show_view_count="<?php echo $show_view_count; ?>" data-rand="<?php echo $rand ?>" data-type="week"><?php _e('Week', 'halimthemes') ?></a>
						</li>
						<li role="presentation">
							<a class="ajax-tab" role="tab" data-toggle="tab" data-showpost="<?php echo $postnum; ?>" data-show_view_count="<?php echo $show_view_count; ?>" data-rand="<?php echo $rand ?>" data-type="month"><?php _e('Month', 'halimthemes') ?></a>
						</li>
						<li role="presentation">
							<a class="ajax-tab" role="tab" data-toggle="tab" data-showpost="<?php echo $postnum; ?>" data-show_view_count="<?php echo $show_view_count; ?>" data-rand="<?php echo $rand ?>" data-type="all"><?php _e('All', 'halimthemes') ?></a>
						</li>
					</ul>
				</div>
			</div>
		<?php endif ?>
	   <section class="tab-content">
			<div role="tabpanel" class="tab-pane active halim-ajax-popular-post">
				<div class="halim-ajax-popular-post-loading hidden"></div>
				<div id="halim-ajax-popular-post" class="popular-post">
					<?php
						$args = array(
							'post_type' => 'post',
							'posts_per_page' => $postnum,
							'orderby' => 'meta_value_num',
							'meta_query' => array(
								'relation' => 'AND',
								array('key' => 'halim_view_post_week'),
							),
						);
						if($rand == 1) {
							$args['orderby'] = 'rand';
						}

						$day = new WP_Query( $args );
						if ($day->have_posts()) : while ($day->have_posts()) : $day->the_post();
							get_template_part( 'templates/loop', 'popular', ['type' => 'day', 'show_info' => false, 'show_view_count' => $show_view_count, 'rand' => $rand] );
						endwhile; endif; wp_reset_postdata(); ?>
				</div>
			</div>
		</section>
		<div class="clearfix"></div>
	<?php
		echo $after_widget;
	}

	function update($new_instance, $old_instance)
	{
		$instance = $old_instance;
		$instance['title']  	= strip_tags( $new_instance['title'] );
		$instance['rand'] 		= $new_instance['rand'];
		$instance['show_view_count'] = $new_instance['show_view_count'];
		$instance['postnum'] 	= $new_instance['postnum'];
		return $instance;
	}

	function form($instance)
	{
		$defaults = array(
			'title' => __('Popular', 'halimthemes'),
			'postnum' => 6,
			'show_view_count' => 0,
			'rand' => 0
		);
		$instance = wp_parse_args((array) $instance, $defaults);

		extract($instance);
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title', 'halimthemes') ?></label>
			<br />
			<input class="widefat" type="text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
		</p>

		<p class="random" style="clear: both; display:block;">
			<label for="<?php echo $this->get_field_id("rand"); ?>">
				<input id="<?php echo $this->get_field_id("rand"); ?>" class="rand" name="<?php echo $this->get_field_name("rand"); ?>" type="checkbox" value="1" <?php if (isset($rand)) { checked($rand, 1 ); } ?>/> <?php _e('Random post', 'halimthemes') ?>
			</label>
		</p>
		<p class="show_view_count" style="clear: both; display:block;">
			<label for="<?php echo $this->get_field_id("show_view_count"); ?>">
				<input id="<?php echo $this->get_field_id("show_view_count"); ?>" class="show_view_count" name="<?php echo $this->get_field_name("show_view_count"); ?>" type="checkbox" value="1" <?php if (isset($show_view_count)) { checked($show_view_count, 1 ); } ?>/> <?php _e('Show post view count', 'halimthemes') ?>
			</label>
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('postnum'); ?>"><?php _e('Number of post to show', 'halimthemes') ?></label>
			<br />
			<input type="number" class="widefat" style="width: 60px;" id="<?php echo $this->get_field_id('postnum'); ?>" name="<?php echo $this->get_field_name('postnum'); ?>" value="<?php echo $instance['postnum']; ?>" />
		</p>
	<?php
	}
}

function halim_tab_popular_widgets(){
	register_widget('halim_tab_popular_Widget');
}
add_action('widgets_init', 'halim_tab_popular_widgets');