<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#234556">
    <meta name="msapplication-navbutton-color" content="#234556">
    <meta name="apple-mobile-web-app-status-bar-style" content="#234556">
    <?php if (cs_get_option('favicon')): ?>
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo esc_url(cs_get_option('apple_touch_icon')); ?>" />
    <link rel="shortcut icon" href="<?php echo esc_url(cs_get_option('favicon')); ?>" type="image/x-icon" />
    <?php else: ?>
    <link rel="shortcut icon" href="<?php echo HALIM_THEME_URI ?>/assets/images/favicon.ico" type="image/x-icon" />
    <?php endif;
        wp_head();
        if (cs_get_option('header_code')) echo cs_get_option('header_code')."\n";
        $logo = '';
        if(cs_get_option('site_logo')){
            $logo = wp_get_attachment_image_src(cs_get_option('site_logo'), 'full')[0];
        }
    if($logo) : ?>
        <style>#header .site-title {background: url(<?php echo esc_attr($logo); ?>) no-repeat top left;background-size: contain;text-indent: -9999px;}</style>
    <?php else: ?>
        <style>#header .site-title {background: url(<?php echo HALIM_THEME_URI ?>/assets/images/halim-dark-logo.png) no-repeat top left;background-size: contain;text-indent: -9999px;}</style>
    <?php endif; ?>
</head>
<body <?php body_class('halimmovie-v'.HALIMMOVIE_VERSION); ?> data-nonce="<?php echo wp_create_nonce(get_the_ID()); ?>">
<?php
    $header_tpl = cs_get_option('header_template') ? cs_get_option('header_template') : 'tpl-1';
    get_template_part( 'templates/header/header', str_replace('tpl-', '', $header_tpl) );
