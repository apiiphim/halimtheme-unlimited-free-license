<?php
   $footer_tpl = cs_get_option('footer_template') ? cs_get_option('footer_template') : 'tpl-1';
   get_template_part( 'templates/footer/footer', str_replace('tpl-', '', $footer_tpl) );
?>