var $ = jQuery.noConflict();
jQuery(document).ready(function ($) {

    // Perform AJAX login/register on form submit
    $('body').on('submit', 'form#login, form#register', function (e) {
        $('p.status', this).show().text(ajax_auth_object.loadingmessage);
        email = recaptcha = '';
        action = 'ajaxlogin';
        username =  $('form#login #username').val();
        password = $('form#login #password').val();
        recaptcha = $('#g-recaptcha-response').val();
        if ($(this).attr('id') == 'register') {
            action = 'ajaxregister';
            username = $('#signup_name').val();
            password = $('#signup_password').val();
            email = $('#signup_email').val();
            recaptcha = $('#g-recaptcha-response-1').val();
        }
        ctrl = $(this);
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajax_auth_object.ajaxurl,
            data: {
                'action': action,
                'username': username,
                'password': password,
                'email': email,
                'recaptcha': recaptcha
            },
            success: function (data) {
                $('p.status', ctrl).text(data.message);
                if (data.loggedin == true) {
                    document.location.href = ajax_auth_object.redirecturl;
                }
                else if (ctrl == 'register')
                    grecaptcha.reset();
            }
        });
        e.preventDefault();
    });


    // Perform AJAX forget password on form submit
    $('body').on('submit', 'form#forgot_password', function(e){

        $('p.status', this).show().text(ajax_auth_object.loadingmessage);
        ctrl = $(this);
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url: ajax_auth_object.ajaxurl,
            data: {
                'action': 'ajaxforgotpassword',
                'user_login': $('#user_login').val(),
                'recaptcha': $('#g-recaptcha-response-2').val(),
            },
            success: function(data){
                $('p.status',ctrl).text(data.message);
                $('#recaptcha-reset-forgot-password').click();
            }
        });
        e.preventDefault();
        return false;
    });

});

var verifyCallbackLogin = function(response) {
    $('#login input[type=submit]').removeAttr('disabled');
};
var verifyCallbackRegister = function(response) {
    $('#register input[type=submit]').removeAttr('disabled');
};
var verifyCallbackForgotPw = function(response) {
    $('#forgot_password input[type=submit]').removeAttr('disabled');
};
var widgetId1;
var widgetId2;
var widgetId3;
var onloadCallback = function() {
    widgetId1 = grecaptcha.render('g-recaptcha-login', {
        'sitekey' : ajax_auth_object.sitekey,
        'theme' : 'light',
        'callback' : verifyCallbackLogin,
    });
    widgetId2 = grecaptcha.render('g-recaptcha-register', {
        'sitekey' : ajax_auth_object.sitekey,
        'callback' : verifyCallbackRegister,
    });
    widgetId3 = grecaptcha.render('g-recaptcha-forgot-password', {
        'sitekey' : ajax_auth_object.sitekey,
        'callback' : verifyCallbackForgotPw,
    });
};

jQuery('body').on('click', '#recaptcha-reset-login', function(){
    grecaptcha.reset(widgetId1);
    $('#recaptcha-reset-login i').addClass('animate-spin');
    setTimeout(function(){
        $('#recaptcha-reset-login i').removeClass('animate-spin');
    }, 500)
});
jQuery('body').on('click', '#recaptcha-reset-register', function(){
    grecaptcha.reset(widgetId2);
    $('#recaptcha-reset-register i').addClass('animate-spin');
    setTimeout(function(){
        $('#recaptcha-reset-register i').removeClass('animate-spin');
    }, 500)
});
jQuery('body').on('click', '#recaptcha-reset-forgot-password', function(){
    grecaptcha.reset(widgetId3);
    $('#recaptcha-reset-forgot-password i').addClass('animate-spin');
    setTimeout(function(){
        $('#recaptcha-reset-forgot-password i').removeClass('animate-spin');
    }, 500)
});

function recaptchaReset(widgetId){
    grecaptcha.reset(widgetId);
}


function showRegisterForm(){

    $('.loginBox').fadeOut('fast',function(){
        $('.registerBox').fadeIn('fast');
        $('.forgotPasswordBox').fadeOut('fast');
        $('.login-footer').fadeOut('fast',function(){
            $('.register-footer').fadeIn('fast');
        });
        $('.modal-title').html(ajax_auth_object.languages.register_with);
    });
    $('.error').removeClass('alert alert-danger').html('');
}

function showForgotPasswordForm(){

    $('.loginBox').fadeOut('fast',function(){
        $('.forgotPasswordBox').fadeIn('fast');
        $('.register-footer').fadeOut('fast',function(){
            $('.login-footer').fadeIn('fast');
        });

        $('.modal-title').html(ajax_auth_object.languages.forgotpassword);
    });
    $('.error').removeClass('alert alert-danger').html('');

}

function showLoginForm(){

    $('#loginModal .registerBox').fadeOut('fast',function(){
        $('.loginBox').fadeIn('fast');
        $('.forgotPasswordBox').fadeOut('fast');
        $('.register-footer').fadeOut('fast',function(){
            $('.login-footer').fadeIn('fast');
        });

        $('.modal-title').html(ajax_auth_object.languages.login_with);
    });
    $('.error').removeClass('alert alert-danger').html('');
}

function openLoginModal(){

    showLoginForm();

    var s = document.createElement('script');
    s.src = '//www.google.com/recaptcha/api.js?onload=onloadCallback&render=explicit';
    $('head').append(s);

    var html = `<div class="modal fade login" id="loginModal">
        <div class="modal-dialog login animated">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
                    <h4 class="modal-title">`+ajax_auth_object.languages.login_with+`</h4> </div>
                <div class="modal-body">
                    <div class="content">
                        <div class="social" id="ajax-social-login">
                            <a id="facebook_login" class="circle facebook" href="javascript:showNotice();"> <i class="hl-facebook"></i> </a>
                            <a id="google_login" class="circle google" href="javascript:showNotice();"> <i class="hl-gplus"></i> </a>
                            <a id="twitter_login" class="circle twitter" href="javascript:showNotice();"> <i class="hl-twitter"></i> </a>
                        </div>
                        <div class="division">
                            <div class="line l"></div><span>`+ajax_auth_object.languages.or+`</span>
                            <div class="line r"></div>
                        </div>
                        <div class="error"></div>
                        <div class="form loginBox">
                            <form id="login" method="post" action="javascript:recaptchaReset(widgetId1);" accept-charset="UTF-8">
                                <p class="status"></p>
                                <input id="username" class="form-control" type="text" placeholder="`+ajax_auth_object.languages.username+`" name="username">
                                <input id="password" class="form-control" type="password" placeholder="`+ajax_auth_object.languages.password+`" name="password">
                                <div id="g-recaptcha-login"></div>
                                <div class="reset-captcha" id="recaptcha-reset-login"><i class="hl-spin4"></i> `+ajax_auth_object.languages.reset_captcha+`</div>
                                <input class="btn btn-default btn-login" type="submit" value="`+ajax_auth_object.languages.login+`" disabled>
                            </form>
                        </div>
                    </div>
                    <div class="content registerBox" style="display:none;">
                        <div class="form">
                            <form id="register" method="post" html="{:multipart=>true}" data-remote="true" action="javascript:recaptchaReset(widgetId2);" accept-charset="UTF-8">
                                <p class="status"></p>
                                <input id="signup_name" class="form-control" type="text" placeholder="`+ajax_auth_object.languages.username+`" name="username">
                                <input id="signup_email" class="form-control" type="text" placeholder="`+ajax_auth_object.languages.email+`" name="email">
                                <input id="signup_password" class="form-control" type="password" placeholder="`+ajax_auth_object.languages.password+`" name="password">
                                <div id="g-recaptcha-register"></div>
                                <div class="reset-captcha" id="recaptcha-reset-register"><i class="hl-spin4"></i> `+ajax_auth_object.languages.reset_captcha+`</div>
                                <input class="btn btn-default btn-register" type="submit" value="`+ajax_auth_object.languages.create_account+`" disabled>
                            </form>
                        </div>
                    </div>
                    <div class="content forgotPasswordBox" style="display:none;">
                        <div class="form">
                            <form id="forgot_password" method="post" action="javascript:recaptchaReset(widgetId3);" accept-charset="UTF-8">
                                <p class="status"></p>
                                <input id="user_login" class="form-control" type="text" placeholder="`+ajax_auth_object.languages.username_email+`" name="user_login">
                                <div id="g-recaptcha-forgot-password"></div>
                                <div class="reset-captcha" id="recaptcha-reset-forgot-password"><i class="hl-spin4"></i> `+ajax_auth_object.languages.reset_captcha+`</div>
                                <input class="btn btn-default btn-forgot" type="submit" value="`+ajax_auth_object.languages.reset_password+`" disabled>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="forgot login-footer"><span><a href="javascript:showRegisterForm();">`+ajax_auth_object.languages.register+` </a></span>| <span><a href="javascript:showForgotPasswordForm();"> `+ajax_auth_object.languages.forgotpassword+`</a></span></div>
                    <div class="forgot register-footer" style="display:none"> <span>`+ajax_auth_object.languages.already_account+`</span> <a href="javascript:showLoginForm();">`+ajax_auth_object.languages.login+`</a> </div>
                </div>
            </div>
        </div>
    </div>`;



    var htmlOld = '<div class="modal fade login" id="loginModal">'+
    '    <div class="modal-dialog login animated">'+
    '        <div class="modal-content">'+
    '            <div class="modal-header">'+
    '                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>'+
    '                <h4 class="modal-title">'+ajax_auth_object.languages.login_with+'</h4>'+
    '            </div>'+
    '            <div class="modal-body">'+
    '                <div class="content">'+
    '                    <div class="social" id="ajax-social-login">'+
    '                        <a id="facebook_login" class="circle facebook" href="javascript:showNotice();">'+
    '                            <i class="hl-facebook"></i>'+
    '                        </a>'+
    '                        <a id="google_login" class="circle google" href="javascript:showNotice();">'+
    '                            <i class="hl-gplus"></i>'+
    '                        </a>'+
    '                        <a id="twitter_login" class="circle twitter" href="javascript:showNotice();">'+
    '                            <i class="hl-twitter"></i>'+
    '                        </a>'+
    '                    </div>'+
    '                    <div class="division">'+
    '                        <div class="line l"></div>'+
    '                        <span>'+ajax_auth_object.languages.or+'</span>'+
    '                        <div class="line r"></div>'+
    '                    </div>'+
    '                    <div class="error"></div>'+
    '                    <div class="form loginBox">'+
    '                        <form id="login" method="post" action="javascript:recaptchaReset(widgetId1);" accept-charset="UTF-8">'+
    '                            <p class="status"></p>'+
    '                            <input id="username" class="form-control" type="text" placeholder="'+ajax_auth_object.languages.username+'" name="username">'+
    '                            <input id="password" class="form-control" type="password" placeholder="'+ajax_auth_object.languages.password+'" name="password">'+
    '                            <div id="g-recaptcha-login"></div>'+
    '                            <div class="reset-captcha" id="recaptcha-reset-login"><i class="hl-spin4"></i> '+ajax_auth_object.languages.reset_captcha+'</div>'+
    '                            <input class="btn btn-default btn-login" type="submit" value="'+ajax_auth_object.languages.login+'" disabled>'+
    '                        </form>'+
    '                    </div>'+
    '                </div>'+
    '                <div class="content registerBox" style="display:none;">'+
    '                    <div class="form">'+
    '                        <form id="register" method="post" html="{:multipart=>true}" data-remote="true" action="javascript:recaptchaReset(widgetId2);" accept-charset="UTF-8">'+
    '                            <p class="status"></p>'+
    '                            <input id="signup_name" class="form-control" type="text" placeholder="'+ajax_auth_object.languages.username+'" name="username" class="required">'+
    '                            <input id="signup_email" class="form-control" type="text" placeholder="'+ajax_auth_object.languages.email+'" name="email">'+
    '                            <input id="signup_password" class="form-control" type="password" placeholder="'+ajax_auth_object.languages.password+'" name="password">'+
    '                            <div id="g-recaptcha-register"></div>'+
    '                            <div class="reset-captcha" id="recaptcha-reset-register"><i class="hl-spin4"></i> '+ajax_auth_object.languages.reset_captcha+'</div>'+
    '                            <input class="btn btn-default btn-register" type="submit" value="'+ajax_auth_object.languages.create_account+'" disabled>'+
    '                        </form>'+
    '                    </div>'+
    '                </div>'+
    '                <div class="content forgotPasswordBox" style="display:none;">'+
    '                    <div class="form">'+
    '                        <form id="forgot_password" method="post" action="javascript:recaptchaReset(widgetId3);" accept-charset="UTF-8">'+
    '                            <p class="status"></p>'+
    '                            <input id="user_login" class="form-control" type="text" placeholder="'+ajax_auth_object.languages.username_email+'" class="required" name="user_login">'+
    '                            <div id="g-recaptcha-forgot-password"></div>'+
    '                            <div class="reset-captcha" id="recaptcha-reset-forgot-password"><i class="hl-spin4"></i> '+ajax_auth_object.languages.reset_captcha+'</div>'+
    '                            <input class="btn btn-default btn-forgot" type="submit" value="'+ajax_auth_object.languages.reset_password+'" disabled>'+
    '                        </form>'+
    '                    </div>'+
    '                </div>'+
    '            </div>'+
    '            <div class="modal-footer">'+
    '                <div class="forgot login-footer">'+
    '                <span><a href="javascript:showRegisterForm();">'+ajax_auth_object.languages.register+' </a></span>|'+
    '                <span><a href="javascript:showForgotPasswordForm();"> '+ajax_auth_object.languages.forgotpassword+'</a>'+
    '                </span>'+
    '                </div>'+
    '                <div class="forgot register-footer" style="display:none">'+
    '                    <span>'+ajax_auth_object.languages.already_account+'</span>'+
    '                    <a href="javascript:showLoginForm();">'+ajax_auth_object.languages.login+'</a>'+
    '                </div>'+
    '            </div>'+
    '        </div>'+
    '    </div>'+
    '</div>';
    $('body').append(html);

    setTimeout(function(){
        $('#loginModal').modal('show');
        $('#loginModal').on('hidden.bs.modal', function(e){
            $(this).remove();
        });
        if(halim_ajax_login !== null){
            if(halim_ajax_login.facebook_login_url){
                var _href = $('a#facebook_login').attr('href').replace('javascript:showNotice();', '');
                $('a#facebook_login').attr('href', _href + halim_ajax_login.facebook_login_url);
            }
            if(halim_ajax_login.google_login_url){
                var _href = $('a#google_login').attr('href').replace('javascript:showNotice();', '');
                $('a#google_login').attr('href', _href + halim_ajax_login.google_login_url);
            }
            if(halim_ajax_login.twitter_login_url){
                var _href = $('a#twitter_login').attr('href').replace('javascript:showNotice();', '');
                    _href.replace('javascript:;', '');
                $('a#twitter_login').attr('href', _href + halim_ajax_login.twitter_login_url);
            }
        }
    }, 200);
}

function openRegisterModal(){
    showRegisterForm();
    setTimeout(function(){
        $('#loginModal').modal('show');
    }, 200);
}

function showNotice(){
    alert('Comming soon...');
}