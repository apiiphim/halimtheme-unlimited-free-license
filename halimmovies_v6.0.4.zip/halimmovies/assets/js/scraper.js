var $ = jQuery.noConflict();

$(document).ready(function(){

	$('<script>').on('load', function(){
        console.log('Successfully loaded lazysizes.min.js script.');
    }).prop('src', halim_scraper.lazysizes).each(function(){
        document.body.appendChild(this);
	});

	$('#get-discover-data').click(function(){
		getDiscover();
	});

	$('#get-trending-data').click(function(){
		getTrending();
	});

	$('[name=site]').change(function(){
	   ($(this).val() == 'imdb') ? $('.media_type').hide() : $('.media_type').show();
	   $('#s').focus();
	});

    var thread = null;
    $('#s').keypress(function(e) {
	    var key = (e.keyCode ? e.keyCode : e.which);
	    if (key == 13) {
	      	getSearch(thread);
	      	return false;
	    }
	});

    $('[name=media_type]').change(function(){
	    getSearch(thread, $(this).val());
	});

    $('body').on('click', '.pagination.search li a', function(){
    	getSearch(thread, null, $(this).data('page'));

    });

    $('body').on('click', '.pagination.trending li a', function(){
    	getTrending($(this).data('page'));
    });

    $('body').on('click', '.pagination.discover li a', function(){
    	getDiscover($(this).data('page'));
    });

});

function getSearch(thread, media_type = null, page = '')
{
	clearTimeout(thread);
	var $this = $(this);
	thread = setTimeout(
  	function() {
		var query = $('[name=s]').val(),
			is_adult = $('[name=is_adult]:checked').val(),
			media_type = (media_type == null) ? $('[name=media_type]:checked').val() : media_type;
			$('#loading').removeClass('hidden');

			if(query){
				$.ajax({
					type: 'POST',
					url: halim_scraper.ajax_url,
					data: {
						action: 'halim_tmdb_search_ajax',
						query: query,
						is_adult: is_adult,
						media_type: media_type,
						page: page
					},
					success: function(data) {
						$('#loading').addClass('hidden');
						$('#results').html(data);
						$('#checkAll').click(function () {
						    $('#results input:checkbox').not(this).prop('checked', this.checked);
						});
						appendInput();

					}
				});
			}
			else {
				$('#results').text('The keyword can\'t be empty!');
				$('#loading').addClass('hidden');
			}


	  	},
	  	100 //1000
	);
}

function getTrending(page = '')
{
	var values = $.map($('#trending-form option:selected'), function(e) { return e.value; });
	values.join(',');
	$.ajax({
		type: 'POST',
		url: halim_scraper.ajax_url,
		data: {
			action: 'halim_get_trending_data',
			values: values,
			page: page
		},
		success: function(data) {
			$('#results').html(data);

			$('#checkAll').click(function () {
			     $('#results input:checkbox').not(this).prop('checked', this.checked);
			});
			appendInput();
		}
	});
}

function getDiscover(page = '')
{
	var language = $('#discover-form [name=language]').val(),
		is_adult = $('[name=is_adult]:checked').val(),
		release_year = $('#discover-form [name=release_year]').val(),
		discover_type = $.map($('#discover-form [name=discover_type] option:selected'), function(e) { return e.value; }),
		sort_by = $.map($('#discover-form [name=sort_by] option:selected'), function(e) { return e.value; });

	sort_by.join(',');

	$.ajax({
		type: 'POST',
		url: halim_scraper.ajax_url,
		data: {
			action: 'halim_ajax_discover',
			is_adult: is_adult,
			sort_by: sort_by,
			language: language,
			release_year: release_year,
			discover_type: discover_type,
			page: page
		},
		success: function(data) {

			$('#results').html(data);
			$('#checkAll').click(function () {
			    $('#results input:checkbox').not(this).prop('checked', this.checked);
			});
			appendInput();
		}
	});
}

function appendInput()
{
	$('.post-meta span.name').on('input', function(e){
	    var data = {}, filmId = $(this).data('id');
    	data['title'] = $(this).text(),
    	data['tmdb_id'] = $(this).data('tmdb_id'),
    	data['original_title'] = $(this).data('original_title'),
    	data['media_type'] = $(this).data('media_type'),
    	data['original_language'] = $(this).data('original_language'),
    	data['first_air_date'] = $(this).data('first_air_date'),
    	data['genre_ids'] = $(this).data('genre_ids'),
    	data['release_date'] = $(this).data('release_date'),
    	data['poster_image'] = $(this).data('poster_image');
	    $('#pid-'+filmId).val(JSON.stringify(data));
	});
	$('.post-meta span.original-title').on('input', function(e){
	    var data = {}, filmId = $(this).data('id');
    	data['title'] = $(this).data('title'),
    	data['tmdb_id'] = $(this).data('tmdb_id'),
    	data['original_title'] = $(this).text(),
    	data['media_type'] = $(this).data('media_type'),
    	data['original_language'] = $(this).data('original_language'),
    	data['first_air_date'] = $(this).data('first_air_date'),
    	data['genre_ids'] = $(this).data('genre_ids'),
    	data['release_date'] = $(this).data('release_date'),
    	data['poster_image'] = $(this).data('poster_image');
	    $('#pid-'+filmId).val(JSON.stringify(data));
	});
}


// $(function () {
//     $("#select_all").on("click", function () {
//         $("#checkBoxes input:checkbox").prop('checked', $(this).prop('checked'));
//     });

// 	$('#rebuild').click(function(){

//         var movie_data = [];
//         $('#checkBoxes [name=movie_data]:checked').each(function(i){
//           movie_data[i] = $(this).val();
//         });
//         console.log(movie_data);
// 	});
// });

function setMessage(msg) {
	$("#message").html(msg).show();
}



var check;
$(".halim-wrap").on("click", function(){
    check = $("input[name=\"create_category\"]").is(":checked");
    if(check) {
        $('#list-cat').hide();
    } else {
        $('#list-cat').show();
    }
});




function CrawlData() {
	$("#halim_data_rebuild").prop("disabled", true);
	setMessage("<p>Reading data...</p>");
    var movie_data = [];
    $('.list-movies [name=movie_data]:checked').each(function(i){
      	movie_data[i] = btoa($(this).val());
    });

    var auto_create_category = $('[name=create_category]:checked').val();
    var save_poster = $('[name=save_poster]:checked').val();

	$.ajax({
		url: halim_scraper.ajax_url,
		type: "POST",
		data: "action=halim_data_crawler&do=getlist&movie_data="+movie_data+"&auto_create_category="+auto_create_category+"&save_poster="+save_poster,
		success: function(result) {
			var list = eval(result), i = 0;
			if (!list) {
				setMessage('No data found.');
				$("#halim_data_rebuild").prop("disabled", false);
				return;
			}
			console.log(list);
			function regenItem() {
				if (i >= list.length) {
					$("#halim_data_rebuild").prop("disabled", false);
					$('#status p:first-child').addClass('ok');
					setMessage("Done!");
					return;
				}

				if(list[i].movie_data)
				{
					setMessage( 'Rebuilding ' + (i + 1) + ' of ' + list.length + ' (' + list[i].movie_data + ')...');
					$.ajax({
						url: halim_scraper.ajax_url,
						type: "POST",
						data: {
							action: 'halim_data_crawler',
							do: 'regen',
							movie_data: list[i].movie_data,
							auto_create_category: auto_create_category,
							save_poster: save_poster
						},
						success: function(result) {
							i = i + 1;
							if (result != '-1') {
								$('#status').prepend('<p><span style="color:#46b450;font-size: 17px;font-weight: bold;">✓</span> '+result+'</p>');
							}
							regenItem();
						}
					});
				}
			}

			regenItem();
		},
		error: function(request, status, error) {
			setMessage("Error!" + request.status);
		}
	});
}