<?php

/**
* Template Name: Showtimes Movie
*/
get_header();?>
<main id="section-showtimes-movie" class="col-md-12" style="padding: 0;">
	<?php if ( is_active_sidebar( 'halim-ad-above-category' ) ) { ?>
	    <div class="a--d-wrapper" style="text-align: center; margin: 10px 0;">
	        <?php dynamic_sidebar( 'halim-ad-above-category' ); ?>
	    </div>
	<?php } ?>

    <?php

    	$showtime_terms = get_terms('showtimes', array('hide_empty' => false, 'parent' => 0));
    	sort($showtime_terms);
    	$i = 1;
    	foreach( $showtime_terms as $lichchieu ):
    		$lichchieu = (object)$lichchieu;
    		?>

	   	<section id="showtimes-movie_<?php echo $i; ?>" class="tab-content col-md-12">
			<div role="tabpanel" class="tab-pane active halim-ajax-popular-post">

				<div class="popular-post showtimes-movie">

					<div class="section-bar clearfix">
					   <h3 class="section-title">
						<span><i class="hl-calendar"></i> <?php echo $lichchieu->name; ?></span>
						<i class="view-more">
							<a href="<?php echo site_url().'/showtimes/'.$lichchieu->slug;?>"><?php _e('View all', 'halimthemes'); ?><i class="hl-angle-right"></i></a></i>
					   </h3>
					</div>
					<div class="halim-ajax-get-post-loading halim-ajax-popular-post-loading-<?php echo $lichchieu->slug; ?> hidden"></div>
					<div id="ajax-showtimes-widget-<?php echo $lichchieu->slug; ?>">
						<?php
							showtimes_term_children($lichchieu->term_id, $lichchieu->slug);
							$args = array(
								'post_type'			=> 'post',
								'posts_per_page' 	=> 12,
								'post_status' 		=> 'publish',
								'orderby'			=> 'modified'
							);

					        $args['tax_query'] = array(
						        array(
						            'taxonomy' => 'showtimes',
						            'field' => 'slug',
						            'terms' => $lichchieu->slug,
						            'operator' => 'IN'
						        )
					        );
							$wp_query = new WP_Query( $args );

							if ($wp_query->have_posts()) : while ($wp_query->have_posts()) : $wp_query->the_post();
								get_template_part( 'templates/loop-list', 'showtimes', ['type' => 'all', 'show_info' => true] );
							endwhile; wp_reset_postdata();
						else:
							echo '<div class="alert alert-danger text-center" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>No posts found!</div>';
						endif;
						?>
					</div>
				</div>
			</div>
		</section>

    <?php $i++; endforeach; ?>

	<?php if ( is_active_sidebar( 'halim-ad-below-category' ) ) { ?>
	    <div class="a--d-wrapper" style="text-align: center; margin: 10px 0;">
	        <?php dynamic_sidebar( 'halim-ad-below-category' ); ?>
	    </div>
	<?php } ?>
</main>
<?php get_footer(); ?>